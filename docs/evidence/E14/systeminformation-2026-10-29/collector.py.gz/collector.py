"""Preserve dependency refusal, actual upstream witnesses and bounded checks."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re

root=Path('/home/haki/code/pw-wt/session-followup-20261027')
work=Path(__file__).resolve().parent
out=root/'docs/evidence/E14/systeminformation-2026-10-29';out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
rows=[]
def add(label,path):
    raw=path.read_bytes();encoded=gzip.compress(raw,mtime=0)
    target=out/(label+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb')as stream:stream.write(encoded)
    if gzip.decompress(target.read_bytes())!=raw:raise RuntimeError('Archive mismatch')
    rows.append({'path':target.relative_to(out).as_posix(),'bytes':len(encoded),'sha256':sha(encoded),
                 'decoded_bytes':len(raw),'decoded_sha256':sha(raw),'original_local_path':str(path)})
for folder in ['systeminformation-upstream-before-5.33.15','systeminformation-upstream-after-5.33.16']:
    for name in ['lib/util.js','lib/processes.js','package.json','LICENSE']:
        add('upstream/'+folder+'/'+name,work/folder/name)
for name in [
    'systeminformation_windows_sanitizer_regression.cjs',
    'systeminformation-windows-sanitizer-red-20261029.log','systeminformation-windows-sanitizer-green-20261029.log',
    'systeminformation-audit-red-20261029.log','systeminformation-audit-green-20261029.log',
    'systeminformation-registry-5.33.16-20261029.json','systeminformation-lock-refresh-20261029.log',
    'systeminformation-frozen-install-green-20261029.log',
    'systeminformation_cypress_resolution.initial.cjs','systeminformation-cypress-resolution-initial-REFUSED.json',
    'systeminformation_cypress_resolution.cjs','systeminformation-cypress-resolution-final-20261029.json',
]:add('working-diagnostics/'+name,work/name)
windows=work/'systeminformation-windows-owned-20261029T1734501132Z'
record=json.loads((windows/'receipt.json').read_text())
if record['node_version']!='v24.18.0' or [r['native_exit']for r in record['rows']]!=[1,0] or any(r['timed_out']or not r['reaped']for r in record['rows']):
    raise RuntimeError('Windows process outcome incomplete')
for path in sorted(windows.iterdir()):
    if path.is_file():add('post-repair-windows-comparison/'+path.name,path)
cypress=work/'systeminformation-working-cypress-20261029T172745Z'
proof=json.loads((cypress/'complete.json').read_text())
if len(proof['gates'])!=3 or not proof['working_inputs_unchanged']or any(g['exit']for g in proof['gates']):
    raise RuntimeError('Cypress check incomplete')
native=(cypress/'cypress.log').read_text()
if len(re.findall(r'^\s*\d+\s+pass\s',native,re.M))!=29 or 'acceptance: the required test outcomes passed'not in native:
    raise RuntimeError('Cypress inventory incomplete')
for path in sorted(cypress.iterdir()):
    if path.is_file():add('working-cypress/'+path.name,path)
for job in ['123606576476','123606607616']:
    for extension in ['log','json']:
        path=work/'session-followup-88f577a2-ci-independent/original-job-logs'/('job-'+job+'.'+extension)
        add('failed-hosted-88/'+path.name,path)
for name in ['decision.json','failed-proof.json','review.md','seal-manifest.json']:
    add('failed-hosted-88/'+name,work/('session-followup-88f577a2-ci-independent-'+name))
for name in ['package.json','pnpm-lock.yaml']:
    add('working-source/'+name,root/name)
add('collector.py',Path(__file__))
report={'kind':'FAILED_88_CANDIDATE_AND_WORKING_DEPENDENCY_REPAIR_ONLY',
        'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'failed_candidate':'88f577a299f26da90ee52654d9debd9b22c45dd6',
        'advisory':'GHSA-3f7j-7jwc-fxfj','affected':'<5.33.16','patched':'5.33.16',
        'maintainer_advisory':'https://github.com/sebhildebrandt/systeminformation/security/advisories/GHSA-3f7j-7jwc-fxfj',
        'maintainer_patch':'https://github.com/sebhildebrandt/systeminformation/commit/5014c6d25cfce7363b937977327baa853cdba0bf',
        'scope':['One root range-scoped override and matching root lock resolution only; unchanged audit allowances/policy.',
                 'First real Windows pure sanitizer RED1fail/1ASCIIpass before dependency change, GREEN2/0 after.',
                 'Owned old/new Windows comparison is POST_REPAIR, not restamped pre-repair execution.',
                 'No services(), PowerShell invocation, whitelist or exploitability coverage is claimed.',
                 'Original consumer-resolution probe used a symlink require origin and was refused; final realpath probe is distinct.',
                 'Actual compatibility-copy Cypress29/0 includes persistence; it is not unchanged upstream execution.',
                 'All working reports remain uncredited to any immutable successor; fresh exact-commit gates still required.'],
        'working_results':{'windows_cases':2,'windows_failed_after':0,'cypress_cases':29,'cypress_failed':0,
                           'cypress_skipped':0,'cypress_pending':0,'audit_new_findings':0,'existing_documented_allowances':4},
        'files':rows}
with(out/'manifest.json').open('x')as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({'out':str(out),'payloads':len(rows),'manifest_sha256':sha((out/'manifest.json').read_bytes())},indent=2))
