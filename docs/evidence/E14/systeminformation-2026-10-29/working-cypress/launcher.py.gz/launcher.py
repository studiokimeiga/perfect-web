"""Working compatibility check of the actual patched Cypress dependency tree."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import types

root=Path('/home/haki/code/pw-wt/session-followup-20261027')
work=Path(__file__).resolve().parent
head='88f577a299f26da90ee52654d9debd9b22c45dd6'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=work/('systeminformation-working-cypress-'+stamp);out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inputs():return{p.decode():sha((root/p.decode()).read_bytes())for p in git('ls-files','-z').split(b'\0')if p}
if git('rev-parse','HEAD').decode().strip()!=head:raise RuntimeError('Head changed')
before=inputs();(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
producer=types.ModuleType('_si_working_cypress_process');producer.__file__=str(root/'scripts/producer_process.py')
sys.modules[producer.__name__]=producer
exec(compile(git('show',head+':scripts/producer_process.py'),producer.__file__,'exec'),producer.__dict__)
environment={**os.environ,'CI':'1','BUILD_ONLY':'1','PORT':'33680','DIAGNOSTIC':'','PW_REUSE':'',
             'PW_FEED_DATABASE_URL':'','PW_STORE_DATABASE_URL':'','PW_BLOB_DIR':'','PW_STORE_TEST_LAYER':'memory',
             'OUT':str(out/'cypress-native.txt')}
commands=[('todo-build',['bash','spikes/own-renderer/todomvc.sh'],600),
          ('server-build',['cargo','build','--quiet','--locked','-p','pw-dev-server'],600),
          ('cypress',['bash','spikes/todomvc-cypress/run.sh'],600)]
rows=[]
for label,command,timeout in commands:
    reaped=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with(out/(label+'.log')).open('x')as log:
        result=producer.run(command,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT,
                            timeout=timeout,grace=2,on_reaped=lambda pid,status,timed_out,cancelled:reaped.append(
                            {'pid':pid,'status':status,'timed_out':timed_out,'cancelled':cancelled}))
    row={'label':label,'command':command,'exit':result.returncode,'started_utc':started,
         'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owned_reaped':reaped,
         'log_sha256':sha((out/(label+'.log')).read_bytes()),'inputs_unchanged':inputs()==before}
    rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(label+' exit='+str(result.returncode),flush=True)
    if result.returncode or not row['inputs_unchanged']:raise RuntimeError(label+' refused')
after=inputs();(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'working.diff').write_bytes(git('diff','--binary',head))
(out/'launcher.py').write_bytes(Path(__file__).read_bytes())
(out/'complete.json').write_text(json.dumps({'baseline_head':head,'working_inputs_unchanged':before==after,'gates':rows,
    'scope':'Actual compatibility-copy Cypress consumer on working patched dependency; not immutable successor or original unchanged upstream suite acceptance.'},indent=2)+'\n')
