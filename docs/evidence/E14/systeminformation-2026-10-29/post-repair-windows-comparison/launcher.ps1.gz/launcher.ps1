param([switch]$IncludeOld, [string]$ExpectedHead = '')
$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\Users\haki\Documents\Codex\2026-10-26\con\work'
$repoRoot = '/home/haki/code/pw-wt/session-followup-20261027'
$head = (& wsl.exe -e git -C $repoRoot rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or ($ExpectedHead -and $head -ne $ExpectedHead)) { throw 'Unexpected Git head' }
$node = 'C:\Program Files\nodejs\node.exe'
$fixture = Join-Path $taskRoot 'systeminformation_windows_sanitizer_regression.cjs'
$stamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssffffZ')
$out = Join-Path $taskRoot ('systeminformation-windows-owned-' + $stamp)
if (Test-Path -LiteralPath $out) { throw 'Existing output' }
New-Item -ItemType Directory -Path $out | Out-Null
$nodeVersion = (& $node --version).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Node version unavailable' }
$cases = @()
if ($IncludeOld) {
    $cases += @{ label='old-source-negative-control'; module=(Join-Path $taskRoot 'systeminformation-upstream-before-5.33.15\lib\util.js'); expected_exit=1 }
}
$cases += @{ label='patched'; module='\\wsl.localhost\Ubuntu\home\haki\code\pw-wt\session-followup-20261027\node_modules\.pnpm\systeminformation@5.33.16\node_modules\systeminformation\lib\util.js'; expected_exit=0 }
$rows = @()
foreach ($case in $cases) {
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $node
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.StandardOutputEncoding = [Text.UTF8Encoding]::new($false)
    $info.StandardErrorEncoding = [Text.UTF8Encoding]::new($false)
    foreach ($argument in @('--test', '--test-reporter=spec', $fixture)) { $info.ArgumentList.Add($argument) }
    $info.Environment['PW_SI_FIXTURE_UTIL_PATH'] = $case.module
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $info
    if (-not $process.Start()) { throw 'Native process did not start' }
    $ownedPid = $process.Id
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    $finished = $process.WaitForExit(30000)
    if (-not $finished) { $process.Kill($true); $process.WaitForExit() }
    $exitCode = $process.ExitCode
    $log = Join-Path $out ($case.label + '.stdout.log')
    [IO.File]::WriteAllText($log, $stdout.GetAwaiter().GetResult(), [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText((Join-Path $out ($case.label + '.stderr.log')), $stderr.GetAwaiter().GetResult(), [Text.UTF8Encoding]::new($false))
    $rows += @{ label=$case.label; pid=$ownedPid; native_exit=$exitCode; expected_exit=$case.expected_exit;
        timed_out=(-not $finished); reaped=$process.HasExited; module_path=$case.module;
        module_sha256=(Get-FileHash -LiteralPath $case.module -Algorithm SHA256).Hash.ToLower();
        log_sha256=(Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash.ToLower() }
    $process.Dispose()
    if (-not $finished -or $exitCode -ne $case.expected_exit) { throw 'Native outcome differs' }
}
$record = @{ observed_utc=[DateTime]::UtcNow.ToString('o'); observed_git_head=$head; node_version=$nodeVersion;
    node_executable_sha256=(Get-FileHash -LiteralPath $node -Algorithm SHA256).Hash.ToLower();
    fixture_sha256=(Get-FileHash -LiteralPath $fixture -Algorithm SHA256).Hash.ToLower();
    rows=$rows; scope='Real Windows pure upstream sanitizer only. Old-source control is post-repair; no services, PowerShell, whitelist or exploit proof.' }
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'receipt.json')
Copy-Item -LiteralPath $fixture -Destination (Join-Path $out 'fixture.cjs')
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $out 'launcher.ps1')
@{ output=$out; node_version=$nodeVersion; cases=$rows.Count; exits=@($rows | ForEach-Object native_exit) } | ConvertTo-Json -Depth 4
