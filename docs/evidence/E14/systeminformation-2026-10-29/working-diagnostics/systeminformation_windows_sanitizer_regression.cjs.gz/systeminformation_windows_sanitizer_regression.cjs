// Diagnostic of the real upstream pure function on Windows. No services()
// call, PowerShell invocation, service mutation or exploit command is used.
const assert = require('node:assert/strict');
const test = require('node:test');
assert.equal(process.platform, 'win32', 'this diagnostic requires real Windows Node');
const util = require(process.env.PW_SI_FIXTURE_UTIL_PATH);

test('default Windows sanitization removes Unicode string delimiters', () => {
  assert.equal(util.sanitizeShellString('service\u201c\u201d'), 'service');
});

test('an ordinary service name remains unchanged', () => {
  assert.equal(util.sanitizeShellString('Spooler'), 'Spooler');
});
