const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const { readFileSync } = require('node:fs');
const { createHash } = require('node:crypto');
const { dirname, join } = require('node:path');
const cypress = createRequire(process.env.PW_SI_CYPRESS_PACKAGE);
const resolved = cypress.resolve('systeminformation/package.json');
const package = JSON.parse(readFileSync(resolved, 'utf8'));
assert.equal(package.version, '5.33.16');
assert.equal(package.license, 'MIT');
const hash = (path) => createHash('sha256').update(readFileSync(path)).digest('hex');
console.log(JSON.stringify({
  cypress_package: process.env.PW_SI_CYPRESS_PACKAGE,
  resolved, version: package.version, license: package.license,
  util_sha256: hash(join(dirname(resolved), 'lib/util.js')),
  processes_sha256: hash(join(dirname(resolved), 'lib/processes.js')),
}, null, 2));
