#!/usr/bin/env bash
# The code-health refactor's checks, copied into the branch's evidence
# (`audit/`): CI's audit as it failed at ad788543 and as it passes at
# d962441b, the whole check and the reached mutation scripts at d962441b,
# the long logs compressed, the scripts that wrote them beside them, and
# SHA256SUMS regenerated (README excluded, as before).
set -euo pipefail
source "$SCRATCH/env.sh"
EV="$WT/docs/evidence/E14/first-press-2026-11-06"
OUT="$EV/audit"
mkdir -p "$OUT"
strip() { sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$1"; }
small() { strip "$SP/$1" > "$OUT/$1"; }
large() { strip "$SP/$1" | gzip -9n > "$OUT/$1.gz"; }
gzip -9nc "$SP/fallow-audit.json" > "$OUT/fallow-audit-ad788543.json.gz"
gzip -9nc "$SP/fallow-audit3.json" > "$OUT/fallow-audit-d962441b.json.gz"
small final-verify3.log
for f in prepush5-verify.log prepush5-size.log; do small "$f"; done
for f in prepush5-preflight.log prepush5-evidence-gates.log prepush5-cargo-test.log prepush5-specs.log; do large "$f"; done
for s in press_modules runtime_recovery address_fragment navigate; do large "mut3-$s.log"; done
for f in final-verify3.sh prepush-verify.sh reached.py copy-audit.sh; do
  gzip -9nc "$SP/$f" > "$OUT/$f.gz"
done
cd "$EV"
find . -type f ! -name README.md ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
echo "copied: $(ls "$OUT" | wc -l) files; SHA256SUMS lines: $(wc -l < SHA256SUMS)"
