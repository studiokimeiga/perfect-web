#!/usr/bin/env bash
# After d962441b (code health): the Fallow audit as CI runs it, the whole
# pre-push check, then the four mutation scripts the change reaches
# (`reached.py ad788543`), each run whole.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/final-verify3.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "commit $(git rev-parse HEAD); uncommitted code paths: $(git status --porcelain -- . ':(exclude)docs' | wc -l)"
step "fallow audit (fallow 3.23.0, gate new-only, against 5c53870d, as CI runs it)"
npx -y fallow@3.23.0 audit --root . --quiet --format json \
  --changed-since 5c53870dfba2502b14be3a0ffec0aa88d44dcbba --gate new-only > "$SP/fallow-audit3.json"
echo "exit fallow $?" >> "$LOG"
python3 - "$SP/fallow-audit3.json" >> "$LOG" <<'EOF'
import json, sys
d = json.load(open(sys.argv[1]))
print("verdict", d["verdict"], json.dumps(d["attribution"]))
for f in d["complexity"]["findings"]:
    if f.get("introduced"):
        print("introduced", f["path"], f["name"], f["line"], f["cyclomatic"], f["exceeded"])
for g in d["duplication"]["clone_groups"]:
    if g.get("introduced"):
        print("introduced clone", [(i.get("file"), i.get("start_line")) for i in g["instances"]])
EOF
step "reached mutation scripts (reached.py ad788543 3)"
python3 "$SP/reached.py" ad788543 3 >> "$LOG" 2>&1
step "the whole pre-push check (TAG=prepush5)"
TAG=prepush5 bash "$SCRATCH/prepush-verify.sh"; echo "exit prepush5 $?" >> "$LOG"
grep -E "^exit |Running [0-9]+ tests|^\s+[0-9]+ (passed|skipped|failed|flaky)|^Ran |^OK|^FAILED|EVIDENCE|is not run|test result: ok. 8" "$SP/prepush5-verify.log" >> "$LOG"
for s in press_modules runtime_recovery address_fragment navigate; do
  step "mutation controls: $s"
  python3 "scripts/${s}_mutations.py" > "$SP/mut3-$s.log" 2>&1
  echo "exit $s $?" >> "$LOG"
  grep -E "KILLED|SURVIVED|REFUSED|mutants killed" "$SP/mut3-$s.log" >> "$LOG"
done
step "restored"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
git status --porcelain -- . ':(exclude)docs' >> "$LOG"
echo FINAL_VERIFY3_FINISHED >> "$LOG"
