// What the renderer's warm-up costs where nothing compiled it yet: on a
// page whose runtime never calls it (the A build), a fresh instance of its
// renderer, `warm()` timed on its first call and on a second.
// usage: node warm-cost.mjs URL [rate] [runs]
import { chromium } from "@playwright/test";
const [url, rate = "1", runs = "6"] = process.argv.slice(2);
const browser = await chromium.launch();
const rows = [];
for (let i = 0; i < Number(runs); i++) {
  const context = await browser.newContext();
  const page = await context.newPage();
  const cdp = await context.newCDPSession(page);
  await page.goto(url);
  await page.waitForLoadState("load");
  await page.waitForTimeout(1500);
  const src = await page.evaluate(() =>
    performance.getEntriesByType("resource").map((e) => e.name).find((n) => n.includes("pw-render.wasm")),
  );
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: Number(rate) });
  rows.push(
    await page.evaluate(async (src) => {
      const { instance } = await WebAssembly.instantiateStreaming(fetch(src));
      const t0 = performance.now();
      const code = instance.exports.warm();
      const t1 = performance.now();
      instance.exports.warm();
      const t2 = performance.now();
      return [code, t1 - t0, t2 - t1];
    }, src),
  );
  await context.close();
}
await browser.close();
const med = (xs) => [...xs].sort((a, b) => a - b)[Math.floor(xs.length / 2)];
console.log(`CPU x${rate}: codes ${rows.map((r) => r[0]).join(" ")}; first warm() median ${med(rows.map((r) => r[1])).toFixed(1)} ms ` +
  `(${rows.map((r) => r[1].toFixed(1)).join(" ")}); second ${med(rows.map((r) => r[2])).toFixed(1)} ms`);
