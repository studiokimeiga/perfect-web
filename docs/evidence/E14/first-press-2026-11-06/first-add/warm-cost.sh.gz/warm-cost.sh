#!/usr/bin/env bash
set -uo pipefail
source $SCRATCH/env.sh
SCR=$SCRATCH/work
cp "$SP/warm-cost.mjs" "$SCR/"
cd spikes/own-renderer
PORT=13811 PW_FEED_DATABASE_URL= PW_STORE_DATABASE_URL= "$CARGO_TARGET_DIR/release/pw-dev-server" "$SCR/dist-A" > "$SCR/server-A.log" 2>&1 &
A=$!
trap 'kill $A 2>/dev/null' EXIT
for i in $(seq 1 100); do curl -s -o /dev/null "http://localhost:13811/" && break; sleep 0.1; done
node "$SCR/warm-cost.mjs" http://localhost:13811/ 1 6
node "$SCR/warm-cost.mjs" http://localhost:13811/ 4 6
