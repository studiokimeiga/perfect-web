#!/usr/bin/env bash
# The final code: the specs the warm-up reaches (keyed's build made too),
# the runtime's size, and the evidence copied into the branch.
set -uo pipefail
source $SCRATCH/env.sh
LOG="$SP/last-check.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "anchors, unit tests"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
cargo test --quiet --locked -p pw-render-wasm >> "$LOG" 2>&1; echo "exit cargo test $?" >> "$LOG"
step "dists"
cargo build --quiet --locked -p pw-cli -p pw-dev-server >> "$LOG" 2>&1; echo "exit build $?" >> "$LOG"
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/run-sh.log" 2>&1; echo "exit run.sh $?" >> "$LOG"
bash spikes/own-renderer/todomvc.sh > "$SP/todomvc-dev.log" 2>&1; echo "exit todomvc.sh $?" >> "$LOG"
bash spikes/own-renderer/keyed-store.sh > "$SP/keyed-store.log" 2>&1; echo "exit keyed-store.sh $?" >> "$LOG"
cd spikes/own-renderer
step "specs (chromium, firefox)"
PORT=13880 pnpm exec playwright test warm.spec.mjs signals.spec.mjs todomvc.spec.mjs keyed-list.spec.mjs keyed.spec.mjs \
  press-modules.spec.mjs lazy-handler.spec.mjs dialog.spec.mjs focus.spec.mjs views.spec.mjs device-store.spec.mjs \
  --project=chromium --project=firefox --reporter=line > "$SP/last-specs.log" 2>&1
echo "exit specs $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/last-specs.log" | grep -E "is not run|^\s+[0-9]+\) |^\s+[0-9]+ (passed|skipped|failed|flaky|did not run)|Running [0-9]+ tests" >> "$LOG"
step "runtime size"
PORT=13880 pnpm exec playwright test runtime-size.spec.mjs --project=chromium --workers=1 --reporter=line > "$SP/last-size.log" 2>&1
echo "exit runtime-size $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/last-size.log" | grep -h "EVIDENCE interactive\|EVIDENCE renderer" >> "$LOG"
echo LAST_CHECK_FINISHED >> "$LOG"
