#!/usr/bin/env bash
# The warm-up of a press's paths: tests, the development specs, and the
# renderer-reaching specs again with every base page's build warming.
set -uo pipefail
source $SCRATCH/env.sh
LOG="$SP/warmpaths-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "anchors"; python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit $?" >> "$LOG"
step "unit tests"
cargo test --quiet --locked -p pw-render-wasm -p pw-render >> "$LOG" 2>&1; echo "exit cargo test $?" >> "$LOG"
(cd spikes/own-renderer && node --test optimize-assets.test.mjs >> "$LOG" 2>&1); echo "exit node test $?" >> "$LOG"
step "debug build + development dists"
cargo build --quiet --locked -p pw-cli -p pw-dev-server >> "$LOG" 2>&1
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/run-sh.log" 2>&1; echo "exit run.sh $?" >> "$LOG"
bash spikes/own-renderer/todomvc.sh > "$SP/todomvc-dev.log" 2>&1; echo "exit todomvc.sh $?" >> "$LOG"
cd spikes/own-renderer
rm -f dist/delivery.json dist-todomvc/delivery.json
SPECS="signals.spec.mjs keyed-list.spec.mjs keyed.spec.mjs todomvc.spec.mjs optimistic.spec.mjs views.spec.mjs \
  device-store.spec.mjs cart.spec.mjs dialog.spec.mjs focus.spec.mjs press-modules.spec.mjs warm.spec.mjs \
  fragment.spec.mjs bind.spec.mjs lazy-handler.spec.mjs soft-navigation.spec.mjs navigate.spec.mjs stable-layout.spec.mjs"
step "development specs (chromium, firefox)"
PORT=13880 pnpm exec playwright test $SPECS --project=chromium --project=firefox --reporter=line >> "$LOG" 2>&1; echo "exit specs $?" >> "$LOG"
step "runtime size (gate 7b, 7d)"
PORT=13880 pnpm exec playwright test runtime-size.spec.mjs --project=chromium --workers=1 --reporter=line >> "$LOG" 2>&1; echo "exit runtime-size $?" >> "$LOG"
step "the same, every base and TodoMVC page warming"
echo '{"warm": true}' > dist/delivery.json
echo '{"warm": true}' > dist-todomvc/delivery.json
WARMING="signals.spec.mjs keyed-list.spec.mjs keyed.spec.mjs todomvc.spec.mjs optimistic.spec.mjs views.spec.mjs \
  device-store.spec.mjs cart.spec.mjs dialog.spec.mjs focus.spec.mjs press-modules.spec.mjs fragment.spec.mjs bind.spec.mjs \
  soft-navigation.spec.mjs navigate.spec.mjs stable-layout.spec.mjs"
PORT=13880 pnpm exec playwright test $WARMING --project=chromium --project=firefox --reporter=line >> "$LOG" 2>&1; echo "exit warming specs $?" >> "$LOG"
rm -f dist/delivery.json dist-todomvc/delivery.json
step "done"
echo WARMPATHS_VERIFY_FINISHED >> "$LOG"
