// Whether nodes imported into a document made by createHTMLDocument load
// or run anything, in Chromium and Firefox: an img, a video, an audio, an
// iframe and a defined custom element, imported from the page.
import { chromium, firefox } from "@playwright/test";
import { createServer } from "node:http";
const asked = [];
const server = createServer((req, res) => {
  asked.push(req.url);
  if (req.url === "/") {
    res.setHeader("content-type", "text/html");
    res.end(`<!doctype html><body><div id="src"></div></body>`);
  } else {
    res.statusCode = 404;
    res.end();
  }
}).listen(13890);
for (const engine of [chromium, firefox]) {
  asked.length = 0;
  const browser = await engine.launch();
  const page = await browser.newPage();
  await page.goto("http://localhost:13890/");
  const result = await page.evaluate(async () => {
    let constructed = 0;
    customElements.define("x-probe", class extends HTMLElement { constructor() { super(); constructed++; } });
    const src = document.getElementById("src");
    // Built detached from the page's own document, never connected.
    const tmpl = document.createElement("template");
    tmpl.innerHTML = `<img src="/img?probe"><video src="/video?probe" preload="auto"></video>` +
      `<audio src="/audio?probe" preload="auto"></audio><iframe src="/frame?probe"></iframe>` +
      `<picture><source srcset="/source?probe"><img src="/pimg?probe"></picture><x-probe></x-probe>` +
      `<link rel="stylesheet" href="/css?probe"><object data="/object?probe"></object>`;
    const made = constructed;
    const inert = document.implementation.createHTMLDocument("");
    const copy = inert.createElement("div");
    for (const n of tmpl.content.childNodes) copy.append(inert.importNode(n, true));
    await new Promise((r) => setTimeout(r, 1500));
    return { constructedByTemplate: made, constructedByImport: constructed - made };
  });
  console.log(engine.name(), JSON.stringify(result), "requests:", JSON.stringify(asked.filter((u) => u.includes("probe"))));
  await browser.close();
}
server.close();
