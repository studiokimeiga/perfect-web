// The FIRST add on a TodoMVC page left idle after its load (its warm-up
// done), in Chromium: in-page timings, and from a trace what the main
// thread ran between the key and the frame after it, by event name.
// usage: node first-add.mjs URL [rate] [runs] [label]
import { chromium } from "@playwright/test";

const [url, rateArg = "1", runsArg = "6", label = ""] = process.argv.slice(2);
const rate = Number(rateArg);
const runs = Number(runsArg);
const browser = await chromium.launch();
const timings = [];
const byName = new Map();
let warmLog = [];
for (let run = 0; run < runs; run++) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const cdp = await context.newCDPSession(page);
  await page.goto(url);
  await page.waitForFunction(() => document.documentElement.dataset.pwReady === "1");
  await page.waitForLoadState("load");
  await page.waitForTimeout(2500);
  warmLog = await page.evaluate(() => window.__pw.log.filter((l) => /warm/.test(l)));
  await page.fill(".new-todo", "measured");
  await page.evaluate(() => {
    window.__t = {};
    addEventListener("keydown", (e) => { if (e.key === "Enter") window.__t.key = e.timeStamp; }, true);
    new MutationObserver(() => {
      if (window.__t.mut) return;
      window.__t.mut = performance.now();
      requestAnimationFrame(() => {
        window.__t.raf = performance.now();
        setTimeout(() => (window.__t.after = performance.now()), 0);
      });
    }).observe(document.body, { subtree: true, childList: true });
  });
  await cdp.send("Emulation.setCPUThrottlingRate", { rate });
  await browser.startTracing(page, {
    categories: [
      "devtools.timeline", "disabled-by-default-devtools.timeline", "toplevel", "blink",
      "v8", "v8.execute", "disabled-by-default-v8.compile", "v8.wasm", "disabled-by-default-v8.wasm.detailed",
    ],
  });
  await page.press(".new-todo", "Enter");
  await page.waitForFunction(() => document.querySelectorAll(".todo-list li").length === 1);
  await page.waitForFunction(() => window.__t.after != null);
  await page.waitForTimeout(200);
  const trace = JSON.parse((await browser.stopTracing()).toString());
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: 1 });
  const t = await page.evaluate(() => window.__t);
  timings.push([t.mut - t.key, t.raf - t.key, t.after - t.key]);
  const events = trace.traceEvents ?? trace;
  const key = events.find((e) => e.name === "EventDispatch" && e.args?.data?.type === "keydown");
  if (key) {
    const end = key.ts + (t.after - t.key) * 1000;
    for (const e of events) {
      if (e.pid !== key.pid || e.tid !== key.tid || e.ts < key.ts || e.ts > end || e.ph !== "X") continue;
      const k = e.name;
      const v = byName.get(k) ?? { us: 0, n: 0 };
      v.us += e.dur ?? 0;
      v.n += 1;
      byName.set(k, v);
    }
  }
  await context.close();
}
await browser.close();
const med = (xs) => [...xs].sort((a, b) => a - b)[Math.floor(xs.length / 2)];
const col = (i) => timings.map((r) => r[i]);
console.log(`${label} CPU x${rate}, ${runs} runs; warm log: ${JSON.stringify(warmLog)}`);
console.log(`  key->mutation  median ${med(col(0)).toFixed(1)}  runs ${col(0).map((x) => x.toFixed(1)).join(" ")}`);
console.log(`  key->rAF       median ${med(col(1)).toFixed(1)}  runs ${col(1).map((x) => x.toFixed(1)).join(" ")}`);
console.log(`  key->after     median ${med(col(2)).toFixed(1)}  runs ${col(2).map((x) => x.toFixed(1)).join(" ")}`);
console.log(`  main thread, key to frame, by event (ms per run, total incl. nested; count per run):`);
for (const [k, v] of [...byName].sort((a, b) => b[1].us - a[1].us).slice(0, 22)) {
  console.log(`    ${(v.us / 1000 / runs).toFixed(2).padStart(7)}  ${(v.n / runs).toFixed(1).padStart(6)}  ${k}`);
}
