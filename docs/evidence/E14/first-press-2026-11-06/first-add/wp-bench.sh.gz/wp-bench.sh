#!/usr/bin/env bash
# The head-to-head with the press's paths warmed: TodoMVC (loopback and
# Slow 4G, cold and warm) and the store's valid record (five server rounds).
set -uo pipefail
source $SCRATCH/env.sh
LOG="$SP/wp-bench.log"
: > "$LOG"
OUT="$SP/bench"
mkdir -p "$OUT"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "release + production TodoMVC"
cargo build --quiet --locked --release -p pw-dev-server >> "$LOG" 2>&1; echo "exit release $?" >> "$LOG"
PW_PRODUCTION_ASSETS=1 bash spikes/own-renderer/todomvc.sh > "$SP/todomvc-prod.log" 2>&1; echo "exit todomvc.sh $?" >> "$LOG"
cat spikes/own-renderer/dist-todomvc/delivery.json >> "$LOG"; echo >> "$LOG"
step "TodoMVC loopback"
PORT=13741 node benchmarks/headtohead/head-to-head.mjs --apps todomvc --stacks pleris,react,svelte --engines chromium \
  --runs 5 --conditions cold,warm --no-shaped --no-load --settle 0 --json "$OUT/wp-loopback.json" > "$OUT/wp-loopback.log" 2>&1
echo "exit loopback $?" >> "$LOG"
step "TodoMVC Slow 4G"
PORT=13741 node benchmarks/headtohead/head-to-head.mjs --apps todomvc --stacks pleris,react,svelte --engines chromium \
  --runs 5 --conditions cold,warm --no-load --settle 0 --json "$OUT/wp-slow4g.json" > "$OUT/wp-slow4g.log" 2>&1
echo "exit slow4g $?" >> "$LOG"
if [ "${STORE:-1}" = 1 ]; then
  step "store record (production, five server rounds)"
  PW_PRODUCTION_ASSETS=1 bash spikes/own-renderer/baseline-store.sh > /dev/null 2>&1; echo "exit baseline-store $?" >> "$LOG"
  PORT=13741 node benchmarks/headtohead/head-to-head.mjs --apps store --stacks pleris,next-react,sveltekit \
    --engines chromium --runs 5 --conditions cold,warm --settle 0 --json "$OUT/wp-store.json" > "$OUT/wp-store.log" 2>&1
  echo "exit store $?" >> "$LOG"
fi
step "done"
echo WP_BENCH_FINISHED >> "$LOG"
