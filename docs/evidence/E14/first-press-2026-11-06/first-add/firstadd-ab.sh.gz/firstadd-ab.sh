#!/usr/bin/env bash
# The first add, HEAD's runtime (A) against the working tree's (B): each a
# production TodoMVC build, served by the same release server.
set -uo pipefail
source $SCRATCH/env.sh
SCR=$SCRATCH/work
mkdir -p "$SCR"
[ -e "$SCR/node_modules" ] || ln -s "$WT/benchmarks/headtohead/node_modules" "$SCR/node_modules"
cp "$SP/first-add.mjs" "$SCR/"
RT=spikes/own-renderer/public/pw-runtime.mjs
if [ "${SKIP_BUILD:-0}" != 1 ]; then
  cargo build --quiet --release -p pw-dev-server || exit 1
  cp "$RT" "$SP/pw-runtime.B.mjs"
  rm -rf "$SCR/dist-A" "$SCR/dist-B"
  PW_OUT="$SCR/dist-B" PW_PRODUCTION_ASSETS=1 bash spikes/own-renderer/todomvc.sh > "$SCR/build-B.log" 2>&1 || { tail -20 "$SCR/build-B.log"; exit 1; }
  git show HEAD:$RT > "$RT"
  PW_OUT="$SCR/dist-A" PW_PRODUCTION_ASSETS=1 bash spikes/own-renderer/todomvc.sh > "$SCR/build-A.log" 2>&1
  status=$?
  cp "$SP/pw-runtime.B.mjs" "$RT"
  [ $status = 0 ] || { tail -20 "$SCR/build-A.log"; exit 1; }
  git diff --stat
fi
cd spikes/own-renderer
PORT=13811 PW_FEED_DATABASE_URL= PW_STORE_DATABASE_URL= "$CARGO_TARGET_DIR/release/pw-dev-server" "$SCR/dist-A" > "$SCR/server-A.log" 2>&1 &
A=$!
PORT=13812 PW_FEED_DATABASE_URL= PW_STORE_DATABASE_URL= "$CARGO_TARGET_DIR/release/pw-dev-server" "$SCR/dist-B" > "$SCR/server-B.log" 2>&1 &
B=$!
trap 'kill $A $B 2>/dev/null' EXIT
for p in 13811 13812; do for i in $(seq 1 100); do curl -s -o /dev/null "http://localhost:$p/" && break; sleep 0.1; done; done
for rate in ${RATES:-4 1}; do
  for round in 1 2; do
    node "$SCR/first-add.mjs" http://localhost:13811/ "$rate" "${RUNS:-6}" "A(HEAD)"
    node "$SCR/first-add.mjs" http://localhost:13812/ "$rate" "${RUNS:-6}" "B(warm paths)"
  done
done
