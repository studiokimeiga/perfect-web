#!/usr/bin/env bash
# press-modules and keyed-list with the base pages warming: HEAD's runtime
# (warming without the paths' warm-up), then the working tree's. The
# working runtime is kept aside and put back whatever happens.
set -uo pipefail
source $SCRATCH/env.sh
LOG="$SP/head-warming.log"
: > "$LOG"
RT=spikes/own-renderer/public/pw-runtime.mjs
cp "$RT" "$SP/pw-runtime.B2.mjs"
restore() { cp "$SP/pw-runtime.B2.mjs" "$RT"; rm -f spikes/own-renderer/dist/delivery.json; }
trap restore EXIT
run() {
  local label=$1
  BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/run-sh.log" 2>&1; echo "exit run.sh ($label) $?" >> "$LOG"
  echo '{"warm": true}' > spikes/own-renderer/dist/delivery.json
  (cd spikes/own-renderer && PORT=13880 pnpm exec playwright test press-modules.spec.mjs keyed-list.spec.mjs \
    --project=chromium --project=firefox --reporter=line > "$SP/head-warming-$label.log" 2>&1); echo "exit specs ($label) $?" >> "$LOG"
  sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/head-warming-$label.log" | grep -E "^\s+\[(chromium|firefox)\] ›|passed|failed|flaky" >> "$LOG"
  rm -f spikes/own-renderer/dist/delivery.json
}
git show HEAD:$RT > "$RT"
run head
cp "$SP/pw-runtime.B2.mjs" "$RT"
run tree
cmp "$RT" "$SP/pw-runtime.B2.mjs" && echo "runtime restored" >> "$LOG"
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/run-sh.log" 2>&1; echo "exit final run.sh $?" >> "$LOG"
echo HEAD_WARMING_FINISHED >> "$LOG"
