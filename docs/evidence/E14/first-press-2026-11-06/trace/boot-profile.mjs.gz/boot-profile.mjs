// Profile a page's boot in Chromium with the CPU throttled (Lighthouse's
// 4x), from navigation to the runtime's ready: self and total time by
// function, and the runtime's own activation measure.
// usage: node boot-profile.mjs URL [rate] [runs]
import { chromium } from "@playwright/test";

const [url, rateArg = "4", runsArg = "3"] = process.argv.slice(2);
const rate = Number(rateArg);
const browser = await chromium.launch();
const self = new Map();
const total = new Map();
const measures = [];
for (let run = 0; run < Number(runsArg); run++) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  const cdp = await context.newCDPSession(page);
  await cdp.send("Emulation.setCPUThrottlingRate", { rate });
  await cdp.send("Profiler.enable");
  await cdp.send("Profiler.setSamplingInterval", { interval: 100 });
  await cdp.send("Profiler.start");
  await page.goto(url);
  await page.waitForFunction(() => document.documentElement.dataset.pwReady === "1");
  const { profile } = await cdp.send("Profiler.stop");
  measures.push(
    await page.evaluate(() => {
      const nav = performance.getEntriesByType("navigation")[0];
      const m = (n) => performance.getEntriesByName(n)[0];
      return {
        responseEnd: nav.responseEnd,
        domInteractive: nav.domInteractive,
        activateStart: m("pw:activate:start")?.startTime,
        activate: m("pw:activate")?.duration,
        ready: performance.now(),
      };
    }),
  );
  // Self time per node, from samples and their deltas.
  const byId = new Map(profile.nodes.map((n) => [n.id, n]));
  const parent = new Map();
  for (const n of profile.nodes) for (const c of n.children ?? []) parent.set(c, n.id);
  const dt = new Map();
  profile.samples.forEach((id, i) => dt.set(id, (dt.get(id) ?? 0) + (profile.timeDeltas[i] ?? 0)));
  const name = (n) => {
    const f = n.callFrame;
    const file = (f.url || "").split("/").pop() || "(native)";
    return `${f.functionName || "(anonymous)"} ${file}${f.lineNumber >= 0 ? ":" + (f.lineNumber + 1) : ""}`;
  };
  for (const [id, us] of dt) {
    const n = byId.get(id);
    const k = name(n);
    self.set(k, (self.get(k) ?? 0) + us);
    // Total: this node and every ancestor, each function once per sample.
    const seen = new Set();
    for (let cur = id; cur != null; cur = parent.get(cur)) {
      const key = name(byId.get(cur));
      if (seen.has(key)) continue;
      seen.add(key);
      total.set(key, (total.get(key) ?? 0) + us);
    }
  }
  await context.close();
}
await browser.close();
const runs = Number(runsArg);
console.log("measures (ms):", JSON.stringify(measures, null, 0));
const show = (title, map, n) => {
  console.log(`\n${title} (ms, mean of ${runs} runs, CPU x${rate}):`);
  for (const [k, us] of [...map].sort((a, b) => b[1] - a[1]).slice(0, n)) {
    if (/^\(idle\)|^\(program\)|^\(root\)/.test(k)) continue;
    console.log(`  ${(us / 1000 / runs).toFixed(1).padStart(8)}  ${k}`);
  }
};
show("self time", self, 30);
show("total time", total, 30);
