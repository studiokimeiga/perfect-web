// Trace one TodoMVC interaction in Chromium and print what ran between the
// input event and the next frame. usage:
//   node trace-press.mjs URL OUT.json [add|toggle|filter]
import { chromium } from "@playwright/test";
import { writeFileSync } from "node:fs";

const [url, out, which = "toggle"] = process.argv.slice(2);
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await context.newPage();
page.on("console", (m) => console.log("console:", m.text()));
await page.goto(url);
await page.waitForFunction(() => document.documentElement.dataset.pwReady === "1");
await page.waitForLoadState("load");
await page.waitForTimeout(1500); // warm-up, idle
// Prepare: one todo for toggle.
if (which !== "add") {
  await page.fill(".new-todo", "first");
  await page.press(".new-todo", "Enter");
  await page.waitForFunction(() => document.querySelectorAll(".todo-list li").length === 1);
  await page.waitForTimeout(500);
}
await page.evaluate(() => {
  window.__t = {};
  for (const type of ["keydown", "pointerdown", "mousedown", "click", "change", "input"]) {
    addEventListener(type, (e) => (window.__t[type] ??= e.timeStamp), true);
  }
  new MutationObserver(() => (window.__t.mutation ??= performance.now())).observe(document.body, {
    subtree: true, childList: true, attributes: true, characterData: true,
  });
});
if (which === "add") await page.fill(".new-todo", "h2h one");
await browser.startTracing(page, {
  categories: [
    "devtools.timeline", "disabled-by-default-devtools.timeline", "v8.execute", "blink.user_timing",
    "disabled-by-default-devtools.timeline.frame", "toplevel", "blink", "loading",
    "disabled-by-default-v8.cpu_profiler",
  ],
});
const t0 = Date.now();
if (which === "add") await page.press(".new-todo", "Enter");
else if (which === "toggle") await page.click(".todo-list li .toggle");
else await page.click('.filters a[href="#/completed"]');
await page.waitForTimeout(300);
const trace = await browser.stopTracing();
writeFileSync(out, trace);
const t = await page.evaluate(() => ({ ...window.__t, log: window.__pw.log.slice(-12) }));
console.log(JSON.stringify(t, null, 1));
console.log(`wall ${Date.now() - t0} ms; trace ${trace.length} bytes -> ${out}`);
await browser.close();
