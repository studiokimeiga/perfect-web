// Summarize a Chromium trace around the first input event: the main
// thread's top-level tasks and notable events, in time order, from the
// input's dispatch to the second frame after it.
import { readFileSync } from "node:fs";
const trace = JSON.parse(readFileSync(process.argv[2], "utf8"));
const events = trace.traceEvents ?? trace;
// The renderer main thread: the thread with EventDispatch events.
const dispatch = events.filter((e) => e.name === "EventDispatch" && e.args?.data?.type);
const first = dispatch.find((e) => ["keydown", "pointerdown", "mousedown", "click"].includes(e.args.data.type));
if (!first) {
  console.log("no input dispatch found");
  process.exit(1);
}
const { pid, tid } = first;
const start = first.ts;
const main = events
  .filter((e) => e.pid === pid && e.tid === tid && e.ts >= start - 2000 && e.ts <= start + 120_000)
  .sort((a, b) => a.ts - b.ts);
const NOTE = new Set([
  "RunTask", "EventDispatch", "FunctionCall", "TimerFire", "TimerInstall", "FireAnimationFrame",
  "RequestAnimationFrame", "Layout", "UpdateLayoutTree", "Paint", "PrePaint", "Commit", "ParseHTML",
  "v8.compile", "v8.compileModule", "v8.evaluateModule", "EvaluateScript", "RunMicrotasks",
  "XHRReadyStateChange", "ResourceFinish", "ResourceReceiveResponse", "ResourceSendRequest",
  "BeginMainThreadFrame", "UpdateLayer", "HitTest", "ScheduleStyleRecalculation", "InvalidateLayout",
  "v8.callFunction", "V8.Execute", "IntersectionObserverController::computeIntersections",
  "PageAnimator::serviceScriptedAnimations", "ProfileChunk",
]);
const ms = (ts) => ((ts - start) / 1000).toFixed(2).padStart(8);
let depth = 0;
for (const e of main) {
  if (!NOTE.has(e.name)) continue;
  if (e.name === "ProfileChunk") continue;
  const dur = e.dur != null ? `${(e.dur / 1000).toFixed(2)}ms` : e.ph;
  const d = e.args?.data ?? {};
  const what = d.type ?? d.functionName ?? d.url?.slice(-50) ?? d.timerId ?? d.frame ?? "";
  const line = `${ms(e.ts)}  ${e.name.padEnd(28)} ${String(dur).padStart(9)}  ${what}`;
  if ((e.dur ?? 0) >= 100 || !["RunTask", "FunctionCall"].includes(e.name)) console.log(line);
}
// Frames on the compositor: DrawFrame / BeginFrame on any thread of the renderer pid.
const frames = events
  .filter((e) => e.pid === pid && ["DrawFrame", "BeginFrame", "Commit", "Paint"].includes(e.name) && e.ts >= start && e.ts <= start + 120_000)
  .sort((a, b) => a.ts - b.ts)
  .slice(0, 16)
  .map((e) => `${e.name}@${((e.ts - start) / 1000).toFixed(1)}`);
console.log("\nframes:", frames.join("  "));
