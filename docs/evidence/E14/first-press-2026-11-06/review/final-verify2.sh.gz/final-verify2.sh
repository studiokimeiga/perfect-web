#!/usr/bin/env bash
# After 21863b22 (one look for a cut a pass): the whole pre-push check again,
# then the one mutation script the change reaches, run whole.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/final-verify2.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "commit $(git rev-parse HEAD); uncommitted code paths: $(git status --porcelain -- . ':(exclude)docs' | wc -l)"
step "the whole pre-push check (TAG=prepush4)"
TAG=prepush4 bash "$SCRATCH/prepush-verify.sh"; echo "exit prepush4 $?" >> "$LOG"
grep -E "^exit |Running [0-9]+ tests|^\s+[0-9]+ (passed|skipped|failed|flaky)|^Ran |^OK|^FAILED|EVIDENCE|is not run|test result: ok. 8" "$SP/prepush4-verify.log" >> "$LOG"
step "mutation controls: connection_faults"
python3 scripts/connection_faults_mutations.py > "$SP/mut2-connection_faults.log" 2>&1
echo "exit connection_faults $?" >> "$LOG"
grep -E "KILLED|SURVIVED|REFUSED|mutants killed" "$SP/mut2-connection_faults.log" >> "$LOG"
step "restored"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
git status --porcelain -- . ':(exclude)docs' >> "$LOG"
echo FINAL_VERIFY2_FINISHED >> "$LOG"
