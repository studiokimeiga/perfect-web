#!/usr/bin/env bash
# A5: a cut wakes a held subscription at once, and none is missed between
# its look and its wait. fmt, anchors, green, red (the wake deleted), restored.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/a5-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
cargo fmt -p pw-dev-server >> "$LOG" 2>&1; echo "exit fmt $?" >> "$LOG"
python3 scripts/mutation_anchors.py 2>&1 | tail -3 >> "$LOG"
step "green: the reconnect and wake tests"
cargo test --quiet --locked -p pw-dev-server -- reconnect wakes cut held_subscription 2>&1 | grep -E "test result|panicked" >> "$LOG"
step "red: the cut's wake deleted"
F=spikes/own-renderer/server/src/main.rs
cp "$F" "$SP/a5-main.rs.orig"
python3 - <<'PY'
import pathlib
p = pathlib.Path("spikes/own-renderer/server/src/main.rs")
s = p.read_text()
wake = ('            let table = server.pending.lock().expect("pending");\n'
        '            server.pending.wake();\n'
        '            drop(table);\n')
assert s.count(wake) == 1, "anchor"
p.write_text(s.replace(wake, ""))
PY
cargo test --quiet --locked -p pw-dev-server -- a_cut_wakes_a_held_subscription_at_once 2>&1 | grep -E "test result|panicked|so by the wake" | cut -c1-200 >> "$LOG"
cp "$SP/a5-main.rs.orig" "$F"
cmp -s "$F" "$SP/a5-main.rs.orig" && echo "main.rs restored" >> "$LOG"
echo A5_VERIFY_FINISHED >> "$LOG"
