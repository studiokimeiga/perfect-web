#!/usr/bin/env bash
# A3: a host that admits from a kept source does not warm. fmt, green, red
# with the guard removed, restored.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/a3-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "fmt"
cargo fmt -p pw-dev-server >> "$LOG" 2>&1; echo "exit fmt $?" >> "$LOG"
git diff --stat >> "$LOG"
step "green"
cargo test --quiet --locked -p pw-dev-server -- warm >> "$LOG" 2>&1; echo "exit green $?" >> "$LOG"
step "red: the guard removed"
F=spikes/own-renderer/server/src/main.rs
cp "$F" "$SP/a3-main.rs.orig"
python3 - <<'PY'
import pathlib
p = pathlib.Path("spikes/own-renderer/server/src/main.rs")
s = p.read_text()
line = "            if server.warm && !server.identity.principals().admits_from_a_kept_source() {\n"
assert s.count(line) == 1, "anchor"
p.write_text(s.replace(line, "            if server.warm {\n"))
PY
cargo test --quiet --locked -p pw-dev-server -- a_host_that_admits_from_a_kept_source_does_not_warm 2>&1 | grep -E "test result|panicked|admitted from a kept source" | cut -c1-160 >> "$LOG"
cp "$SP/a3-main.rs.orig" "$F"
step "restored"
cmp -s "$F" "$SP/a3-main.rs.orig" && echo "main.rs restored" >> "$LOG"
echo A3_VERIFY_FINISHED >> "$LOG"
