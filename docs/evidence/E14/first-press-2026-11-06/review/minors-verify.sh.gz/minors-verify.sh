#!/usr/bin/env bash
# The runtime's minor fixes (warmPaths' idle and life checks, the handover's
# release, a leaving page's fragment links) and the fragment spec's tests:
# green, two reds, restored.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/minors-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
R=spikes/own-renderer/public/pw-runtime.mjs
cp "$R" "$SP/minors-runtime.fixed"
step "build (the fixes)"
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/minors-run.log" 2>&1; echo "exit run.sh $?" >> "$LOG"
cd spikes/own-renderer
step "green: fragment, warm, soft-navigation, the load specs, runtime size"
PORT=13880 pnpm exec playwright test fragment.spec.mjs warm.spec.mjs soft-navigation.spec.mjs press-modules.spec.mjs lazy-handler.spec.mjs navigate.spec.mjs \
  --project=chromium --project=firefox --reporter=line > "$SP/minors-green.log" 2>&1
echo "exit green $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/minors-green.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
PORT=13880 pnpm exec playwright test runtime-size.spec.mjs --project=chromium --workers=1 --reporter=line > "$SP/minors-size.log" 2>&1
echo "exit runtime-size $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/minors-size.log" | grep -h "EVIDENCE interactive\|EVIDENCE renderer\|passed\|failed" >> "$LOG"
step "red 1: the committed runtime (no leaving guard)"
git show HEAD:$R > public/pw-runtime.mjs
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/minors-run-red1.log" 2>&1); echo "exit run.sh (red 1) $?" >> "$LOG"
PORT=13880 pnpm exec playwright test fragment.spec.mjs -g "leaving" --project=chromium --project=firefox --reporter=line > "$SP/minors-red1.log" 2>&1
echo "exit red 1 $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/minors-red1.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
step "red 2: a link to the address it is at pushes an entry"
cp "$SP/minors-runtime.fixed" public/pw-runtime.mjs
python3 - <<'PY'
import pathlib
p = pathlib.Path("public/pw-runtime.mjs")
s = p.read_text()
line = '      if (url.href !== location.href) history.pushState(null, "", url.href);\n'
assert s.count(line) == 1, "anchor"
p.write_text(s.replace(line, '      history.pushState(null, "", url.href);\n'))
PY
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/minors-run-red2.log" 2>&1); echo "exit run.sh (red 2) $?" >> "$LOG"
PORT=13880 pnpm exec playwright test fragment.spec.mjs -g "no entry of its own" --project=chromium --project=firefox --reporter=line > "$SP/minors-red2.log" 2>&1
echo "exit red 2 $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/minors-red2.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
step "restored"
cp "$SP/minors-runtime.fixed" public/pw-runtime.mjs
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/minors-run-restored.log" 2>&1); echo "exit run.sh (restored) $?" >> "$LOG"
cd "$WT"
cmp -s "$R" "$SP/minors-runtime.fixed" && echo "runtime: the fixes, restored" >> "$LOG"
git diff --stat >> "$LOG"
echo MINORS_VERIFY_FINISHED >> "$LOG"
