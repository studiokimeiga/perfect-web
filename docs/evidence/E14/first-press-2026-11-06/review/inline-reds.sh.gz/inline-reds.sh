#!/usr/bin/env bash
# The red runs made inline while fixing the review's findings, again, into a
# log: A1 (`name_files` as it was) and A6 (the two routes that ignore the
# query). Each: the source mutated, the test run, the source restored.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/inline-reds.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
F=spikes/own-renderer/server/src/main.rs
cp "$F" "$SP/reds-main.rs.orig"
step "commit $(git rev-parse HEAD)"

step "A1 red: name_files as it was at 1f021e1d (a replace over the whole document)"
python3 - <<'PY'
import pathlib
p = pathlib.Path("spikes/own-renderer/server/src/main.rs")
s = p.read_text()
start = s.index("    fn name_files(&self, document: String) -> String {\n")
end = s.index("    /// **A document as this delivery sends it**")
old = '''    fn name_files(&self, document: String) -> String {
        if self.version.is_none() {
            return document;
        }
        let mut document = document;
        for file in &self.files {
            for attribute in ["href", "src"] {
                let plain = format!("{attribute}=\\"{file}\\"");
                if document.contains(&plain) {
                    document =
                        document.replace(&plain, &format!("{attribute}=\\"{}\\"", self.named(file)));
                }
            }
        }
        document
    }

    #[allow(dead_code)]
    fn name_in(&self, tag: &str, named: &mut String) {
        named.push_str(tag);
    }

'''
p.write_text(s[:start] + old + s[end:])
PY
cargo test --quiet --locked -p pw-dev-server -- a_production_build_names_its_files_at_one_version 2>&1 | grep -E "test result|a reader's text" | cut -c1-200 >> "$LOG"
cp "$SP/reds-main.rs.orig" "$F"

for target in "let path = server.handler_module(id);" "fn serve_file("; do
  step "A6 red: the route after \`$target\` ignores the query"
  python3 - "$target" <<'PY'
import pathlib, sys
p = pathlib.Path("spikes/own-renderer/server/src/main.rs")
s = p.read_text()
at = s.index("cache_policy(query)", s.index(sys.argv[1]))
p.write_text(s[:at] + 'cache_policy("")' + s[at + len("cache_policy(query)"):])
PY
  cargo test --quiet --locked -p pw-dev-server -- a_production_build_serves_its_page_and_table_at_its_delivery 2>&1 | grep -E "test result|at the delivery" | cut -c1-200 >> "$LOG"
  cp "$SP/reds-main.rs.orig" "$F"
done
step "restored"
cmp -s "$F" "$SP/reds-main.rs.orig" && echo "main.rs restored" >> "$LOG"
git status --porcelain -- spikes >> "$LOG"
echo INLINE_REDS_FINISHED >> "$LOG"
