#!/usr/bin/env bash
# B2: the warm-up's live-page probe. Green on the runtime; red on the
# review's mutant (the copy's morph made on the live block); restored.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/b2-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
cd spikes/own-renderer
step "green"
PORT=13880 pnpm exec playwright test warm.spec.mjs --project=chromium --project=firefox --reporter=line > "$SP/b2-green.log" 2>&1
echo "exit green $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/b2-green.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
step "red: the warm-up morphs the live block"
cp public/pw-runtime.mjs "$SP/b2-runtime.orig"
python3 - <<'PY'
import pathlib
p = pathlib.Path("public/pw-runtime.mjs")
s = p.read_text()
line = "    morphChildren(copy, [...copy.childNodes], parseInstance(html), null, []);\n"
assert s.count(line) == 1, "anchor"
p.write_text(s.replace(line, "    morphChildren(at.start.parentNode, nodes, parseInstance(html), at.end.nextSibling, []);\n"))
PY
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/b2-run-mutant.log" 2>&1); echo "exit run.sh (mutant) $?" >> "$LOG"
PORT=13880 pnpm exec playwright test warm.spec.mjs -g "the page is as it was" --project=chromium --project=firefox --reporter=line > "$SP/b2-red.log" 2>&1
echo "exit red $? (expected non-zero)" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/b2-red.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) |live block is not morphed|Expected|Received" | head -12 >> "$LOG"
cp "$SP/b2-runtime.orig" public/pw-runtime.mjs
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/b2-run-restored.log" 2>&1); echo "exit run.sh (restored) $?" >> "$LOG"
cd "$WT"
step "restored"
git diff --stat >> "$LOG"
echo B2_VERIFY_FINISHED >> "$LOG"
