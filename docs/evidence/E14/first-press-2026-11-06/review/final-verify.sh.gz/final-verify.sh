#!/usr/bin/env bash
# The review's fixes, verified at their exact commit: the whole pre-push
# check, then each mutation script whose anchors lie in or beside the code
# the fixes changed (reached.py), run whole as its recipe runs it; then the
# sources' restoration.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/final-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "commit $(git rev-parse HEAD); uncommitted code paths: $(git status --porcelain -- . ':(exclude)docs' | wc -l)"
step "the whole pre-push check (TAG=prepush3)"
TAG=prepush3 bash "$SCRATCH/prepush-verify.sh"; echo "exit prepush3 $?" >> "$LOG"
grep -E "^exit |Running [0-9]+ tests|^\s+[0-9]+ (passed|skipped|failed|flaky)|^Ran |^OK|^FAILED|EVIDENCE|is not run" "$SP/prepush3-verify.log" >> "$LOG"
step "the apps the scripts' recipes build"
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > /dev/null 2>&1; echo "exit run.sh $?" >> "$LOG"
for s in feed kiokun-site keyed-store; do bash "spikes/own-renderer/$s.sh" > /dev/null 2>&1; echo "exit $s.sh $?" >> "$LOG"; done
for name in press_modules soft_navigation page_policy address_fragment build_id connection_faults press_order shared_output; do
  step "mutation controls: $name"
  case $name in
    page_policy|address_fragment) CARGO_INCREMENTAL=0 python3 "scripts/${name}_mutations.py" > "$SP/mut-$name.log" 2>&1 ;;
    *) python3 "scripts/${name}_mutations.py" > "$SP/mut-$name.log" 2>&1 ;;
  esac
  echo "exit $name $?" >> "$LOG"
  tail -6 "$SP/mut-$name.log" >> "$LOG"
done
step "restored"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
git status --porcelain -- . ':(exclude)docs' >> "$LOG"
echo FINAL_VERIFY_FINISHED >> "$LOG"
