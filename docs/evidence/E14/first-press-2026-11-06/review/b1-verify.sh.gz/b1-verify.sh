#!/usr/bin/env bash
# B1: a press's wait has its own deadline. Contract test, anchors, the load
# specs green; the two new tests red on the committed runtime; restored.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/b1-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "anchors, the renderer's contract"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
node --test --test-reporter=spec spikes/own-renderer/renderer-contract.test.mjs 2>&1 | grep -E "^ℹ (tests|pass|fail) |^✖ " >> "$LOG"
step "build (the fix)"
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/b1-run.log" 2>&1; echo "exit run.sh $?" >> "$LOG"
cd spikes/own-renderer
step "the load specs (the fix), chromium and firefox"
PORT=13880 pnpm exec playwright test warm.spec.mjs lazy-handler.spec.mjs press-modules.spec.mjs optimistic.spec.mjs cart.spec.mjs transport.spec.mjs recovery.spec.mjs \
  --project=chromium --project=firefox --reporter=line > "$SP/b1-green.log" 2>&1
echo "exit green $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/b1-green.log" | grep -E "is not run|^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
step "red: the committed runtime"
cp public/pw-runtime.mjs "$SP/b1-runtime.fixed"
git show HEAD:spikes/own-renderer/public/pw-runtime.mjs > public/pw-runtime.mjs
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/b1-run-old.log" 2>&1); echo "exit run.sh (old) $?" >> "$LOG"
PORT=13880 pnpm exec playwright test warm.spec.mjs -g "within a deadline of its own" --project=chromium --project=firefox --reporter=line > "$SP/b1-red.log" 2>&1
echo "exit red $? (expected non-zero)" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/b1-red.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
cp "$SP/b1-runtime.fixed" public/pw-runtime.mjs
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/b1-run-restored.log" 2>&1); echo "exit run.sh (restored) $?" >> "$LOG"
cd "$WT"
step "restored"
cmp -s spikes/own-renderer/public/pw-runtime.mjs "$SP/b1-runtime.fixed" && echo "runtime: the fix, restored" >> "$LOG"
git diff --stat >> "$LOG"
echo B1_VERIFY_FINISHED >> "$LOG"
