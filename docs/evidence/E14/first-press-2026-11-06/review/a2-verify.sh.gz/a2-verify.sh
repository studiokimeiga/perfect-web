#!/usr/bin/env bash
# A2: a soft navigation stays within one delivery. Native tests, the new
# browser test green, then red with the runtime's check removed (the mutant
# built and served as the suite serves it), then the source restored.
set -uo pipefail
source "$SCRATCH/env.sh"
LOG="$SP/a2-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "anchors"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
step "native"
cargo test --quiet --locked -p pw-dev-server -- a_production_build_serves_its_page_and_table_at_its_delivery a_host_serves_its_build_by_its_name >> "$LOG" 2>&1
echo "exit native $?" >> "$LOG"
step "build (the fix)"
cargo build --quiet --locked -p pw-cli -p pw-dev-server >> "$LOG" 2>&1; echo "exit build $?" >> "$LOG"
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/a2-run.log" 2>&1; echo "exit run.sh $?" >> "$LOG"
cd spikes/own-renderer
step "soft-navigation.spec (the fix)"
PORT=13880 pnpm exec playwright test soft-navigation.spec.mjs --project=chromium --project=firefox --reporter=line > "$SP/a2-green.log" 2>&1
echo "exit green $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/a2-green.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
step "mutant: the delivery's check removed"
cp public/pw-runtime.mjs "$SP/a2-runtime.orig"
python3 - <<'PY'
import pathlib
p = pathlib.Path("public/pw-runtime.mjs")
s = p.read_text()
line = '  if (response.headers.get("pw-delivery") !== DELIVERY) return loadWhole(at, how);\n'
assert s.count(line) == 1, "anchor"
p.write_text(s.replace(line, ""))
PY
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/a2-run-mutant.log" 2>&1); echo "exit run.sh (mutant) $?" >> "$LOG"
PORT=13880 pnpm exec playwright test soft-navigation.spec.mjs -g "another delivery" --project=chromium --project=firefox --reporter=line > "$SP/a2-red.log" 2>&1
echo "exit red $? (expected non-zero)" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/a2-red.log" | grep -E "^\s+[0-9]+ (passed|skipped|failed|flaky)|^\s+[0-9]+\) " >> "$LOG"
cp "$SP/a2-runtime.orig" public/pw-runtime.mjs
(cd "$WT" && BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/a2-run-restored.log" 2>&1); echo "exit run.sh (restored) $?" >> "$LOG"
cd "$WT"
step "restored"
git diff --stat >> "$LOG"
echo A2_VERIFY_FINISHED >> "$LOG"
