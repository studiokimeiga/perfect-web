"""stable_layout_mutations.py's mutants, each run as the script runs it, in
Chromium and Firefox only (WebKit cannot open a page on this PC). The source
is restored after each, whatever happens."""
import importlib.util
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path("/home/haki/code/pw-wt/first-press")
sys.path.insert(0, str(ROOT / "scripts"))
spec = importlib.util.spec_from_file_location("sl", ROOT / "scripts/stable_layout_mutations.py")
sl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sl)

BUILD = ["cargo", "build", "--quiet", "--locked", "-p", "pw-dev-server"]
RUN = ["pnpm", "exec", "playwright", "test", *sl.SPEC, "--project=chromium", "--project=firefox", "--reporter=line"]


def run():
    b = subprocess.run(BUILD, cwd=ROOT, capture_output=True, text=True)
    if b.returncode != 0:
        return None
    r = subprocess.run(RUN, cwd=ROOT / "spikes/own-renderer", capture_output=True, text=True, timeout=1200)
    out = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", r.stdout + r.stderr)
    passed = sum(int(n) for n in re.findall(r"^\s*(\d+) passed", out, re.M))
    failed = sum(int(n) for n in re.findall(r"^\s*(\d+) failed", out, re.M))
    return passed, failed


base = run()
print("baseline (chromium, firefox):", base, flush=True)
if not base or base[1] or not base[0]:
    sys.exit("baseline not green")
survivors = 0
for mutant in sl.MUTANTS:
    what, path, anchor, replacement = mutant[0], mutant[-3], mutant[-2], mutant[-1]
    original = path.read_text()
    if original.count(anchor) != 1:
        print(f"{what}: ANCHOR NOT FOUND ONCE")
        survivors += 1
        continue
    try:
        path.write_text(original.replace(anchor, replacement, 1))
        result = run()
    finally:
        path.write_text(original)
    if result is None:
        print(f"{what}: build failed (killed by the build)")
    elif result[1]:
        print(f"{what}: KILLED ({result[1]} of {sum(result)} tests fail)")
    else:
        print(f"{what}: SURVIVED")
        survivors += 1
print(f"survivors: {survivors} of {len(sl.MUTANTS)}")
sys.exit(1 if survivors else 0)
