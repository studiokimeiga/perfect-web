#!/usr/bin/env bash
# The mutation controls this branch re-anchored, run whole, alone in the
# worktree; then the anchor check that every source was restored.
set -uo pipefail
source /mnt/c/Users/haki/AppData/Local/Temp/claude/a3a99843d7659d2c/c2fdf789-8c40-4584-932e-eb0f5a7419a5/scratchpad/env.sh
LOG="$SP/mutations.log"
: > "$LOG"
echo "== $(date -Is) clean tree: $(git status --short | wc -l) changes" >> "$LOG"
cargo build --quiet --locked -p pw-cli -p pw-dev-server >> "$LOG" 2>&1
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/run-sh.log" 2>&1

# second_host's `assets` control by hand (its script needs two PostgreSQL
# databases): its mutant, its one test, which must fail; the source restored.
echo "== $(date -Is) second_host assets (by hand)" >> "$LOG"
python3 - >> "$LOG" 2>&1 <<'PY'
import pathlib, subprocess, sys
sys.path.insert(0, "scripts")
src = pathlib.Path("spikes/own-renderer/server/src/main.rs")
text = src.read_text()
anchor = ('    if method == "GET"\n'
          "        && matches!(\n"
          "            route,\n"
          '            "/pw-runtime.mjs" | "/pw-resume.wasm" | "/pw-render.wasm"\n'
          "        )\n"
          "    {\n"
          "        serve_file(server, &mut stream, path, &headers);\n"
          "        return;\n"
          "    }\n")
assert text.count(anchor) == 1, "anchor"
cmd = ["cargo", "test", "--quiet", "--locked", "-p", "pw-dev-server", "--bin", "pw-dev-server", "--",
       "tests::public_runtime_assets_load_while_session_authority_is_unavailable"]
base = subprocess.run(cmd, capture_output=True, text=True)
print("baseline:", base.returncode, [l for l in base.stdout.splitlines() if l.startswith("test result")])
try:
    src.write_text(text.replace(anchor, "", 1))
    mut = subprocess.run(cmd, capture_output=True, text=True)
    out = [l for l in mut.stdout.splitlines() if l.startswith("test result")]
    print("mutant:", mut.returncode, out, "KILLED" if mut.returncode != 0 and out and " 0 failed" not in out[-1] else "SURVIVED")
finally:
    src.write_text(text)
PY
for s in connection_faults_mutations.py optimistic_posts_mutations.py metadata_mutations.py stable_layout_mutations.py soft_navigation_mutations.py; do
  echo "== $(date -Is) $s" >> "$LOG"
  PORT=13900 python3 "scripts/$s" >> "$LOG" 2>&1
  echo "exit $s $?" >> "$LOG"
done
echo "== $(date -Is) anchors (restoration)" >> "$LOG"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
echo "== $(date -Is) tree: $(git status --short | wc -l) changes" >> "$LOG"
git status --short >> "$LOG"
echo MUTATIONS_FINISHED >> "$LOG"
