#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
expected="${1:?exact local review-fix commit required}"
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
git rev-parse HEAD > /tmp/pw-protected-migration/windows-review-frozen-source.txt
cargo test --locked -p pw-core --lib --test table_windows --test bounded_tables --test bounded_reads --test table_counts --test head_only > /tmp/pw-protected-migration/windows-review-frozen-core.log 2>&1
cargo test --locked -p pw-table-memory --test compiled_windows > /tmp/pw-protected-migration/windows-review-frozen-memory.log 2>&1
cargo test --locked -p pw-table-postgres --test compiled_windows > /tmp/pw-protected-migration/windows-review-frozen-pg.log 2>&1
just test-compile > /tmp/pw-protected-migration/windows-review-frozen-test-compile.log 2>&1
just preflight > /tmp/pw-protected-migration/windows-review-frozen-preflight.log 2>&1
python3 scripts/row_ownership_mutations.py 'windows repair' 'windows varying' > /tmp/pw-protected-migration/windows-review-frozen-controls.log 2>&1
python3 scripts/bounded_checker_mutations.py 'generated composite keys' > /tmp/pw-protected-migration/windows-review-frozen-bounded-controls.log 2>&1
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> /tmp/pw-protected-migration/windows-review-frozen-source.txt
echo 0 > /tmp/pw-protected-migration/windows-review-frozen.exit
