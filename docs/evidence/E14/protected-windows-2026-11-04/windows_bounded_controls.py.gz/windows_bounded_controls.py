"""Run the two moved bounded-guidance faults with strict native inventories."""
import importlib.util
from pathlib import Path
import sys

root = Path('/home/haki/code/pw-wt/data-path')
sys.path.insert(0, str(root / 'scripts'))
import cargo_assertion_results
import producer_process

spec = importlib.util.spec_from_file_location('bounded_guidance', root / 'scripts/bounded_checker_mutations.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
chosen = ['generated flat batches replace each individual read in the repair', 'generated composite keys are described as scalar keys']
module.MUTANTS = [m for m in module.MUTANTS if m[0] in chosen]
assert len(module.MUTANTS) == 2
inventory = {}
sources = [root / 'compiler/pw-core/tests/bounded_reads.rs', root / 'compiler/pw-core/tests/bounded_tables.rs']

def strict_run():
    passed = failed = 0
    for command in module.TESTS:
        child = producer_process.run([*command, '--', '--format=pretty'], cwd=root, timeout=900)
        key = tuple(command)
        result = cargo_assertion_results.validate(child.returncode, child.stdout, root=root, sources=sources, expected=inventory.get(key))
        if not result.valid:
            print(child.stdout[-4000:], flush=True)
            return False, passed, failed
        inventory.setdefault(key, cargo_assertion_results.names(child.stdout))
        passed += result.passed
        failed += result.failed
    return True, passed, failed

module.run = strict_run
sys.exit(module.main())
