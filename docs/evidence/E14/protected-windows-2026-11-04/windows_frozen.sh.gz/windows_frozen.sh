#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
expected="${1:?exact local window commit required}"
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
git rev-parse HEAD > /tmp/pw-protected-migration/windows-frozen-source.txt
cargo test --locked -p pw-core --lib --test tables --test table_counts --test table_windows --test table_owners --test bounded_reads --test bounded_tables --test invoked_by --test scheduled > /tmp/pw-protected-migration/windows-frozen-core.log 2>&1
cargo test --locked -p pw-cli --test tables > /tmp/pw-protected-migration/windows-frozen-cli.log 2>&1
cargo test --locked -p pw-host --features engine > /tmp/pw-protected-migration/windows-frozen-host.log 2>&1
cargo test --locked -p pw-table-memory > /tmp/pw-protected-migration/windows-frozen-memory.log 2>&1
cargo test --locked -p pw-table-postgres > /tmp/pw-protected-migration/windows-frozen-pg.log 2>&1
cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::protected_migration:: identity:: tests::store_accounts:: tests::sign_in:: tests::tables:: tests::conformance:: tests::tables_pg:: tests::second_host:: > /tmp/pw-protected-migration/windows-frozen-server.log 2>&1
just test-compile > /tmp/pw-protected-migration/windows-frozen-test-compile.log 2>&1
just preflight > /tmp/pw-protected-migration/windows-frozen-preflight.log 2>&1
python3 scripts/d3_postgres_mutations.py windows counts > /tmp/pw-protected-migration/windows-frozen-pg-controls.log 2>&1
python3 scripts/row_ownership_mutations.py windows counts "a set form's handle" > /tmp/pw-protected-migration/windows-frozen-row-controls.log 2>&1
python3 scripts/data_path_mutations.py windows "count aggregate" > /tmp/pw-protected-migration/windows-frozen-data-controls.log 2>&1
python3 scripts/table_host_mutations.py "a get-many may answer" > /tmp/pw-protected-migration/windows-frozen-table-host-controls.log 2>&1
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> /tmp/pw-protected-migration/windows-frozen-source.txt
echo 0 > /tmp/pw-protected-migration/windows-frozen.exit
