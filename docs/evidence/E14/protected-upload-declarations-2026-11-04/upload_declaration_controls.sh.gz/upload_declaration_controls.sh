#!/bin/bash
set -euo pipefail
cd /home/haki/code/pw-wt/data-path
source /home/haki/pw-setup/env.sh
expected=a1f4b2dc848ddb3502430cb89f4a46a741bdad58
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration/upload_declaration_controls.py > /tmp/pw-protected-migration/upload-declaration-controls.log 2>&1
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'strict controls source guard: clean' >> /tmp/pw-protected-migration/upload-declaration-source.txt
echo 0 > /tmp/pw-protected-migration/upload-declaration-controls.exit
