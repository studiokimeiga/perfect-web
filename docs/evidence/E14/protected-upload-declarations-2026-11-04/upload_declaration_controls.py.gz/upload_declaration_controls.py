"""Strict native controls for the frozen declaration stage; restore every byte."""
from pathlib import Path
import sys, json, hashlib, importlib.util
root=Path('/home/haki/code/pw-wt/data-path')
sys.path.insert(0,str(root/'scripts'))
import cargo_assertion_results, producer_process
declaration='compiler/pw-core/src/uploads/declared.rs'
assets='compiler/pw-core/src/tables/assets.rs'
mutants=[
 ('upload resource capability omitted',declaration,'        if let Some(resource) = resource {','        if let Some(resource) = resource.filter(|_| false) {'),
 ('upload private visibility lost',declaration,'        decl.visibility = visibility.clone();','        decl.visibility = visibility.clone().filter(|_| false);'),
 ('upload generated identity collision silent',declaration,'            !hir.generated_uploads.contains_key(&other) && crate::wit::ident(&decl.name) == identity','            false && !hir.generated_uploads.contains_key(&other) && crate::wit::ident(&decl.name) == identity'),
 ('upload interface alias silent',declaration,'                && other.name != d.name','                && false && other.name != d.name'),
 ('upload claim consuming command lacks receipt',declaration,'d.kind == DeclKind::Command && d.policy("idempotent_by").is_none()','d.kind == DeclKind::Command && false && d.policy("idempotent_by").is_none()'),
 ('asset source mismatch silent',assets,'        if source.is_none() || source != target_source {','        if false && (source.is_none() || source != target_source) {'),
 ('asset owned table accepted',assets,'        if t.owner.is_some() || !t.sharers().is_empty() || !t.private_fields().is_empty() {','        if false && (t.owner.is_some() || !t.sharers().is_empty() || !t.private_fields().is_empty()) {'),
 ('asset nominal declaration ignored',assets,'        if field.def_id() != reference || !field.args().is_empty() {','        if false && (field.def_id() != reference || !field.args().is_empty()) {'),
 ('asset mandatory binding omitted',assets,'            if !t.assets.iter().any(|asset| asset.value.field == *field) {','            if false && !t.assets.iter().any(|asset| asset.value.field == *field) {'),
 ('asset claim escape accepted',assets,'            contains_kind(hirs, sigs, ty, &mut BTreeSet::new(), GeneratedKind::Claim)','            false && contains_kind(hirs, sigs, ty, &mut BTreeSet::new(), GeneratedKind::Claim)'),
 ('upload pure URI key and kind swapped',declaration,'            parts: vec![key, suffix],','            parts: vec![suffix, key],'),
 ('upload imports owned by application','compiler/pw-core/src/backend/mod.rs','    let binding = match [PLATFORM_PACKAGE, TABLES_PACKAGE, UPLOADS_PACKAGE]','    let binding = match [PLATFORM_PACKAGE, TABLES_PACKAGE]'),
]
for campaign,label in [('tables','table imports belong to the app instead of the platform'),('bounded_checker','`set` and `sets` head a clause wherever they are written')]:
 spec=importlib.util.spec_from_file_location(campaign,root/f'scripts/{campaign}_mutations.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 item=next(m for m in module.MUTANTS if m[0]==label)
 mutants.append((item[0],str(item[1].relative_to(root)),item[2],item[3]))
tests=[['cargo','test','--quiet','--locked','-p','pw-core','--test','table_assets'],['cargo','test','--quiet','--locked','-p','pw-table-memory','--test','compiled_assets'],['cargo','test','--quiet','--locked','-p','pw-core','--test','tables'],['cargo','test','--quiet','--locked','-p','pw-cli','--test','tables'],['cargo','test','--quiet','--locked','-p','pw-core','--test','bounded_reads'],['cargo','test','--quiet','--locked','-p','pw-core','--test','bounded_tables']]
sources=sorted((root/'compiler').rglob('*.rs'))+sorted((root/'runtime/pw-table-memory').rglob('*.rs'))
out=Path('/tmp/pw-protected-migration/upload-declaration-strict');out.mkdir(exist_ok=True)
inventories={}
def run(number,indices):
 failed=passed=0
 for index in indices:
  cmd=tests[index]+['--','--format=pretty','--test-threads=2']
  child=producer_process.run(cmd,cwd=root,timeout=1200)
  receipt=out/f'run-{number:02}-{index:02}.log';receipt.write_text(child.stdout)
  result=cargo_assertion_results.validate(child.returncode,child.stdout,root=root,sources=sources,expected=inventories.get(index))
  receipt.with_suffix('.json').write_text(json.dumps({'command':cmd,'exit':child.returncode,'valid':result.valid,'passed':result.passed,'failed':result.failed,'sha256':hashlib.sha256(child.stdout.encode()).hexdigest()},indent=2))
  if not result.valid: raise RuntimeError(f'invalid native producer {receipt}: '+child.stdout[-3000:])
  inventories.setdefault(index,cargo_assertion_results.names(child.stdout))
  passed+=result.passed;failed+=result.failed
 return passed,failed
passed,failed=run(0,range(len(tests)));assert failed==0
print(f'baseline {passed} native assertions, complete inventories',flush=True)
for n,(label,path,before,after) in enumerate(mutants,1):
 file=root/path;original=file.read_bytes();source=original.decode()
 assert source.count(before)==1,(label,source.count(before))
 try:
  file.write_text(source.replace(before,after))
  indices=[1] if 'URI' in label else ([2,3] if n==len(mutants)-1 else ([4,5] if n==len(mutants) else [0]))
  passed,failed=run(n,indices)
  assert failed>0,f'survived: {label}'
  print(f'KILLED {n}/{len(mutants)}: {label}; {passed} pass/{failed} fail',flush=True)
 finally: file.write_bytes(original)
print(f'controls: {len(mutants)}/{len(mutants)} killed; no invalid or stopped producer',flush=True)
