from pathlib import Path
import gzip,hashlib,re,subprocess
root=Path('/home/haki/code/pw-wt/data-path');logs=Path('/tmp/pw-protected-migration')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='a1f4b2dc848ddb3502430cb89f4a46a741bdad58'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
assert (logs/'upload-declaration.exit').read_text().strip()=='0'
assert (logs/'upload-declaration-controls.exit').read_text().strip()=='0'
assert '14/14 killed' in (logs/'upload-declaration-controls.log').read_text()
out=root/'docs/evidence/E14/protected-upload-declarations-2026-11-04';assert not out.exists();out.mkdir()
items=list(logs.glob('upload-declaration-*.log'))+list(logs.glob('upload-declaration-*.txt'))+list(logs.glob('upload-declaration*.exit'))+list((logs/'upload-declaration-strict').glob('*'))
for p in items:
 name=('strict-'+p.name) if p.parent.name=='upload-declaration-strict' else p.name
 (out/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
helper=Path('/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration')
for name in ['upload_declaration_frozen.sh','upload_declaration_controls.py','upload_declaration_controls.sh','upload_declaration_record.py']:
 (out/(name+'.gz')).write_bytes(gzip.compress((helper/name).read_bytes(),mtime=0))
counts={kind:sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed', (logs/f'upload-declaration-{kind}.log').read_text())) for kind in ['core','memory','pg']}
(out/'review.txt').write_text('Immutable separate review of 6426ff73: no blocking production finding; generated attached proof gap identified. Test-only successor a1f4b2dc adds actual attached import, signature and independent exact read grant assertions; re-review CLEAR. Generic storage, lifetime and HTTP remain unproved.\n')
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir())))
record=root/'docs/diagnostics/protected-upload-declarations-2026-11-04.md'
record.write_text(f'''# Generic upload declarations: local prerequisite

Frozen source a1f4b2dc848ddb3502430cb89f4a46a741bdad58, clean before/after.
This closes declaration-stage checks only. Canonical feed/store still use legacy
layers; generic storage, lifetime, HTTP and full app-port gates remain pending.

Native checks: selected compiler {counts['core']}, memory {counts['memory']},
actual configured PostgreSQL {counts['pg']}, and just preflight passed. The
strict control baseline contains 95 native assertions across six complete
inventories. All 14 controls failed at native assertion sites; no stopped or
invalid producer counted. Controls cover resource grants, visibility, emitted
identities, idempotency, source/public/nominal asset associations, required
bindings, claim storage escape, pure URL output and the two moved old anchors.
The first attempted idempotency mutation only disabled acquire while leaving
release active due to operator precedence; it survived and was corrected before
the complete retained run. No production fix was inferred from that bad fault.

Generated attached is actually imported and its semantic ABI, read grant and
absence of resource grant asserted. This does not yet prove runtime hook ABI.
Memory/PostgreSQL still refuse asset tables without an actual upload binding.
Their guard-removal control is deferred until the otherwise-supported Ref.kind
wire encoding exists, to avoid treating a second unrelated rejection as proof.

Separate immutable review of declaration code and attached test repair is clear.
Reproduce using the byte-preserving frozen/control scripts under the
[evidence directory](../evidence/E14/protected-upload-declarations-2026-11-04/).
All raw per-binary outputs, native validator JSON and source/restoration guards
are gzip archived there; SHA256SUMS covers every archived input.
''')
status=root/'docs/STATUS.md';s=status.read_text();needle='Earlier green records below apply to their named sources only.';assert s.count(needle)==1
s=s.replace(needle,'''Generic upload declaration source `a1f4b2dc` passed frozen selected compiler
checks, memory/PostgreSQL and preflight, plus 14/14 strict declaration controls;
separate immutable review is clear. The old asset storage guards remain closed.
See the [declaration record](diagnostics/protected-upload-declarations-2026-11-04.md).
'''+needle);status.write_text(s)
print(counts)
