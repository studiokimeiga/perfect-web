#!/bin/bash
set -euo pipefail
cd /home/haki/code/pw-wt/data-path
source /home/haki/pw-setup/env.sh
expected=a1f4b2dc848ddb3502430cb89f4a46a741bdad58
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
log=/tmp/pw-protected-migration
git rev-parse HEAD > "$log/upload-declaration-source.txt"
run() { local name="$1"; shift; echo "starting $name"; "$@" > "$log/upload-declaration-$name.log" 2>&1; echo "$name passed"; }
run core cargo test --locked -p pw-core --lib --test table_assets --test uploads --test tables --test table_relations --test capability_argument --test data_sources --test effect_resolution --test effective_effects --test resource_clauses --test matched_resources --test boundary_matrix
run memory cargo test --locked -p pw-table-memory
run pg cargo test --locked -p pw-table-postgres
run preflight just preflight
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> "$log/upload-declaration-source.txt"
echo 0 > "$log/upload-declaration.exit"
echo 'upload declaration checks and source guard passed'
