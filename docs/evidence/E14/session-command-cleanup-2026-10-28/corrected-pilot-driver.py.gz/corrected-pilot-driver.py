import gzip,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
root=Path('/home/haki/code/pw-wt/session-followup-20261027');work=Path('/mnt/c/Users/haki/Documents/Codex/2026-10-26/con/work')
out=work/'session-command-cleanup-working-fault-pilot-corrected';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'scripts'));import mutation_source,producer_process
source=root/'scripts/session_command_mutations.py';original=source.read_text();sha=lambda raw:hashlib.sha256(raw).hexdigest()
cmd=['python3','-m','unittest','-v','scripts/tests/test_session_command_mutations.py'];rows=[];completed=[];valid=False;problem=None
test_source=root/'scripts/tests/test_session_command_mutations.py'

def run(label,target=None,only=False):
    owned=[]
    command=cmd if not only else cmd[:-1]+['scripts.tests.test_session_command_mutations.SessionCommandProducer.'+target]
    inputs={'producer':source.read_bytes(),'tests':test_source.read_bytes()}
    for name,raw in inputs.items():(out/(label+'.'+name+'.py.gz')).write_bytes(gzip.compress(raw,mtime=0))
    with tempfile.TemporaryDirectory(prefix='pw-command-cleanup-bytecode-') as cache:
        environment={**os.environ,'PYTHONPYCACHEPREFIX':cache,'PYTHONDONTWRITEBYTECODE':'1'}
        result=producer_process.run(command,cwd=root,timeout=60,grace=2,env=environment,
            on_reaped=lambda pid,status,timed_out,cancelled:owned.append({'pid':pid,'status':status,'timed_out':timed_out,'cancelled':cancelled}))
        if list(Path(cache).rglob('*.pyc')):raise RuntimeError('unexpected bytecode publication')
    if source.read_bytes()!=inputs['producer'] or test_source.read_bytes()!=inputs['tests']:raise RuntimeError('input changed during native run')
    text=result.stdout;raw=text.encode();(out/(label+'.log')).write_bytes(raw)
    count=1 if only else 17
    row={'label':label,'command':command,'tests_selected':count,'status':result.returncode,'log_sha256':sha(raw),'owned_reaped':owned,
         'producer_sha256':sha(inputs['producer']),'test_source_sha256':sha(inputs['tests']),'fresh_empty_owned_bytecode_prefix':True,'bytecode_writes_disabled':True}
    rows.append(row)
    if f'Ran {count} test' not in text or 'skipped' in text or 'ERROR:' in text:raise RuntimeError('incomplete/invalid native calibration')
    if target:
        if result.returncode!=1 or 'FAILED (failures=1)' not in text or ('FAIL: '+target) not in text or 'AssertionError:' not in text:raise RuntimeError('wrong calibration failure')
    elif result.returncode!=0:raise RuntimeError('baseline not green')

try:
    run('baseline')
    prior=subprocess.check_output(['git','show','5371f0f20d7fcb50826d3a775b5bbac72c1b14b0:scripts/session_command_mutations.py'],cwd=root).decode()
    with mutation_source.changed(source,original,prior):
        run('original-source-privacy-subset','test_cleanup_discards_child_stderr_before_retaining_logs',only=True)
    completed.append('original-source-privacy-subset')
    for label,anchor,replacement,target in [
        ('cleanup-stderr-restored','                              suppress_stderr=True)\n','                              suppress_stderr=False)\n','test_cleanup_discards_child_stderr_before_retaining_logs'),
        ('native-stderr-discarded','stderr=subprocess.DEVNULL if suppress_stderr else subprocess.STDOUT)\n','stderr=subprocess.DEVNULL if suppress_stderr else subprocess.DEVNULL)\n','test_ordinary_native_process_still_retains_stderr_diagnostics'),
    ]:
        if original.count(anchor)!=1:raise RuntimeError('calibration source anchor differs')
        with mutation_source.changed(source,original,original.replace(anchor,replacement,1)):
            run(label,target)
        if source.read_text()!=original:raise RuntimeError('source not restored')
        completed.append(label)
    valid=True
except BaseException as error:
    problem=type(error).__name__
    raise
finally:
    if source.read_text()!=original:raise RuntimeError('source restoration failed')
    run('restored-baseline')
    (out/'report.json').write_text(json.dumps({'scope':'WORKING SOURCE one original-source privacy testcase SUBSET1/17 plus two privacy/native-diagnostic calibration controls over all17; not full26 command authority acceptance',
        'parent_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'source_sha256':sha(original.encode()),'tests':17,'selected_fault_controls':2,'completed':completed,'valid':valid,'error':problem,'restored':True,'runs':rows},indent=2)+'\n')
print('working17-test baseline/restored green; two source faults earn one intended assertion failure each')
