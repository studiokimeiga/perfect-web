"""Owned two-database fixture; never stores configured connection values."""
import hashlib,json,os,re,subprocess,sys,uuid
from pathlib import Path
root=Path('/home/haki/code/pw-wt/session-followup-20261027');work=Path('/mnt/c/Users/haki/Documents/Codex/2026-10-26/con/work')
out=work/'session-command-cleanup-working-real-pg-neighbors';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'scripts'));import session_command_mutations as gate
sha=lambda raw:hashlib.sha256(raw).hexdigest()
urls={kind:os.environ['PW_'+kind.upper()+'_DATABASE_URL'] for kind in ['feed','store']}
if len(set(urls.values()))!=2:raise RuntimeError('two distinct configured fixture databases required')
schemas={kind:'pw_session_'+kind+'_'+uuid.uuid4().hex[:16] for kind in urls}
if not all(re.fullmatch(r'pw_session_(feed|store)_[0-9a-f]{16}',name) for name in schemas.values()):raise RuntimeError('unsafe owned name')
receipt=out/'owned.txt';receipt.write_text(''.join(name+'\n' for name in schemas.values()))
source=(root/'scripts/session_command_mutations.py').read_bytes();source_sha=sha(source)
(out/'source-before.py.gz').write_bytes(__import__('gzip').compress(source,mtime=0))
records=[];created=[];success=False;answer={}

def owned(kind,label,sql):
    cmd=['psql','--no-psqlrc','--tuples-only','--no-align','--dbname',urls[kind],'--command',sql]
    public=[value if value!=urls[kind] else '<configured PW_'+kind.upper()+'_DATABASE_URL>' for value in cmd]
    reaped=[]
    try:
        child=gate.producer_process.run(cmd,cwd=root,timeout=30,stderr=subprocess.DEVNULL,
            on_reaped=lambda pid,status,timed_out,cancelled:reaped.append({'pid':pid,'status':status,'timed_out':timed_out,'cancelled':cancelled}))
    except subprocess.TimeoutExpired:
        raise RuntimeError('owned fixture process timed out') from None
    raw=child.stdout.encode();path=out/(label+'-'+kind+'.log');path.write_bytes(raw)
    records.append({'kind':kind,'label':label,'command':public,'status':child.returncode,'log':path.name,'log_sha256':sha(raw),'reaped':reaped,'stderr_policy':'discarded at child launch'})
    if child.returncode!=0:raise RuntimeError('owned fixture command failed: '+label+'-'+kind)
    return child.stdout

try:
    for kind,name in schemas.items():
        if owned(kind,'before',"SELECT nspname FROM pg_catalog.pg_namespace WHERE nspname = '"+name+"'")!='':raise RuntimeError('fresh fixture name already exists')
        owned(kind,'create','CREATE SCHEMA "'+name+'"');created.append(kind)
    env={**os.environ}
    present=gate.cleanup(receipt,2,out,'present',env)
    (out/'present.result.json').write_text(json.dumps(present,indent=2)+'\n')
    if present['valid'] or any(present['checks'][kind]['status']!=0 for kind in schemas):raise RuntimeError('existing owned schemas were accepted as absent')
    if any((out/('present.cleanup-'+kind+'.log')).read_text()!=schemas[kind]+'\n' for kind in schemas):raise RuntimeError('fixed SELECT stdout was not retained')
    for kind in list(created):
        owned(kind,'drop','DROP SCHEMA "'+schemas[kind]+'"');created.remove(kind)
    absent=gate.cleanup(receipt,2,out,'absent',env)
    (out/'absent.result.json').write_text(json.dumps(absent,indent=2)+'\n')
    if not absent['valid'] or any(absent['checks'][kind]['status']!=0 or (out/('absent.cleanup-'+kind+'.log')).read_text()!='' for kind in schemas):raise RuntimeError('absent owned schemas were refused')
    answer={'present_refused':True,'present_exact_stdout_retained':True,'absent_accepted':True,'configured_database_count':2,'owned_schemas':schemas}
    success=True
finally:
    for kind in list(created):
        owned(kind,'emergency-drop','DROP SCHEMA "'+schemas[kind]+'"');created.remove(kind)
    for kind,name in schemas.items():
        if owned(kind,'final-absence',"SELECT nspname FROM pg_catalog.pg_namespace WHERE nspname = '"+name+"'")!='':raise RuntimeError('owned schema remains')
    if sha((root/'scripts/session_command_mutations.py').read_bytes())!=source_sha:raise RuntimeError('source changed during fixture')
    for path in out.iterdir():
        if path.is_file() and any(value.encode() in path.read_bytes() for value in urls.values()):raise RuntimeError('configured connection value in proof')
    proof={'scope':'WORKING SOURCE two-database owned-schema neighbor only; no full26 or exact-parent credit','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
           'source_sha256':source_sha,'success':success,'neighbors':answer,'owned_process_records':records,'source_unchanged':True,'actual_endpoint_values_saved':False}
    (out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('actual two-database neighbors passed: owned rows refused, later absence accepted; only both newly created fixture schemas dropped')
