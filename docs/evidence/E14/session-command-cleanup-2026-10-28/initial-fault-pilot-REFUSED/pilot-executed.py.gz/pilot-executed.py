import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/home/haki/code/pw-wt/session-followup-20261027');work=Path('/mnt/c/Users/haki/Documents/Codex/2026-10-26/con/work')
out=work/'session-command-cleanup-working-fault-pilot';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'scripts'));import mutation_source,producer_process
source=root/'scripts/session_command_mutations.py';original=source.read_text();sha=lambda raw:hashlib.sha256(raw).hexdigest()
cmd=['python3','-m','unittest','-v','scripts/tests/test_session_command_mutations.py'];rows=[]

def run(label,target=None):
    owned=[]
    result=producer_process.run(cmd,cwd=root,timeout=60,grace=2,
        on_reaped=lambda pid,status,timed_out,cancelled:owned.append({'pid':pid,'status':status,'timed_out':timed_out,'cancelled':cancelled}))
    text=result.stdout;raw=text.encode();(out/(label+'.log')).write_bytes(raw)
    row={'label':label,'command':cmd,'status':result.returncode,'log_sha256':sha(raw),'owned_reaped':owned}
    rows.append(row)
    if 'Ran 17 tests' not in text or 'skipped' in text or 'ERROR:' in text:raise RuntimeError('incomplete/invalid native calibration')
    if target:
        if result.returncode!=1 or 'FAILED (failures=1)' not in text or ('FAIL: '+target) not in text or 'AssertionError:' not in text:raise RuntimeError('wrong calibration failure')
    elif result.returncode!=0:raise RuntimeError('baseline not green')

try:
    run('baseline')
    for label,anchor,replacement,target in [
        ('cleanup-stderr-restored','                              suppress_stderr=True)\n','                              suppress_stderr=False)\n','test_cleanup_discards_child_stderr_before_retaining_logs'),
        ('native-stderr-discarded','stderr=subprocess.DEVNULL if suppress_stderr else subprocess.STDOUT)\n','stderr=subprocess.DEVNULL if suppress_stderr else subprocess.DEVNULL)\n','test_ordinary_native_process_still_retains_stderr_diagnostics'),
    ]:
        if original.count(anchor)!=1:raise RuntimeError('calibration source anchor differs')
        with mutation_source.changed(source,original,original.replace(anchor,replacement,1)):
            run(label,target)
        if source.read_text()!=original:raise RuntimeError('source not restored')
finally:
    if source.read_text()!=original:raise RuntimeError('source restoration failed')
    run('restored-baseline')
    (out/'report.json').write_text(json.dumps({'scope':'WORKING SOURCE two privacy/native-diagnostic calibration controls only, not full26 command authority acceptance',
        'parent_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'source_sha256':sha(original.encode()),'tests':17,'controls':2,'restored':True,'runs':rows},indent=2)+'\n')
print('working17-test baseline/restored green; two source faults earn one intended assertion failure each')
