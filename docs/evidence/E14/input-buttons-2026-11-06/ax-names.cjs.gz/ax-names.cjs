// What each engine names the input buttons in buttons.html.
//
// Chromium: its native accessibility tree, over CDP (Accessibility domain).
// Every engine: Playwright's own name computation (locator.ariaSnapshot),
// which is one JavaScript implementation run in each engine's DOM, and
// page.accessibility where this Playwright still has it (the engine's own
// accessibility tree).
//
// usage: node ax-names.cjs <absolute path to buttons.html>
const pw = require(
  "/home/haki/code/perfect-web/node_modules/.pnpm/@playwright+test@1.58.0/node_modules/@playwright/test",
);

async function main() {
  const file = process.argv[2];
  console.log(`playwright: ${require("/home/haki/code/perfect-web/node_modules/.pnpm/@playwright+test@1.58.0/node_modules/@playwright/test/package.json").version}`);
  for (const [label, engine] of [["chromium", pw.chromium], ["firefox", pw.firefox], ["webkit", pw.webkit]]) {
    const browser = await engine.launch();
    const page = await browser.newPage();
    await page.goto("file://" + file);
    console.log(`\n== ${label} ${browser.version()}`);
    const ids = await page.$$eval("input", (els) => els.map((e) => e.id));
    let native = null;
    if (label === "chromium") {
      const cdp = await page.context().newCDPSession(page);
      const { root } = await cdp.send("DOM.getDocument", { depth: -1 });
      native = {};
      for (const id of ids) {
        const { nodeId } = await cdp.send("DOM.querySelector", { nodeId: root.nodeId, selector: "#" + id });
        const { nodes } = await cdp.send("Accessibility.getPartialAXTree", { nodeId, fetchRelatives: false });
        native[id] = nodes[0].name ? nodes[0].name.value : null;
      }
    }
    console.log(`${"input".padEnd(20)} ${"native (CDP)".padEnd(22)} playwright's computation`);
    for (const id of ids) {
      const aria = (await page.locator("#" + id).ariaSnapshot()).trim();
      const n = native ? JSON.stringify(native[id]) : "-";
      console.log(`${id.padEnd(20)} ${n.padEnd(22)} ${aria}`);
    }
    await browser.close();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
