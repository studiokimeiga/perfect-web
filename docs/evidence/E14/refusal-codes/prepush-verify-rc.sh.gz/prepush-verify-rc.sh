#!/usr/bin/env bash
# Before the first push (AGENTS.md "Before submitting or merging a PR", item 2),
# at the exact commit: `just preflight`, `just evidence-gates`, the affected
# crates' tests, every own-renderer app built with this runtime, the whole
# own-renderer browser suite in Chromium and Firefox, and the runtime-size
# gates. One step after another, so no browser timing competes with cargo.
set -uo pipefail
source "$SCRATCH/env-rc.sh"
TAG="${TAG:-prepush}"
LOG="$SP/$TAG-verify.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "commit $(git rev-parse HEAD); uncommitted paths: $(git status --porcelain | wc -l)"
git status --porcelain >> "$LOG"
echo "just: $(command -v just) $(just --version 2>&1)" >> "$LOG"
echo "rust: $(rustc --version); node: $(node --version)" >> "$LOG"
echo "dev servers already running: $(pgrep -fc 'pw-dev-server|dev-server ' || true)" >> "$LOG"

step "just preflight"
just preflight > "$SP/$TAG-preflight.log" 2>&1; echo "exit preflight $?" >> "$LOG"
tail -5 "$SP/$TAG-preflight.log" >> "$LOG"

step "just evidence-gates"
just evidence-gates > "$SP/$TAG-evidence-gates.log" 2>&1; echo "exit evidence-gates $?" >> "$LOG"
grep -E "^Ran [0-9]+ tests|^OK|^FAILED|^# (tests|pass|fail)" "$SP/$TAG-evidence-gates.log" >> "$LOG"

step "cargo test: pw-render, pw-render-wasm, pw-dev-server"
cargo test --locked --no-fail-fast -p pw-render -p pw-render-wasm -p pw-dev-server > "$SP/$TAG-cargo-test.log" 2>&1
echo "exit cargo test $?" >> "$LOG"
grep -E "^test result|FAILED|panicked at" "$SP/$TAG-cargo-test.log" >> "$LOG"

step "builds: the CLI, the servers (pw-dev-server, kiokun-server), then every own-renderer app"
cargo build --quiet --locked -p pw-cli -p pw-dev-server -p kiokun-server >> "$LOG" 2>&1; echo "exit build $?" >> "$LOG"
BUILD_ONLY=1 bash spikes/own-renderer/run.sh > "$SP/$TAG-run.log" 2>&1; echo "exit run.sh $?" >> "$LOG"
for s in todomvc keyed-store feed guestbook kiokun-site; do
  bash "spikes/own-renderer/$s.sh" > "$SP/$TAG-$s.log" 2>&1; echo "exit $s.sh $?" >> "$LOG"
done
echo "delivery.json in development builds: $(ls spikes/own-renderer/dist*/delivery.json 2>/dev/null | tr '\n' ' ')" >> "$LOG"

cd spikes/own-renderer
step "the whole own-renderer suite (chromium, firefox)"
PORT=13880 pnpm exec playwright test --project=chromium --project=firefox --reporter=line > "$SP/$TAG-specs.log" 2>&1
echo "exit specs $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/$TAG-specs.log" \
  | grep -E "is not run|^\s+[0-9]+\) |^\s+[0-9]+ (passed|skipped|failed|flaky|did not run|interrupted)|Running [0-9]+ tests" >> "$LOG"

step "runtime size (gates 7b, 7d)"
PORT=13880 pnpm exec playwright test runtime-size.spec.mjs --project=chromium --workers=1 --reporter=line > "$SP/$TAG-size.log" 2>&1
echo "exit runtime-size $?" >> "$LOG"
sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$SP/$TAG-size.log" | grep -h "EVIDENCE interactive\|EVIDENCE renderer\|passed\|failed" >> "$LOG"
cd "$WT"

step "tree after"
git status --porcelain >> "$LOG"
echo PREPUSH_VERIFY_FINISHED >> "$LOG"
