#!/usr/bin/env bash
# The refusal codes (6edb530a), verified at their exact commit: the Fallow
# audit as CI runs it against the PR's base (14a3a7f6), the whole pre-push
# check, the change's own recipe (`just e14-refusal-codes`, which writes its
# evidence and runs its mutation controls), then every other mutation script
# the change reaches (`reached.py 14a3a7f6`), each run whole.
set -uo pipefail
source "$SCRATCH/env-rc.sh"
LOG="$SP/final-verify-rc.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "commit $(git rev-parse HEAD); uncommitted code paths: $(git status --porcelain -- . ':(exclude)docs' | wc -l)"
step "fallow audit (fallow 3.23.0, gate new-only, against 14a3a7f6, as CI runs it)"
npx -y fallow@3.23.0 audit --root . --quiet --format json \
  --changed-since 14a3a7f64f22165f0fc596f8c24e4cd9b0bf1de9 --gate new-only > "$SP/fallow-rc.json" 2>/dev/null
echo "exit fallow $?" >> "$LOG"
python3 - "$SP/fallow-rc.json" >> "$LOG" <<'EOF'
import json, sys
d = json.load(open(sys.argv[1]))
print("verdict", d["verdict"], json.dumps(d["attribution"]))
for f in d["complexity"]["findings"]:
    if f.get("introduced"):
        print("introduced", f["path"], f["name"], f["line"], f["cyclomatic"], f["exceeded"])
EOF
step "reached mutation scripts (reached.py 14a3a7f6 3)"
python3 "$SP/reached.py" 14a3a7f6 3 > "$SP/rc-reached.txt" 2>&1
cat "$SP/rc-reached.txt" >> "$LOG"
step "the whole pre-push check (TAG=rc1)"
TAG=rc1 bash "$SCRATCH/prepush-verify-rc.sh"; echo "exit rc1 $?" >> "$LOG"
grep -E "^exit |Running [0-9]+ tests|^\s+[0-9]+ (passed|skipped|failed|flaky)|^Ran |^OK|^FAILED|EVIDENCE|is not run|test result: ok. 8" "$SP/rc1-verify.log" >> "$LOG"
step "just e14-refusal-codes (its evidence and its mutation controls)"
just e14-refusal-codes > "$SP/rc-recipe.log" 2>&1; echo "exit recipe $?" >> "$LOG"
cat "$SP/rc-recipe.log" >> "$LOG"
for s in $(sed -n 's/^\([a-z_0-9]*\)_mutations\.py: .*/\1/p' "$SP/rc-reached.txt"); do
  [ "$s" = refusal_codes ] && continue
  step "mutation controls: $s"
  CARGO_INCREMENTAL=0 python3 "scripts/${s}_mutations.py" > "$SP/rc-mut-$s.log" 2>&1
  echo "exit $s $?" >> "$LOG"
  grep -E "KILLED|SURVIVED|REFUSED|DID NOT BUILD|mutants killed" "$SP/rc-mut-$s.log" >> "$LOG"
done
step "restored"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
git status --porcelain -- . ':(exclude)docs' >> "$LOG"
echo FINAL_VERIFY_RC_FINISHED >> "$LOG"
