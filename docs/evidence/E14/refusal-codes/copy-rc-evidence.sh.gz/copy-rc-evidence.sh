#!/usr/bin/env bash
# The refusal codes' whole check, copied into the branch's evidence
# (`docs/evidence/E14/refusal-codes/`): the run that failed at 6edb530a
# (`run1-*`), the green run at the head, the long logs compressed, the scripts
# that ran them beside them, and SHA256SUMS over everything but the README.
set -euo pipefail
SP=/mnt/c/Users/haki/AppData/Local/Temp/claude/a3a99843d7659d2c/c2fdf789-8c40-4584-932e-eb0f5a7419a5/scratchpad
OWN=/mnt/c/Users/haki/AppData/Local/Temp/claude/2fa9113b97a63953/ed6a007c-73b2-4125-864d-2fde8498d637/scratchpad
WT=/home/haki/code/pw-wt/refusal-codes
OUT="$WT/docs/evidence/E14/refusal-codes"
mkdir -p "$OUT"
strip() { sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$1"; }
small() { strip "$SP/$1" > "$OUT/$1"; }
large() { strip "$SP/$1" | gzip -9n > "$OUT/$1.gz"; }
# The run at 6edb530a, stopped after its one failure.
small run1-final-verify-rc.log
small run1-rc1-verify.log
large run1-rc1-evidence-gates.log
# The run at the head.
small final-verify-rc.log
small rc1-verify.log
small rc1-size.log
for f in rc1-preflight.log rc1-evidence-gates.log rc1-cargo-test.log rc1-specs.log rc-recipe.log; do large "$f"; done
gzip -9nc "$SP/fallow-rc.json" > "$OUT/fallow-rc.json.gz"
for f in final-verify-rc.sh prepush-verify-rc.sh env-rc.sh reached.py; do gzip -9nc "$SP/$f" > "$OUT/$f.gz"; done
gzip -9nc "$OWN/copy-rc-evidence.sh" > "$OUT/copy-rc-evidence.sh.gz"
cd "$OUT"
find . -type f ! -name README.md ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
echo "copied: $(ls | wc -l) files; SHA256SUMS lines: $(wc -l < SHA256SUMS)"
