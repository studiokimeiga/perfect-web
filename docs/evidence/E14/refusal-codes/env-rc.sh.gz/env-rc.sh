# Source me: the toolchain environment for the refusal-codes worktree.
export PATH="$HOME/.nvm/versions/node/v22.21.1/bin:$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
export WT=/home/haki/code/pw-wt/refusal-codes
export CARGO_TARGET_DIR=/home/haki/pw-targets/refusal-codes
export SP=/mnt/c/Users/haki/AppData/Local/Temp/claude/a3a99843d7659d2c/c2fdf789-8c40-4584-932e-eb0f5a7419a5/scratchpad
export PORT=13780
cd "$WT"
