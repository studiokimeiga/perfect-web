"""Owned working-tree diagnostics; never exact-commit gate acceptance."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import types

root = Path('/home/haki/code/pw-wt/session-followup-20261027')
work = Path(__file__).resolve().parent
head = 'eb28ac01946367cff453000eed4d39e83beacd9b'
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out = work / ('session-followup-renderer-broad-' + stamp)
out.mkdir(exist_ok=False)
def git(*args): return subprocess.check_output(['git', *args], cwd=root)
def sha(raw): return hashlib.sha256(raw).hexdigest()
if git('rev-parse','HEAD').decode().strip() != head:
    raise RuntimeError('Unexpected baseline head')
new = ['spikes/own-renderer/renderer-fault.mjs', 'spikes/own-renderer/renderer-contract.test.mjs',
       'scripts/tests/test_renderer_contract.py']
def inputs():
    names = [p.decode() for p in git('ls-files','-z').split(b'\0') if p] + new
    return {name:sha((root/name).read_bytes()) for name in names}
before = inputs()
(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
producer = types.ModuleType('_renderer_working_producer')
producer.__file__ = str(root/'scripts/producer_process.py')
sys.modules[producer.__name__] = producer
exec(compile(git('show',head+':scripts/producer_process.py'),producer.__file__,'exec'),producer.__dict__)
environment = {**os.environ, 'CI':'1','PORT':'33680','PW_REUSE':'','PW_FEED_DATABASE_URL':'',
               'PW_STORE_DATABASE_URL':'','PW_BLOB_DIR':'','PW_STORE_TEST_LAYER':'memory','BUILD_ONLY':'1',
               'PLAYWRIGHT_JSON_OUTPUT_FILE':str(out/'results.json')}
gates = []
commands = [
    ('node', ['python3','-m','unittest','-v','scripts/tests/test_renderer_contract.py'], root, 60),
    ('preflight', ['just','preflight'], root, 600),
    ('store-build', ['bash','spikes/own-renderer/run.sh'], root, 600),
    ('feed-build', ['bash','spikes/own-renderer/feed.sh'], root, 600),
    ('browser', ['pnpm','exec','playwright','test','e2e/feed.spec.mjs','e2e/press-modules.spec.mjs',
      '--workers=1','--retries=0','--reporter=list,json','--output='+str(out/'test-results')], root/'spikes/own-renderer',600),
    ('press-modules', ['just','e14-press-modules'], root, 1800),
]
canonical = root/'docs/evidence/E14/press-modules.txt'
original = canonical.read_bytes()
if original != git('show',head+':docs/evidence/E14/press-modules.txt'):
    raise RuntimeError('Canonical producer output has another owner/change')
try:
    for label, command, cwd, timeout in commands:
        reaped = []
        with (out/(label+'.log')).open('x') as log:
            result = producer.run(command,cwd=cwd,env=environment,stdout=log,stderr=subprocess.STDOUT,
                                  timeout=timeout,grace=2,on_reaped=lambda pid,status,timed_out,cancelled:reaped.append(
                                  {'pid':pid,'status':status,'timed_out':timed_out,'cancelled':cancelled}))
        gates.append({'label':label,'command':command,'cwd':str(cwd),'exit':result.returncode,
                      'owned_reaped':reaped,'log_sha256':sha((out/(label+'.log')).read_bytes())})
        (out/'progress.json').write_text(json.dumps(gates,indent=2)+'\n')
        if result.returncode: break
finally:
    produced = canonical.read_bytes()
    (out/'press-modules-canonical.txt').write_bytes(produced)
    canonical.write_bytes(original)
    (out/'canonical-restoration.json').write_text(json.dumps({
        'path':str(canonical),'before_sha256':sha(original),'produced_sha256':sha(produced),
        'restored_sha256':sha(canonical.read_bytes()),'raw_produced_bytes_preserved':True,
    },indent=2)+'\n')
after = inputs()
(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'source.diff').write_bytes(git('diff','--binary',head))
for name in new:
    (out/Path(name).name).write_bytes((root/name).read_bytes())
(out/'launcher.py').write_bytes(Path(__file__).read_bytes())
receipt={'baseline_git_head':head,'gates':gates,'working_inputs_unchanged':before==after,
         'gate_acceptance':False,'scope':'Working-tree diagnostics only. Future immutable head requires all fresh gates.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'out':str(out),'gates':[{k:v for k,v in g.items() if k in ['label','exit']}for g in gates],
                  'unchanged':before==after},indent=2))
if before!=after or any(g['exit'] for g in gates): raise SystemExit(1)



