"""Final fixture bytes against preserved pre-owner runtime, after repair.

This is a source-bound negative control, not a restamped pre-repair execution.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import types

work = Path(__file__).resolve().parent
root = Path('/home/haki/code/pw-wt/session-followup-20261027')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out = work/('renderer-final-fixture-negative-control-'+stamp)
out.mkdir(exist_ok=False)
(out/'public').mkdir()
runtime = (work/'renderer-rejected-import-red-source-20261029/pw-runtime.mjs').read_bytes()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
if sha(runtime) != 'c5c3c30846e87ae1df8dff7c9914e7aaddaaa864f9c2a9d335fb8eab5a57610f':
    raise RuntimeError('Wrong preserved source')
test = (root/'spikes/own-renderer/renderer-contract.test.mjs').read_bytes()
(out/'public/pw-runtime.mjs').write_bytes(runtime)
(out/'renderer-contract.test.mjs').write_bytes(test)
producer = types.ModuleType('_renderer_negative_control_producer')
producer.__file__ = str(root/'scripts/producer_process.py')
sys.modules[producer.__name__] = producer
raw = subprocess.check_output(['git','show','eb28ac01946367cff453000eed4d39e83beacd9b:scripts/producer_process.py'],cwd=root)
exec(compile(raw,producer.__file__,'exec'),producer.__dict__)
command = ['node','--test','--test-reporter=spec',str(out/'renderer-contract.test.mjs')]
reaped = []
with (out/'native.log').open('x') as log:
    result = producer.run(command,cwd=out,env={**os.environ,'CI':'1'},stdout=log,stderr=subprocess.STDOUT,
                          timeout=60,grace=2,on_reaped=lambda pid,status,timed_out,cancelled:reaped.append(
                          {'pid':pid,'status':status,'timed_out':timed_out,'cancelled':cancelled}))
receipt = {'phase':'POST_REPAIR_NEGATIVE_CONTROL','runtime_sha256':sha(runtime),'test_sha256':sha(test),
           'exit':result.returncode,'owned_reaped':reaped,'command':command,
           'log_sha256':sha((out/'native.log').read_bytes()),'gate_acceptance':False,
           'not_a_claim_final_test_bytes_were_executed_before_repair':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'launcher.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'out':str(out),'actual_exit':result.returncode},indent=2))
