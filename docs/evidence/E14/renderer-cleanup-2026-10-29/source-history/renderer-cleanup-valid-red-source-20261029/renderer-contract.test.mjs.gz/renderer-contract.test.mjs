// ADR-0172: small lifecycle seams from the actual browser runtime. These
// tests do not boot a page; feed.spec.mjs exercises the real renderer there.
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import vm from "node:vm";

const runtime = readFileSync(new URL("./public/pw-runtime.mjs", import.meta.url), "utf8");
function source(from, until) {
  assert.equal(runtime.split(from).length, 2, `unique runtime seam: ${from}`);
  assert.equal(runtime.split(until).length, 2, `unique runtime seam: ${until}`);
  const start = runtime.indexOf(from);
  const end = runtime.indexOf(until, start);
  assert.ok(end > start, "ordered runtime seam");
  return runtime.slice(start, end);
}
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
function loader(fetch) {
  return vm.runInNewContext(source("let renderer = null;", "/** A path read from the signals") +
    "\n({ renderModule, forgetRenderer })", { fetch, WebAssembly, log: [], wasm: null, speculationModule: null });
}
// A valid native module. Distinct instantiations have distinct export owners.
const response = () => new Response(Uint8Array.of(0, 97, 115, 109, 1, 0, 0, 0), {
  headers: { "Content-Type": "application/wasm" },
});

test("an abandoned renderer load cannot publish over a newer native instance", async () => {
  const first = deferred();
  let requests = 0;
  const actual = loader(() => ++requests === 1 ? first.promise : Promise.resolve(response()));
  const abandoned = actual.renderModule();
  actual.forgetRenderer();
  const current = await actual.renderModule();
  first.resolve(response());
  const obsolete = await abandoned;
  assert.notEqual(obsolete, current);
  assert.equal(await actual.renderModule(), current);
  assert.equal(requests, 2);
});

test("an abandoned renderer rejection cannot forget a newer native instance", async () => {
  const first = deferred();
  let requests = 0;
  const actual = loader(() => ++requests === 1 ? first.promise : Promise.resolve(response()));
  const failure = new Error("the abandoned network request failed");
  const abandoned = actual.renderModule();
  const rejected = assert.rejects(abandoned, (error) => error === failure);
  actual.forgetRenderer();
  const current = await actual.renderModule();
  first.reject(failure);
  await rejected;
  assert.equal(await actual.renderModule(), current);
  assert.equal(requests, 2);
});

function settlement() {
  const load = deferred();
  const states = new Map([
    ["first", { entry: "entry-a", version: 1, value: "held-a", pending: [{ id: 10 }, { id: 11 }] }],
    ["second", { entry: "entry-b", version: 2, raw: "held-b", pending: [{ id: 12 }, { id: 13 }] }],
  ]);
  const drawn = [];
  const actual = vm.runInNewContext(source("async function resolveSpeculation(", "/** An `entry_value` frame:") +
    "\n({ resolveSpeculation })", {
    speculated: states, speculations: () => load.promise, log: [],
    render: (_module, binding) => drawn.push({ binding, state: structuredClone(states.get(binding)) }),
  });
  return { actual, load, states, drawn };
}

test("all failed press IDs are removed before loading or redrawing any binding", async () => {
  const { actual, load, states, drawn } = settlement();
  const resolved = actual.resolveSpeculation([["first", 10], ["second", 12]], false);
  assert.deepEqual(states.get("first").pending, [{ id: 11 }]);
  assert.deepEqual(states.get("second").pending, [{ id: 13 }]);
  assert.equal(drawn.length, 0);
  // An authoritative frame while the redraw loads must remain authoritative.
  states.get("first").version = 3;
  states.get("first").value = "new held-a";
  load.resolve({});
  await resolved;
  assert.deepEqual(drawn.map(({ binding }) => binding).sort(), ["first", "second"]);
  assert.equal(drawn[0].state.value, "new held-a");
  assert.equal(states.get("first").version, 3);
  assert.equal(states.get("second").raw, "held-b");
});

test("a failed rollback load leaves neither owned ID pending", async () => {
  const { actual, load, states, drawn } = settlement();
  const failure = new Error("rollback renderer unavailable");
  const resolved = actual.resolveSpeculation([["first", 10], ["second", 12]], false);
  const rejected = assert.rejects(resolved, (error) => error === failure);
  load.reject(failure);
  await rejected;
  assert.deepEqual(states.get("first").pending, [{ id: 11 }]);
  assert.deepEqual(states.get("second").pending, [{ id: 13 }]);
  assert.equal(drawn.length, 0);
});
