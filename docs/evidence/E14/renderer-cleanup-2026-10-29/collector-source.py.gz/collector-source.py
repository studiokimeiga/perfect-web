"""Preserve bounded working diagnostics without executable archival snapshots."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

work = Path(__file__).resolve().parent
root = Path('/home/haki/code/pw-wt/session-followup-20261027')
out = root/'docs/evidence/E14/renderer-cleanup-2026-10-29'
out.mkdir(exist_ok=False)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
items = []
def add(label, path):
    raw = path.read_bytes()
    encoded = gzip.compress(raw, mtime=0)
    target = out/(label+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(encoded)
    if gzip.decompress(target.read_bytes()) != raw: raise RuntimeError('Archive mismatch')
    items.append({'path':target.relative_to(out).as_posix(),'bytes':len(encoded),'sha256':sha(encoded),
                  'decoded_bytes':len(raw),'decoded_sha256':sha(raw),'original_local_path':str(path)})

for folder, label in [
    ('session-followup-renderer-failure-red-20261028T092128Z','invalid-wrong-export'),
    ('session-followup-renderer-failure-red-20261029T161235Z','invalid-message-role'),
    ('session-followup-renderer-failure-red-20261029T161457Z','cleanup-red'),
]:
    for name in ['browser.log','receipt.json','results.json']:
        add(label+'/'+name,work/folder/name)
    if label == 'cleanup-red':
        for name in ['working-inputs-before.json','working-inputs-after.json']:
            add(label+'/'+name,work/folder/name)
        before=json.loads((work/folder/'working-inputs-before.json').read_text())
        for name in ['spikes/own-renderer/e2e/feed.spec.mjs','spikes/own-renderer/renderer-fault.mjs']:
            if sha((root/name).read_bytes()) != before[name]: raise RuntimeError('Cleanup RED fixture drift')

for name in [
    'renderer-contract-red-20261029.log',
    'renderer-owner-red-20261029.log','renderer-owner-red-final-20261029.log',
    'renderer-owner-native-import-red-20261029.log','renderer-owner-native-import-green-20261029.log',
    'renderer-retirement-caller-red-20261029.log','renderer-retirement-caller-green-20261029.log',
    'renderer-rejected-import-red-20261029.log','renderer-rejected-import-green-20261029.log',
    'renderer-rejected-import-green-final-20261029.log','renderer-hook-final-green-20261029.log',
]: add('node-history/'+name,work/name)

for folder in [
    'renderer-cleanup-valid-red-source-20261029',
    'renderer-owner-native-import-red-source-20261029',
    'renderer-retirement-caller-red-source-20261029',
    'renderer-rejected-import-red-source-20261029',
]:
    for path in sorted((work/folder).iterdir()):
        if path.is_file(): add('source-history/'+folder+'/'+path.name,path)

control=work/'renderer-final-fixture-negative-control-20261029T164248Z'
for name in ['native.log','receipt.json','launcher.py','renderer-contract.test.mjs','public/pw-runtime.mjs']:
    add('post-repair-negative-control/'+name,control/name)

broad=work/'session-followup-renderer-broad-20261029T164107Z'
receipt=json.loads((broad/'receipt.json').read_text())
if len(receipt['gates']) != 6 or not receipt['working_inputs_unchanged'] or any(g['exit']for g in receipt['gates']):
    raise RuntimeError('Incomplete working diagnostics')
for path in sorted(broad.iterdir()):
    if path.is_file(): add('working-broad/'+path.name,path)
for path in sorted((work/'session-followup-eb28ac01-actual-computed-failures').iterdir()):
    if path.is_file(): add('historical-hosted-failures/'+path.name,path)

for name in [
    'spikes/own-renderer/public/pw-runtime.mjs',
    'spikes/own-renderer/renderer-contract.test.mjs',
    'spikes/own-renderer/renderer-fault.mjs',
    'spikes/own-renderer/e2e/feed.spec.mjs',
    'scripts/tests/test_renderer_contract.py','scripts/press_modules_mutations.py',
]: add('working-source/'+name,root/name)
add('collector-source.py',Path(__file__))
manifest={'kind':'BOUNDED_WORKING_DIAGNOSTICS_NOT_IMMUTABLE_HEAD_GATES',
          'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'baseline_git_head':'eb28ac01946367cff453000eed4d39e83beacd9b',
          'original_hosted_candidate_failed':True,'original_trap_low_level_cause_resolved':False,
          'working_broad':{'node_cases':13,'browser_cases':93,'skipped':0,'flaky':0,'failed':0,
                           'press_module_controls_killed':10,'refused':0,'survived':0,'memory_stop':False},
          'qualifications':[
              'Initial wrong-export and wrong-message-role attempts are invalid cleanup witnesses.',
              'Cached-JS owner-red proposals did not order retirement before module completion and are uncredited for adoption.',
              'The first rejected-import green-named log failed in fixture retry; it is not green evidence.',
              'Final fixture bytes changed after the initial RED. Their post-repair old-runtime negative control is separately labeled.',
              'The Python hook was additionally hardened and rerun after the broad diagnostic; browser/runtime/test JS bytes did not change.',
              'Source seams do not boot a page or prove deadlines. Node experimental VM import warning is retained.',
              'Legacy press-module canonical evidence is controller output, not a per-control raw native/PID receipt archive.',
              'All final immutable-head gates and independent evidence review remain required before merge.',
          ],'files':items}
with (out/'manifest.json').open('x') as stream: json.dump(manifest,stream,indent=2);stream.write('\n')
print(json.dumps({'out':str(out),'payloads':len(items),'manifest_sha256':sha((out/'manifest.json').read_bytes())},indent=2))
