from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
for crate in ['pw-table-memory','pw-table-postgres']:
    p=root/f'runtime/{crate}/tests/compiled_relations.rs';s=p.read_text()
    old='let staged=authorized(&program,"RelHeld",ALICE,&command,&pw_host::Limits::unbounded(),&args,false,&asked).assert_ok("compiled predicate sees BOTH staged tables");'
    assert s.count(old)==1
    p.write_text(s.replace(old,'let staged=authorized(&program,"RelHeld",ALICE,&command,&pw_host::Limits::unbounded(),&args,false,&asked);\n    assert!(staged.is_ok(),"compiled predicate sees BOTH staged tables: {staged:?}");\n    let staged=staged.unwrap();'))
