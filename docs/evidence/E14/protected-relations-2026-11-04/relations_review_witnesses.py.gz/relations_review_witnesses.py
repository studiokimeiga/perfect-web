from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-table-memory/tests/compiled_relations.rs';s=p.read_text()
old='    for missing in ["Links", "Roots"] {';assert s.count(old)==1
s=s.replace(old,'''    let predicate=program.components.values().find(|c|c.contract.exports.iter().any(|e|e.kind=="predicate")).unwrap();
    for component in [program.component("RelLast"),program.component("RelMaybe"),predicate] {
    for missing in ["Links", "Roots"] {''')
old='        assert!(result.unwrap_err().contains(missing));\n    }';assert s.count(old)==1
s=s.replace(old,'''        assert!(result.unwrap_err().contains(missing));
        let narrow=absent.granted();
        for primary in ["Links","Roots"] {
            let mut full=component.contract.clone();
            for import in &mut full.imports {if import.interface=="pw:tables/links" {import.capability=format!("database.read<{primary}>");}}
            let actual_missing=program.manifest.admit_reads(&full,&narrow);
            assert!(actual_missing.as_ref().is_err_and(|why|why.contains(missing)),"{} original full contract with only actual {missing} withheld, primary{primary}: {actual_missing:?}",component.contract.component_id);
            let mut reduced=absent.contract.clone();
            for import in &mut reduced.imports {if import.interface=="pw:tables/links" {import.capability=format!("database.read<{primary}>");}}
            let contract_missing=program.manifest.admit_reads(&reduced,&component.granted());
            assert!(contract_missing.as_ref().is_err_and(|why|why.contains(missing)),"{} original full actual grants with only contract {missing} omitted, primary{primary}: {contract_missing:?}",component.contract.component_id);
        }
    }
    }''')
old='''            "target-owned" => {
                tables[target]["owner"] = json!("author");
            }
            "target-order" => {
                tables[target]["order"] = serde_json::Value::Null;
            }''';assert s.count(old)==1
s=s.replace(old,'''            "target-owned" => {
                tables[target]["owner"] = json!("author");
                tables[target]["key"]=json!(["author","id"]);
                tables[target]["functions"]=json!([]);
                for function in tables[source]["functions"].as_array_mut().unwrap() {
                    if function["relation"]=="posts" {function["sorted_by"]=json!(["stamp","author","id"]);}
                }
            }
            "target-order" => {
                tables[target]["order"] = serde_json::Value::Null;
                tables[target]["functions"]=json!([]);
                for function in tables[source]["functions"].as_array_mut().unwrap() {
                    if function["relation"]=="posts" {function["sorted_by"]=json!(["id"]);}
                }
            }''')
old='''            "forged {kind} manifest admitted: {result:?}"
        );''';assert s.count(old)==1
s=s.replace(old,old+'''
        if kind=="target-owned" {assert!(result.unwrap_err().contains("public target"),"otherwise-valid owned target must fail the relation rule");}
        else if kind=="target-order" {assert!(result.unwrap_err().contains("declared target order"),"otherwise-valid unordered target must fail the relation rule");}''')
s+=r'''

#[test]
fn an_unchosen_relation_import_and_authorization_only_predicate_keep_both_grants() {
    let program=relation_program();
    let component=program.component("RelMaybe");
    let reads=program.manifest.admit_reads(&component.contract,&component.granted()).assert_ok("full unchosen import");
    let calls=Arc::new(AtomicUsize::new(0));
    let mut host=program.platform(ALICE);
    for (key,read) in reads {let calls=calls.clone();host.insert(key,pw_host::engine::table_read_host::host_fn(read,Arc::new(move |_|{calls.fetch_add(1,Ordering::SeqCst);Ok(json!([]))})));}
    let args=[handle(ALICE),Val::S64(10),Val::S64(2),Val::Bool(false)];
    assert_eq!(pw_host::engine::call_with_tables_as(&component.bytes,&component.contract,&component.granted(),&pw_host::Limits::unbounded(),&host,&program.manifest,&as_user(ALICE),&component.export(),&args),Ok(vec![Val::List(vec![])]));
    let mut contract=component.contract.clone();contract.required_capabilities.retain(|c|c.name()!="database.read<Roots>");
    let denied=pw_host::engine::call_with_tables_as(&component.bytes,&contract,&component.granted(),&pw_host::Limits::unbounded(),&host,&program.manifest,&as_user(ALICE),&component.export(),&args);
    assert!(denied.as_ref().is_err_and(|why|why.contains("relation read requires") && why.contains("Roots")),"unused import is gated before the false branch: {denied:?}");
    assert_eq!(calls.load(Ordering::SeqCst),0);

    let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");
    let predicate=program.components.values().find(|c|c.contract.exports.iter().any(|e|e.kind=="predicate")).unwrap();
    let mut contract=predicate.contract.clone();contract.required_capabilities.retain(|c|c.name()!="database.read<Roots>");
    let bad=pw_host::engine::Predicate::new(pw_host::engine::Prepared::compile(&predicate.bytes).assert_ok("compiled Selected"),contract,predicate.granted()).assert_ok("predicate's missing target requirement is checked with the table manifest");
    let predicates=pw_host::engine::Predicates::new([bad]).assert_ok("one Selected predicate");
    let body=program.component("RelHeld");
    let prepared=pw_host::engine::Prepared::compile(&body.bytes).assert_ok("RelHeld");
    let snapshot=tables.snapshot().assert_ok("snapshot");
    let watched=Watched::new(&snapshot);
    let denied=prepared.call_authorized_with_tables_as(&body.contract,&body.granted(),&pw_host::Limits::unbounded(),&program.platform(ALICE),&watched,&predicates,&as_user(ALICE),&body.export(),&[handle(ALICE),Val::S64(10),Val::S64(1)],|_,_|Ok(false));
    assert!(denied.as_ref().is_err_and(|why|why.to_string().contains("Roots")),"authorization-only Selected cannot borrow body target authority: {denied:?}");
    assert_eq!(watched.body.load(Ordering::SeqCst),0);
}
'''
p.write_text(s)

p=root/'runtime/pw-table-memory/tests/support/relations.rs';s=p.read_text()
old='    app.push_str(r#"\nimport context.';assert s.count(old)==1
new=r'''    app.push_str(r#"
user query RelMaybe(reader: User<UserId>, topic: Int, n: Int, run: Bool) -> List<Roots.Root>
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader,topic,n,run
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    if run { Links.last_posts_by_reader_topic(reader,topic,n) } else { [] }
}
"#);
    app.push_str(r#"
import context.'''
s=s.replace(old,new);p.write_text(s)

p=root/'compiler/pw-core/tests/table_relations.rs';s=p.read_text();s+=r'''

#[test]
fn an_owner_may_match_private_fields_but_a_sharer_cannot_select_through_them() {
    let owner=LINKS.replace("key reader, topic, author, edge","key reader, edge")
        .replace("index by_recipient_topic_author on to, topic, author","index by_reader_author on reader, author\n    index by_to on to")
        .replace("private secret","private secret, author");
    let got=diagnostics(&owner,ROOTS,DATA);
    assert!(got.is_empty(),"owner-only private match is valid beside ordinary shared rows: {got:#?}");
    let shared=owner.replace("index by_to on to","index by_to on to\n    index by_to_author on to, author");
    refused(&shared,ROOTS,DATA,"PW0369","private match field");
}
''';p.write_text(s)
