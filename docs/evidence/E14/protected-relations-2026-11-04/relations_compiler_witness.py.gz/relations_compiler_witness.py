from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'compiler/pw-core/tests/table_relations.rs'
assert not path.exists()
path.write_text(r'''//! Fixed global windows through declared membership relations.
use pw_core::check::{Unit, check_sources};

const ROOTS: &str = r#"module Roots
import capability.{ UserId }
type Root = Root { id: Int, author: UserId, stamp: Int, text: String }
table Roots
    row Root
    key id
    order stamp
    index by_author on author
"#;
const WINDOW: &str = "    window posts from Roots row Roots.Root on author to author\n";
const LINKS: &str = r#"module Links
import List
import Roots
import capability.{ User, UserId }
type Link = Link { reader: UserId, topic: Int, author: UserId, edge: Int, to: UserId, secret: String }
table Links
    row Link
    key reader, topic, author, edge
    order edge
    index by_recipient_topic_author on to, topic, author
    owned by reader
    shares with to
    private secret
    window posts from Roots row Roots.Root on author to author
"#;
const DATA: &str = r#"module RelationData
import Links
import Roots
source RelationData
    holds Links, Roots
    transactions serializable
    reads strong
    changes none
    sets one_call
"#;
const QUERIES: &str = r#"
user query Mine(reader: User<UserId>, topic: Int, n: Int) -> List<Roots.Root>
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader, topic, n
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    Links.last_posts_by_reader_topic(reader, topic, n)
}
user query Several(reader: User<UserId>, topics: List<Int>, n: Int) -> List<LinksReaderTopicPostsWindow>
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader, topics, n
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    Links.last_posts_by_reader_topic_many(reader, topics, n)
}
user query Shared(reader: User<UserId>, topic: Int, n: Int) -> List<Roots.Root>
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader, topic, n
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    Links.first_posts_by_to_topic(reader, topic, n)
}
user query SharedSeveral(reader: User<UserId>, topics: List<Int>, n: Int) -> List<LinksToTopicPostsWindow>
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader, topics, n
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    Links.first_posts_by_to_topic_many(reader, topics, n)
}
"#;

fn files(links: &str, roots: &str, data: &str) -> Vec<(String, String)> {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let mut files = vec![("Links.pw".into(), links.into()), ("Roots.pw".into(), roots.into()), ("RelationData.pw".into(), data.into())];
    for package in ["packages/pw-std", "packages/pw-platform-web"] {
        let mut paths = std::fs::read_dir(root.join(package)).unwrap()
            .map(|p| p.unwrap().path()).filter(|p| p.extension().is_some_and(|p| p == "pw")).collect::<Vec<_>>();
        paths.sort();
        files.extend(paths.into_iter().map(|path| (path.display().to_string(), std::fs::read_to_string(path).unwrap())));
    }
    files
}
fn units(files: &[(String, String)]) -> Vec<Unit> {
    files.iter().map(|(path, src)| {
        let parsed = pw_syntax::parse_tree(src);
        assert!(parsed.ok(), "{path}: {:?}", parsed.errors);
        Unit { path: path.clone(), src: src.clone(), hir: pw_core::lower::lower_file(src, &parsed.green) }
    }).collect()
}
fn diagnostics(links: &str, roots: &str, data: &str) -> Vec<(String, String)> {
    check_sources(&files(links, roots, data)).into_iter().flat_map(|(_, ds)| ds)
        .map(|d| (d.code.to_string(), d.message)).collect()
}
fn refused(links: &str, roots: &str, data: &str, code: &str, says: &str) {
    let got = diagnostics(links, roots, data);
    assert!(got.iter().any(|(c,m)| c == code && m.contains(says)), "expected {code} {says:?}, got {got:#?}");
}

#[test]
fn the_existing_table_neighbor_without_a_relation_is_valid() {
    let got = diagnostics(&LINKS.replace(WINDOW, ""), ROOTS, DATA);
    assert!(got.is_empty(), "fixture neighbor: {got:#?}");
}

#[test]
fn relation_windows_compile_real_owned_shared_and_group_components_with_dual_grants() {
    for reversed in [false, true] {
        let mut files = files(&(LINKS.to_string()+QUERIES), ROOTS, DATA);
        if reversed { files.reverse(); }
        let got = check_sources(&files);
        assert!(got.iter().all(|(_,d)|d.is_empty()), "relation checks: {got:#?}");
        let build = pw_core::build::build(&units(&files));
        assert!(build.is_ok(), "relation build: {:?}", build.as_ref().err());
        let build = build.unwrap();
        let json = serde_json::to_value(&build.tables).unwrap();
        let table = json["tables"].as_array().unwrap().iter().find(|t|t["name"] == "Links").unwrap();
        for (name, primitive, by, reader) in [
            ("last_posts_by_reader_topic", "related-last", vec!["reader","topic"], "reader"),
            ("last_posts_by_reader_topic_many", "related-last-many", vec!["reader","topic"], "reader"),
            ("first_posts_by_to_topic", "related-first", vec!["to","topic"], "to"),
            ("first_posts_by_to_topic_many", "related-first-many", vec!["to","topic"], "to"),
        ] {
            let function = table["functions"].as_array().unwrap().iter().find(|f|f["name"] == name);
            assert!(function.is_some(), "missing {name}: {table}");
            let function = function.unwrap();
            assert_eq!(function["primitive"], primitive);
            assert_eq!(function["by"], serde_json::json!(by));
            assert_eq!(function["reader"], reader);
            assert_eq!(function["relation"], "posts");
            assert_eq!(function["sorted_by"], serde_json::json!(["stamp","id"]), "target order only");
        }
        for name in ["Links.Mine", "Links.Several", "Links.Shared", "Links.SharedSeveral"] {
            assert!(build.components.iter().any(|(id,b)|id==name && matches!(b,pw_core::backend::component::Built::Component{..})), "real component {name}");
            let contract = build.contracts.iter().find(|c|c.component_id==name).unwrap();
            for table in ["Links","Roots"] {
                assert!(contract.required_capabilities.iter().any(|c|c.family=="database" && c.operation=="read" && c.argument.as_deref()==Some(table)), "{name} missing read<{table}>: {contract:?}");
                assert!(contract.imports.iter().filter(|i|i.interface=="pw:tables/links").all(|i|i.capabilities.iter().any(|c|c.argument.as_deref()==Some(table))), "import dual grant {name}: {contract:?}");
            }
        }
    }
}

#[test]
fn a_relation_row_annotation_is_the_exact_declared_target_row() {
    let identical = "\ntype Other = Other { id: Int, author: UserId, stamp: Int, text: String }\n";
    let roots = ROOTS.to_string()+identical;
    refused(&LINKS.replace("row Roots.Root on", "row Roots.Other on"), &roots, DATA, "PW0361", "row type");
}

#[test]
fn a_relation_requires_one_explicit_source_for_both_tables() {
    let split = DATA.replace("holds Links, Roots", "holds Links")+"\nsource OtherData\n    holds Roots\n    transactions serializable\n    reads strong\n    changes none\n";
    refused(LINKS, ROOTS, &split, "PW0361", "same source");
    refused(LINKS, ROOTS, "module RelationData\n", "PW0361", "source");
}

#[test]
fn a_protected_relation_target_is_refused_beside_the_public_neighbor() {
    let owned = ROOTS.replace("    key id", "    key author, id").replace("    order stamp", "    order stamp\n    owned by author");
    refused(LINKS, &owned, DATA, "PW0368", "public");
}

#[test]
fn a_relation_does_not_disclose_memberships_through_a_shared_cache() {
    let leak = "\nimport context.{ current_user }\nquery Leak() -> List<Roots.Root>\n    consistency strong\n    cache shared\n{\n    Links.last_posts_by_reader_topic(current_user(),0,2)\n}\n";
    refused(&(LINKS.to_string()+leak), ROOTS, DATA, "PW5001", "shared cache");
}
''')
print('compiler relation witnesses written before implementation')
