from pathlib import Path
import ast
root=Path('/home/haki/code/pw-wt/data-path')
def replace(script,name,anchor,replacement,production):
    p=root/'scripts'/script;s=p.read_text();tree=ast.parse(s)
    tuples=[n for n in ast.walk(tree) if isinstance(n,ast.Tuple) and len(n.elts)==4 and isinstance(n.elts[0],ast.Constant) and n.elts[0].value==name]
    assert len(tuples)==1,(script,name)
    node=tuples[0]
    assert (root/production).read_text().count(anchor)==1,(name,'production anchor')
    lines=s.splitlines(keepends=True);offsets=[0]
    for line in lines:offsets.append(offsets[-1]+len(line))
    edits=[]
    for at,value in [(2,anchor),(3,replacement)]:
        field=node.elts[at];edits.append((offsets[field.lineno-1]+field.col_offset,offsets[field.end_lineno-1]+field.end_col_offset,repr(value)))
    for a,b,value in sorted(edits,reverse=True):s=s[:a]+value+s[b:]
    p.write_text(s)

anchor='    "layout", "set", "sets", "row", "order", "index", "unique", "refers", "window", "migrate",\n'
replace('bounded_checker_mutations.py','`set` and `sets` head a clause wherever they are written',anchor,anchor.replace('"set", "sets", ',''),'compiler/pw-syntax/src/grammar.rs')
anchor='                            && fields == by\n                            && (!primitive.related()'
replace('bounded_checker_mutations.py','generated index pairs ignore their queried fields',anchor,anchor.replace('fields == by','(fields == by || true)'),'compiler/pw-core/src/bounded.rs')
anchor='                best.insert(place(row, &function.sorted_by, &table.key), row);\n                if best.len() as u64 > bound as u64 {'
replace('data_path_mutations.py','windows memory retains every matching row',anchor,anchor.replace('if best.len()','if false && best.len()'),'runtime/pw-table-memory/src/lib.rs')
anchor='''                best.insert(place(row, &function.sorted_by, &table.key), row);
                if best.len() as u64 > bound as u64 {
                    if function.primitive.descending() {
                        best.pop_first();'''
replace('data_path_mutations.py','windows memory chooses first rows for last windows',anchor,anchor.replace('best.pop_first();','best.pop_last();'),'runtime/pw-table-memory/src/lib.rs')
anchor='''    if seen != asked {
        return Err("a set count omits a requested selector (zero counts are required)".into());'''
replace('row_ownership_mutations.py','counts missing result keys are accepted',anchor,anchor.replace('if seen != asked','if false && seen != asked'),'runtime/pw-host/src/engine/table_link.rs')
anchor='''        if last.as_ref().is_some_and(|last| *last >= selected) {
            return Err("set counts are in canonical selector order".into());'''
replace('row_ownership_mutations.py','counts reversed selector order is accepted',anchor,anchor.replace('if last.as_ref()','if false && last.as_ref()'),'runtime/pw-host/src/engine/table_link.rs')
anchor='''                if !function.by.iter().all(known)
                    || (!function.primitive.related() && !function.sorted_by.iter().all(known))
                {'''
replace('table_host_mutations.py','a function may name a field its table lacks',anchor,anchor.replace('if !function.by.iter().all(known)\n                    || (!function.primitive.related() && !function.sorted_by.iter().all(known))','if false && (!function.by.iter().all(known)\n                    || (!function.primitive.related() && !function.sorted_by.iter().all(known)))'),'runtime/pw-host/src/tables.rs')
anchor='            } else if import.capability != capability {\n'
replace('table_host_mutations.py',"the gate trusts an import's claim of its capability",anchor,anchor.replace('else if import.capability','else if false && import.capability'),'runtime/pw-host/src/tables.rs')
print('eight old faults reanchored, original scopes preserved')
