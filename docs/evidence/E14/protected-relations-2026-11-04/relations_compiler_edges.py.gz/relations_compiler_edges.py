from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/compiler/pw-core/tests/table_relations.rs')
s=p.read_text();assert 'reader_only_relations' not in s
p.write_text(s+r'''

#[test]
fn reader_only_relations_keep_the_existing_empty_set_exception() {
    let links=LINKS.replace("key reader, topic, author, edge","key reader, author, edge")
        .replace("on to, topic, author","on to, author");
    let build=pw_core::build::build(&units(&files(&links,ROOTS,DATA)));
    assert!(build.is_ok(),"reader-only: {:?}",build.as_ref().err());
    let build=build.unwrap();
    let table=build.tables.tables.iter().find(|t|t.schema.name=="Links").unwrap();
    for selector in ["reader","to"] {
        assert!(table.functions.iter().any(|f|f.name==format!("last_posts_by_{selector}")));
        assert!(!table.functions.iter().any(|f|f.name==format!("last_posts_by_{selector}_many")));
    }
}

#[test]
fn a_relation_loop_names_its_own_set_and_nested_empty_groups() {
    let links=LINKS.replace(WINDOW,&format!("{WINDOW}    window stories from Roots row Roots.Root on author to author\n"));
    let looped=r#"
user query Bad(reader: User<UserId>, topics: List<Int>, n: Int) -> List<List<Roots.Root>>
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader,topics,n
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    List.map(topics,topic => Links.last_stories_by_reader_topic(reader,topic,n))
}
"#;
    let sources=files(&(links+looped),ROOTS,DATA);
    let got=check_sources(&sources).into_iter().flat_map(|(_,d)|d).collect::<Vec<_>>();
    let refusal=got.iter().find(|d|d.code=="PW0405");
    assert!(refusal.is_some(),"missing keyed-loop refusal: {got:#?}");
    let hint=format!("{:#?}",refusal.unwrap());
    assert!(hint.contains("last_stories_by_reader_topic_many"),"correct relation set: {hint}");
    assert!(!hint.contains("last_posts_by_reader_topic_many"),"another relation's set: {hint}");
    assert!(hint.contains("key/rows") && hint.contains("empty"),"nested result groups including empty: {hint}");
}

#[test]
fn duplicate_relation_names_and_user_group_names_are_named_refusals() {
    refused(&LINKS.replace(WINDOW,&format!("{WINDOW}{WINDOW}")),ROOTS,DATA,"PW0361","posts");
    refused(&(LINKS.to_string()+"\ntype LinksReaderTopicPostsWindow = LinksReaderTopicPostsWindow { fake: Int }\n"),ROOTS,DATA,"PW0361","LinksReaderTopicPostsWindow");
}

#[test]
fn matching_fields_keep_nominal_identity_and_both_declared_lookup_paths() {
    let roots=ROOTS.replace("type Root =", "opaque type OtherId = String\ntype Root =").replace("author: UserId","author: OtherId");
    refused(LINKS,&roots,DATA,"PW0361","same complete keyable type");
    refused(LINKS,&ROOTS.replace("    index by_author on author\n",""),DATA,"PW0361","declared lookup");
    refused(LINKS,&ROOTS.replace("    order stamp\n",""),DATA,"PW0361","target order");
    let links=LINKS.replace("key reader, topic, author, edge","key reader, topic, edge")
        .replace("    index by_recipient_topic_author on to, topic, author\n","");
    refused(&links,ROOTS,DATA,"PW0361","declared lookup");
}

#[test]
fn relation_owner_formals_do_not_alias_the_list_or_bound() {
    for owner in ["keys","limit"] {
        let pascal=format!("{}{}",owner[..1].to_uppercase(),&owner[1..]);
        let links=(LINKS.to_string()+QUERIES).replace("reader",owner).replace("Reader",&pascal);
        let build=pw_core::build::build(&units(&files(&links,ROOTS,DATA)));
        assert!(build.is_ok(),"owner {owner}: {:?}",build.as_ref().err());
        let build=build.unwrap();
        for name in ["Links.Mine","Links.Several"] {
            assert!(build.components.iter().any(|(id,b)|id==name && matches!(b,pw_core::backend::component::Built::Component{..})),"real WIT names {owner} {name}");
        }
    }
}
''')
