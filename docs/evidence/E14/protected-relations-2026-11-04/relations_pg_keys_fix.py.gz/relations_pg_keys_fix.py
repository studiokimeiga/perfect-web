from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/runtime/pw-table-postgres/src/lib.rs');s=p.read_text()
old='let keys=typed_selections(source,function,"relation window",selectors)?;';assert s.count(old)==1
p.write_text(s.replace(old,'let keys=typed_selections(source,function,"relation window",selectors)?.into_iter().collect::<Vec<_>>();'))
