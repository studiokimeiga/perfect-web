from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-table-memory/tests/read_selector_types.rs';s=p.read_text()
old='    FunctionJson {\n';assert s.count(old)==1;s=s.replace(old,old+'        relation: None,\n')
old='TableJson {\n';assert s.count(old)==1;s=s.replace(old,old+'            windows: Vec::new(),\n');p.write_text(s)
