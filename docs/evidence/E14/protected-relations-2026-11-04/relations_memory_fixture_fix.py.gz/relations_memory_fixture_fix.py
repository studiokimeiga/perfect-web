from pathlib import Path
import shutil
p=Path('/home/haki/code/pw-wt/data-path/runtime/pw-table-memory/tests/compiled_relations.rs')
s=p.read_text();assert s.count('Caller::None')==1 and s.count('operation_statements()')==2
p.write_text(s.replace('Caller::None','Caller::Nobody').replace('operation_statements()','statements()'))
shutil.copy2('/tmp/pw-protected-migration/relations-memory-red.log','/tmp/pw-protected-migration/relations-memory-fixture-invalid.log')
