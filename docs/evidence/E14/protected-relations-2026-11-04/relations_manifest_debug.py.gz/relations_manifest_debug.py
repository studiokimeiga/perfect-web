from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/runtime/pw-table-memory/tests/support/relations.rs')
s=p.read_text();old='    built_from(&[("Roots.pw",roots),("Links.pw",links),("RelationData.pw",data),("app.pw",&app)])';assert s.count(old)==1
s=s.replace(old,'''    let files=[("Roots.pw",roots),("Links.pw",links),("RelationData.pw",data),("app.pw",&app)];
    let checked=pw_core::build::build(&units_of(files.iter().map(|(path,source)|(path.to_string(),source.to_string())).collect())).assert_ok("relation build");
    let manifest=pw_host::tables::Manifest::from_json(&serde_json::to_string(&checked.tables).unwrap());
    assert!(manifest.is_ok(),"relation manifest admission: {:?}",manifest.as_ref().err());
    built_from(&files)''')
p.write_text(s)
