from pathlib import Path
import importlib.util
import sys

root=Path('/home/haki/code/pw-wt/data-path')
def edit(path,old,new):
    p=root/path;s=p.read_text();assert s.count(old)==1,(path,s.count(old),old);p.write_text(s.replace(old,new,1))

pg=[
('relations scalar ignores its whole source selector','SQL',
 'WHERE {} AND {matched}) ORDER BY {order} LIMIT ${parameter}::bigint",',
 'WHERE ({} OR true) AND {matched}) ORDER BY {order} LIMIT ${parameter}::bigint",'),
('relations match uses another type-compatible target field','SQL',
 'ident(&target.columns[relation.target_match].name)',
 'ident(&target.columns.iter().find(|c| c.name == "text").unwrap_or(&target.columns[relation.target_match]).name)'),
('relations scalar join duplicates target rows for duplicate edges','SQL',
 'FROM {to} t WHERE EXISTS (SELECT 1 FROM {from} s WHERE {} AND {matched}) ORDER BY {order} LIMIT ${parameter}::bigint",',
 'FROM {to} t JOIN {from} s ON {matched} WHERE {} ORDER BY {order} LIMIT ${parameter}::bigint",'),
('relations set clips globally instead of inside each source selector','SQL',
 'WHERE {} AND {matched}) ORDER BY {order} LIMIT ${parameter}::bigint) w \\\n             ORDER BY k.pw_slot, {}",',
 'WHERE {} AND {matched}) ORDER BY {order} OFFSET (${parameter}::bigint * 0)) w \\\n             ORDER BY k.pw_slot, {} LIMIT ${parameter}::bigint",'),
]
query_anchor='''        let rows = conn
            .query(&inner.counters, sql, &params)
            .map_err(database)?;
        let mut last = 0;
        for row in rows {'''
pg.append(('relations correct scalar answers fetch all matches before host clipping','LIB',query_anchor,'''        let expanded = if !function.primitive.many() {
            let parameter = function.by.len() + 1;
            sql.replace(&format!(" LIMIT ${parameter}::bigint"), &format!(" OFFSET (${parameter}::bigint * 0)"))
        } else { sql.to_string() };
        let mut rows = conn.query(&inner.counters, &expanded, &params).map_err(database)?;
        if !function.primitive.many() { rows.truncate(usize::try_from(bound).unwrap_or(usize::MAX)); }
        let mut last = 0;
        for row in rows {'''))
pg.append(('relations correct scalar answers fetch per-author windows before host clipping','LIB',query_anchor,'''        let expanded = if !function.primitive.many() {
            let parameter = function.by.len() + 1;
            let (head, rest) = sql.split_once(" FROM ").ok_or_else(|| Error::Schema("relation select".into()))?;
            let (filtered, ordered) = rest.rsplit_once(" ORDER BY ").ok_or_else(|| Error::Schema("relation order".into()))?;
            let (order, _) = ordered.rsplit_once(" LIMIT ").ok_or_else(|| Error::Schema("relation limit".into()))?;
            let matched = ident(&target.columns[relation.target_match].name);
            format!("{head} FROM (SELECT t.*, row_number() OVER (PARTITION BY t.{matched} ORDER BY {order}) AS pw_author_rank FROM {filtered}) t WHERE t.pw_author_rank <= ${parameter}::bigint ORDER BY {order}")
        } else { sql.to_string() };
        let mut rows = conn.query(&inner.counters, &expanded, &params).map_err(database)?;
        if !function.primitive.many() { rows.truncate(usize::try_from(bound).unwrap_or(usize::MAX)); }
        let mut last = 0;
        for row in rows {'''))
loop_anchor=query_anchor+'''
            let (slot, offset) = if function.primitive.many() {
                let slot: i64 = row.try_get(0).map_err(database)?;
                (
                    usize::try_from(slot)
                        .ok()
                        .and_then(|s| s.checked_sub(1))
                        .ok_or_else(|| Error::Database("relation slot is invalid".into()))?,
                    1,
                )
            } else {
                (0, 0)
            };'''
pg.append(('relations correct set answers run one SQL query per source selector','LIB',loop_anchor,'''        let rows = if function.primitive.many() {
            let mut rows = Vec::new();
            for (slot,key) in keys.iter().enumerate() {
                let mut params = function.by.iter().zip(key).map(|(&field,atom)| bind_array(&source.columns[field],&[atom])).collect::<Result<Vec<Param>,Error>>()?;
                params.push(Box::new(bound));
                rows.extend(conn.query(&inner.counters,sql,&params).map_err(database)?.into_iter().map(|row| (slot,1,row)));
            }
            rows
        } else {
            conn.query(&inner.counters,sql,&params).map_err(database)?.into_iter().map(|row| (0,0,row)).collect()
        };
        let mut last = 0;
        for (slot,offset,row) in rows {'''))

row=[
('relations contract dual grant requirement is omitted','HOST_TABLES',
 '                    if !contract\n                        .required_capabilities',
 '                    if false && !contract\n                        .required_capabilities'),
('relations actual secondary grant requirement is omitted','HOST_TABLES',
 '                        || granted.handle(&required).is_none()',
 '                        || false && granted.handle(&required).is_none()'),
('relations protected targets are admitted','HOST_RELATIONS',
 'if target.owner.is_some() || !target.private.is_empty() || !target.shares.is_empty() {',
 'if false && (target.owner.is_some() || !target.private.is_empty() || !target.shares.is_empty()) {'),
('relations different sources are admitted as colocated','HOST_RELATIONS',
 'if source.source.as_ref().is_none_or(|s| s.trim().is_empty())\n            || source.source != target.source',
 'if false && (source.source.as_ref().is_none_or(|s| s.trim().is_empty())\n            || source.source != target.source)'),
('relations target order declaration is not required','HOST_RELATIONS',
 'if target.order.is_none() {', 'if false && target.order.is_none() {'),
('relations match stored kinds and refinements need not agree','HOST_RELATIONS',
 'if from.stored != to.stored || !scalar(&from.stored) {',
 'if false && from.stored != to.stored || !scalar(&from.stored) {'),
('relations target nominal row annotation is ignored','CORE_RELATIONS',
 '.is_some_and(|(a, b)| a.same_as(b))', '.is_some_and(|(a, b)| { let _ = (a,b); true })'),
('relations target row visibility is ignored','CORE_RELATIONS',
 'if private_row {', 'if false && private_row {'),
('relations identity transition uses the public target key as owner authority','OWNERS',
 'read.source_key.as_ref().unwrap_or(&read.key).first()', 'read.key.first()'),
('relations missing empty groups are accepted','LINK',
 '    if seen != asked {\n        return Err("a relation set omits a requested group (empty groups are required)".into());',
 '    if false && seen != asked {\n        return Err("a relation set omits a requested group (empty groups are required)".into());'),
('relations reversed source groups are accepted','LINK',
 '        if last.as_ref().is_some_and(|last| *last >= selected) {\n            return Err("relation groups are in canonical source selector order".into());',
 '        if false && last.as_ref().is_some_and(|last| *last >= selected) {\n            return Err("relation groups are in canonical source selector order".into());'),
]
data=[
('relations memory ignores membership selection','MEMORY',
 '                if !member {\n                    continue;\n                }',
 '                if false && !member {\n                    continue;\n                }'),
('relations memory uses another readers memberships','MEMORY',
 '                let mut lookup = selected.clone();\n                lookup.push(Atom::parse(value)?);',
 '                let mut lookup = selected.clone();\n                if matches!(lookup.first(),Some(Atom::String(_))) { lookup[0] = Atom::String("u-bob".into()); }\n                lookup.push(Atom::parse(value)?);'),
('relations memory retains every matching target row','MEMORY',
 '                best.insert(place(row, &function.sorted_by, &target.key), row);\n                if best.len() as u64 > bound as u64 {',
 '                best.insert(place(row, &function.sorted_by, &target.key), row);\n                if false && best.len() as u64 > bound as u64 {'),
('relations memory chooses first rows for a last window','MEMORY',
 '                best.insert(place(row, &function.sorted_by, &target.key), row);\n                if best.len() as u64 > bound as u64 {\n                    if function.primitive.descending() {\n                        best.pop_first();',
 '                best.insert(place(row, &function.sorted_by, &target.key), row);\n                if best.len() as u64 > bound as u64 {\n                    if function.primitive.descending() {\n                        best.pop_last();'),
('relations memory omits empty source groups','MEMORY',
 '        groups.push(serde_json::json!({"key":key,"rows":rows}));',
 '        if !rows.is_empty() { groups.push(serde_json::json!({"key":key,"rows":rows})); }'),
]

edit('scripts/row_ownership_mutations.py','MUTANTS = [\n',
     'HOST_RELATIONS = ROOT / "runtime/pw-host/src/tables/relations.rs"\nCORE_RELATIONS = ROOT / "compiler/pw-core/src/tables/relations.rs"\n\nMUTANTS = [\n')
for script,mutants in [('d3_postgres',pg),('row_ownership',row),('data_path',data)]:
    rendered=''.join('    ('+repr(name)+', '+variable+',\n     '+repr(anchor)+',\n     '+repr(replacement)+'),\n' for name,variable,anchor,replacement in mutants)
    edit(f'scripts/{script}_mutations.py','MUTANTS = [\n','MUTANTS = [\n'+rendered)
    sys.path.insert(0,str(root/'scripts'))
    spec=importlib.util.spec_from_file_location(script,root/f'scripts/{script}_mutations.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    for name,path,anchor,_ in module.MUTANTS:
        if name.startswith('relations '): assert path.read_text().count(anchor)==1,(name,path,path.read_text().count(anchor))
print('23 new relation fault anchors are unique')
