from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/runtime/pw-host/src/tables.rs')
s=p.read_text();old='if !function.by.iter().chain(&function.sorted_by).all(known) {';assert s.count(old)==1
p.write_text(s.replace(old,'if !function.by.iter().all(known) || (!function.primitive.related() && !function.sorted_by.iter().all(known)) {'))
