from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/compiler/pw-core/src/tables/relations.rs');s=p.read_text()
old='''        if !annotation
            .resolved()''';assert s.count(old)==1
new='''        // Resolving a written policy type does not by itself run the normal
        // import-visibility diagnostic. Its actual target row must be visible
        // across this module boundary as well as nominally identical.
        let private_row = target_unit != unit && target_type.as_ref()
            .and_then(|ty|ty.resolved()).and_then(|ty|ty.def_id())
            .is_some_and(|def|hirs[def.unit].decl(DeclId(def.decl)).visibility.as_deref()==Some("private"));
        if private_row {
            out.push(bad(format!("window `{}` row type `{}` is private to its declaring module",w.name,w.row_type)));
        }
        if !annotation
            .resolved()'''
p.write_text(s.replace(old,new))
