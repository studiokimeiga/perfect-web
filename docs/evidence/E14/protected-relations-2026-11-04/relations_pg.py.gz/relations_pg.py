from pathlib import Path
import shutil
root=Path('/home/haki/code/pw-wt/data-path')
shutil.copy2('/tmp/pw-protected-migration/relations-pg-initial.log','/tmp/pw-protected-migration/relations-pg-build-before-integration.log')
def change(path,old,new):
    p=root/path;s=p.read_text();assert s.count(old)==1,(path,s.count(old),old[:90]);p.write_text(s.replace(old,new,1))
change('runtime/pw-table-postgres/src/migrate.rs','            .map(|schema| TableJson {','            .map(|schema| TableJson {\n                windows: Vec::new(),')
change('runtime/pw-table-postgres/src/shape.rs','#[derive(Debug, Clone)]\npub(crate) struct FunctionShape {','''#[derive(Debug, Clone)]
pub(crate) struct RelatedShape {
    pub target: usize,
    pub source_match: usize,
    pub target_match: usize,
}

#[derive(Debug, Clone)]
pub(crate) struct FunctionShape {
    pub related: Option<RelatedShape>,''')
change('runtime/pw-table-postgres/src/shape.rs','            let shaped = FunctionShape {\n                table: at,','''            let related=if function.primitive.related() {
                let window=table.windows.iter().find(|window|Some(&window.name)==function.relation.as_ref())
                    .ok_or_else(||Error::Schema("relation declaration is missing".into()))?;
                let target=place(&window.target).ok_or_else(||Error::Schema("relation target is missing".into()))?;
                let target_match=manifest.tables[target].schema.fields.iter().position(|field|field.name==window.target_field)
                    .ok_or_else(||Error::Schema("target match field is missing".into()))?;
                Some(RelatedShape{target,source_match:at_field(&window.source_field)?,target_match})
            }else{None};
            let result_table=related.as_ref().map(|r|&manifest.tables[r.target]).unwrap_or(table);
            let shaped = FunctionShape {
                related,
                table: at,''')
change('runtime/pw-table-postgres/src/shape.rs','''                sorted_by: function
                    .sorted_by
                    .iter()
                    .map(|f| at_field(f))
                    .collect::<Result<_, _>>()?,''','''                sorted_by: function.sorted_by.iter().map(|name|result_table.schema.fields.iter().position(|field|field.name==*name)
                    .ok_or_else(||Error::Schema(format!("target sort field {name} is missing")))).collect::<Result<_,_>>()?,''')
change('runtime/pw-table-postgres/src/sql.rs','            (import.clone(), statement(names, table, function))','''            let sql=if let Some(relation)=&function.related {
                related_statement(names,table,&shape.tables[relation.target],function,relation)
            }else{statement(names,table,function)};
            (import.clone(), sql)''')
change('runtime/pw-table-postgres/src/sql.rs','    match function.primitive {\n        Primitive::Get |','''    match function.primitive {
        Primitive::RelatedFirst | Primitive::RelatedFirstMany | Primitive::RelatedLast | Primitive::RelatedLastMany => unreachable!("relation SQL is generated with both table shapes"),
        Primitive::Get |''')
p=root/'runtime/pw-table-postgres/src/sql.rs';s=p.read_text();at=s.index('\nfn statement(')
new=r'''
/// A fixed semi-join: target ordering and LIMIT occur globally across all
/// matching members inside each source selector, before rows cross SQL.
fn related_statement(names:&Names,source:&TableShape,target:&TableShape,function:&FunctionShape,relation:&crate::shape::RelatedShape)->String {
    let from=names.qualified(&source.name);
    let to=names.qualified(&target.name);
    let matched=format!("s.{} = t.{}",ident(&source.columns[relation.source_match].name),ident(&target.columns[relation.target_match].name));
    let order=window_order("t",target,&function.sorted_by,function.primitive.descending());
    let parameter=function.by.len()+1;
    if !function.primitive.many() {
        let by=(1..=function.by.len()).collect::<Vec<_>>();
        return format!("SELECT {} FROM {to} t WHERE EXISTS (SELECT 1 FROM {from} s WHERE {} AND {matched}) ORDER BY {order} LIMIT ${parameter}::bigint",
            row_list("t",target),equal("s",source,&function.by,&by));
    }
    let arrays=function.by.iter().enumerate().map(|(i,&field)|format!("${}::{}",i+1,source.columns[field].kind.array())).collect::<Vec<_>>();
    let mut columns=(0..function.by.len()).map(|i|format!("c{i}")).collect::<Vec<_>>();columns.push("pw_slot".into());
    let selectors=function.by.iter().enumerate().map(|(i,&field)|format!("s.{} = k.c{i}",ident(&source.columns[field].name))).collect::<Vec<_>>();
    let named=target.columns.iter().map(|column|format!("{} AS {}",read_column("t",column),ident(&column.name))).collect::<Vec<_>>();
    format!("SELECT k.pw_slot AS pw_related_slot, {} FROM unnest({}) WITH ORDINALITY AS k({}) CROSS JOIN LATERAL \
             (SELECT {} FROM {to} t WHERE EXISTS (SELECT 1 FROM {from} s WHERE {} AND {matched}) ORDER BY {order} LIMIT ${parameter}::bigint) w \
             ORDER BY k.pw_slot, {}",
        row_list("w",target),arrays.join(", "),columns.join(", "),named.join(", "),selectors.join(" AND "),
        window_order("w",target,&function.sorted_by,function.primitive.descending()))
}
'''
s=s[:at]+new+s[at:];p.write_text(s)
change('runtime/pw-table-postgres/src/lib.rs','''    if function.primitive.range() {
        return read_ranges(inner, conn, table, function, sql, args);
    }''','''    if function.primitive.related() {
        return read_related(inner,conn,table,function,sql,args);
    }
    if function.primitive.range() {
        return read_ranges(inner, conn, table, function, sql, args);
    }''')
p=root/'runtime/pw-table-postgres/src/lib.rs';s=p.read_text();at=s.index('/// A scalar/set range is one aggregate query')
new=r'''/// One prepared global relation window, or one lateral statement for all keys.
fn read_related(inner:&Inner,conn:&mut Conn,source:&shape::TableShape,function:&shape::FunctionShape,sql:&str,args:&[Value])->Result<Value,Error> {
    let Some((bound,selectors))=args.split_last() else {return Err(Error::Input("a relation window takes a trailing Int limit".into()));};
    let bound=bound.as_i64().ok_or_else(||Error::Input("a relation limit must be an Int".into()))?;
    let keys=typed_selections(source,function,"relation window",selectors)?;
    let relation=function.related.as_ref().ok_or_else(||Error::Schema("relation shape is missing".into()))?;
    let target=&inner.shape.tables[relation.target];
    if keys.is_empty() {return Ok(Value::Array(Vec::new()));}
    let mut groups=vec![Vec::new();keys.len()];
    if bound>0 {
        let mut params=if function.primitive.many() {
            function.by.iter().enumerate().map(|(at,&field)|{
                let atoms=keys.iter().map(|key|&key[at]).collect::<Vec<_>>();
                bind_array(&source.columns[field],&atoms)
            }).collect::<Result<Vec<Param>,Error>>()?
        }else{
            function.by.iter().zip(&keys[0]).map(|(&field,atom)|bind_atom(&source.columns[field],atom)).collect::<Result<Vec<Param>,Error>>()?
        };
        params.push(Box::new(bound));
        let rows=conn.query(&inner.counters,sql,&params).map_err(database)?;
        let mut last=0;
        for row in rows {
            let (slot,offset)=if function.primitive.many() {
                let slot:i64=row.try_get(0).map_err(database)?;
                (usize::try_from(slot).ok().and_then(|s|s.checked_sub(1)).ok_or_else(||Error::Database("relation slot is invalid".into()))?,1)
            }else{(0,0)};
            if slot>=groups.len() || slot<last {return Err(Error::Database("relation slot is out of request order".into()));}
            last=slot;
            if groups[slot].len() as u64>=bound as u64 {return Err(Error::Database("relation rows exceed their global limit".into()));}
            groups[slot].push(Value::Object(decode(target,&row,offset)?));
        }
    }
    if !function.primitive.many() {return Ok(Value::Array(groups.remove(0)));}
    let mut out=Vec::with_capacity(keys.len());
    for (key,rows) in keys.into_iter().zip(groups) {
        let key=match key.as_slice() {
            [one]=>one.value(),
            _=>Value::Object(function.by.iter().map(|&field|source.columns[field].name.clone()).zip(key.iter().map(shape::Atom::value)).collect()),
        };
        out.push(serde_json::json!({"key":key,"rows":rows}));
    }
    Ok(Value::Array(out))
}

'''
s=s[:at]+new+s[at:];p.write_text(s)
print('PostgreSQL fixed relation statement/shape/read integration applied')
