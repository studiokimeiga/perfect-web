from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
for crate in ['pw-table-memory','pw-table-postgres']:
    p=root/f'runtime/{crate}/tests/compiled_relations.rs';s=p.read_text();assert s.count('&[root.clone()]')==1
    p.write_text(s.replace('&[root.clone()]','std::slice::from_ref(&root)'))
p=root/'runtime/pw-table-memory/tests/support/relations.rs';s=p.read_text()
start=s.index('    let checked=pw_core::build::build(');end=s.index('    built_from(&files)',start)
s=s[:start]+s[end:];p.write_text(s)
