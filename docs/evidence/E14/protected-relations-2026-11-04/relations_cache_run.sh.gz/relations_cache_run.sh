#!/bin/bash
set -euo pipefail
cd /home/haki/code/pw-wt/data-path
source /home/haki/pw-setup/env.sh
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
cargo test --locked -p pw-dev-server warm_relation_selections > /tmp/pw-protected-migration/relations-review-cache.log 2>&1
