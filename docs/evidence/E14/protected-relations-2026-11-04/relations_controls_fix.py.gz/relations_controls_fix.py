from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/scripts/data_path_mutations.py');s=p.read_text();assert s.count('Atom::String')==2;p.write_text(s.replace('Atom::String','Atom::Str'))
