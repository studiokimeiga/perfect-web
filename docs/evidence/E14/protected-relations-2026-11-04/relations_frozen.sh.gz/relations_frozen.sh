#!/bin/bash
set -euo pipefail
cd /home/haki/code/pw-wt/data-path
source /home/haki/pw-setup/env.sh
expected=d8c634c9
test "$(git rev-parse --short=8 HEAD)" = "$expected"
test -z "$(git status --porcelain)"
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
log=/tmp/pw-protected-migration
git rev-parse HEAD > "$log/relations-frozen-source.txt"
run() { local name="$1"; shift; echo "starting $name"; "$@" > "$log/relations-frozen-$name.log" 2>&1; echo "$name passed"; }
run core cargo test --locked -p pw-core --lib --test tables --test table_counts --test table_windows --test table_ranges --test table_relations --test table_owners --test bounded_reads --test bounded_tables --test invoked_by --test scheduled --test head_only
run cli cargo test --locked -p pw-cli --test tables
run host cargo test --locked -p pw-host --features engine
run memory cargo test --locked -p pw-table-memory
run pg cargo test --locked -p pw-table-postgres
run server cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::protected_migration:: identity:: tests::store_accounts:: tests::sign_in:: tests::tables:: tests::conformance:: tests::tables_pg:: tests::second_host::
run test-compile just test-compile
run preflight just preflight
helper=/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration/relations_strict_controls.py
run pg-controls python3 "$helper" d3_postgres
run row-controls python3 "$helper" row_ownership
run data-controls python3 "$helper" data_path
run bounded-controls python3 "$helper" bounded_checker
run host-controls python3 "$helper" table_host
test "$(git rev-parse --short=8 HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> "$log/relations-frozen-source.txt"
echo 0 > "$log/relations-frozen.exit"
echo 'relation frozen checks and source guard passed'
