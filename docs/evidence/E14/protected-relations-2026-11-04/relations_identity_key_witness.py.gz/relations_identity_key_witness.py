from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-host/src/tables.rs';s=p.read_text();old='    pub target: Option<String>,\n';assert s.count(old)==1
s=s.replace(old,old+'    /// The membership table key when result rows/key belong to a public target.\n    pub source_key: Option<Vec<String>>,\n')
old='                target: target.map(|t| t.name.clone()),';assert s.count(old)==1
s=s.replace(old,old+'\n                source_key: target.map(|_| table.key.clone()),');p.write_text(s)
count=0
for name in ['table_selectors','table_results','table_read_host','table_link','table_owners']:
    p=root/f'runtime/pw-host/src/engine/{name}.rs';s=p.read_text();n=s.count('            target: None,\n');
    s=s.replace('            target: None,\n','            target: None,\n            source_key: None,\n');count+=n;p.write_text(s)
assert count==6,count
p=root/'runtime/pw-host/src/engine/table_owners.rs';s=p.read_text();at=s.rfind('\n}')
new=r'''

    #[test]
    fn identity_relation_reads_use_membership_ownership_not_the_public_targets_key() {
        let caller=Caller::IdentityTransition{previous_guest:"guest".into(),current:"account".into()};
        let mut shared=by_to();
        if let Access::Read(read)=&mut shared {
            read.target=Some("Posts".into());
            read.source_key=Some(read.key.clone());
            // A legal public target key may have the same spelling as the
            // source sharer field. It grants no old-guest sharer authority.
            read.key=vec!["to".into()];
            read.primitive=Primitive::RelatedLast;
            read.handle.as_mut().unwrap().seen=None;
        }
        assert!(admit(&shared,&caller,vec![Val::String("guest".into()),Val::S64(1)]).is_err(),"old guest must not read foreign-owned memberships through a sharer");
        assert!(admit(&shared,&caller,vec![Val::String("account".into()),Val::S64(1)]).is_ok(),"current account retains normal sharer access");
        let mut owner=shared;
        if let Access::Read(read)=&mut owner {
            read.handle.as_mut().unwrap().field="author".into();
            read.by[0]=string("author");
        }
        assert!(admit(&owner,&caller,vec![Val::String("guest".into()),Val::S64(1)]).is_ok(),"old guest retains own membership reads even when target key differs");
    }
'''
s=s[:at]+new+s[at:];p.write_text(s)
p=root/'runtime/pw-table-memory/tests/compiled_relations.rs';s=p.read_text();old='    assert_eq!(read.table, "Links");';assert s.count(old)==1
s=s.replace(old,old+'\n    assert_eq!(read.source_key.as_deref(),Some(["reader".to_string(),"topic".to_string(),"author".to_string(),"edge".to_string()].as_slice()));');p.write_text(s)
