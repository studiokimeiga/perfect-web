from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/compiler/pw-core/tests/table_relations.rs');s=p.read_text()
old='    let hint = format!("{:#?}", refusal.unwrap());';assert s.count(old)==1
s=s.replace(old,old+'\n    assert!(!hint.contains("; +"),"no patch marker in rendered relation repair: {hint}");')
p.write_text(s)
