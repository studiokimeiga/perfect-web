from pathlib import Path
import gzip,hashlib,json,re,shutil,subprocess,sys
root=Path('/home/haki/code/pw-wt/data-path');logs=Path('/tmp/pw-protected-migration')
work=Path('/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration')
code='d8c634c9e513810dc5db300e0a44478718edd355';latest=sys.argv[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==latest and not git('status','--porcelain')
assert git('diff','--name-only',code,latest)=='runtime/pw-table-memory/tests/compiled_relations.rs'
assert (logs/'relations-frozen-source.txt').read_text()==f'{code}\nsource guard: clean\n'
assert (logs/'relations-reuse-source.txt').read_text()==f'{latest}\nsource guard: clean\n'
for prefix in ['relations-frozen','relations-reuse']:
    assert (logs/f'{prefix}.exit').read_text().strip()=='0'
totals={}
for suite,expected in [('core',350),('cli',5),('host',118),('memory',132),('pg',95),('server',180)]:
    content=(logs/f'relations-frozen-{suite}.log').read_text()
    results=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',content)]
    totals[suite]=dict(zip(['passed','failed','ignored'],[sum(row[i] for row in results) for i in range(3)]))
    assert totals[suite]['passed']==expected and totals[suite]['failed']==0
assert totals['host']['ignored']==9
controls={}
for name,count,baseline in [('pg',11,95),('row',14,232),('data',7,85),('bounded',2,40),('host',2,171)]:
    content=(logs/f'relations-frozen-{name}-controls.log').read_text()
    assert f'{count} of {count} mutants killed' in content
    assert f'baseline: {baseline} passed, 0 failed' in content
    assert all(bad not in content for bad in ['INVALID','SURVIVED','ANCHOR NOT'])
    controls[name]={'baseline':baseline,'killed':count}
assert 'test result: ok. 8 passed; 0 failed;' in (logs/'relations-reuse-memory.log').read_text()
content=(logs/'relations-reuse-controls.log').read_text()
assert 'baseline: 8 passed, 0 failed' in content and '2 of 2 mutants killed' in content
assert all(bad not in content for bad in ['INVALID','SURVIVED','ANCHOR NOT'])
for path in [logs/'relations-frozen-preflight.log',logs/'relations-reuse-preflight.log']:
    assert 'mutation anchors: 5253 mutants' in path.read_text()
# The correct-answer cost faults fail AFTER their final-answer equality.
for number,extra in [(6,36),(7,24)]:
    content=(logs/f'relations-strict-d3_postgres/run-{number:02}-00.log').read_text()
    assert 'only final target rows cross SQL at12' in content and f'left: {extra}\n right: 2' in content

base=root/'docs/evidence/E14/protected-relations-2026-11-04';base.mkdir()
for path in sorted(logs.glob('relations*')):
    if path.is_file() and path.suffix in ['.log','.txt','.exit','.json']:
        data=path.read_bytes();assert not re.search(rb'postgres(?:ql)?://',data),path
        shutil.copy2(path,base/path.name)
    elif path.is_dir() and ('strict' in path.name):
        dest=base/path.name;dest.mkdir()
        for p in sorted(path.iterdir()):
            data=p.read_bytes();assert not re.search(rb'postgres(?:ql)?://',data),p
            if p.suffix=='.json':assert json.loads(data)['valid'],p
            (dest/(p.name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
for path in sorted(work.glob('relations_*.py'))+sorted(work.glob('relations_*.sh')):
    data=path.read_bytes();p=base/(path.name+'.gz');assert not p.exists()
    p.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(p.read_bytes())==data
(base/'native-summary.json').write_text(json.dumps({'code':code,'test_only_reuse_successor':latest,'native':totals,'strict':controls,'reuse_successor':{'memory':8,'dual_grant_controls':2}},indent=2)+'\n')
(base/'reproduce.md').write_text(f'''Copy these evidence inputs outside the repository before checking out older
source, and preserve all existing dirty worktrees. The archived helpers retain
the original local WSL checkout/setup and host helper paths; restore there or
adjust only local paths. Require a real throwaway PostgreSQL URL.

At `{code}`, run archived `relations_frozen.sh` with
`relations_strict_controls.py` restored at its referenced host path. At
`{latest}`, run `relations_reuse_frozen.sh {latest}` with
`relations_reuse_controls.py` restored. Both runners require clean source and
check the source again at completion. Other archived one-shot writers describe
earlier inputs; do not apply them to final source. Raw native per-binary receipts
and strict JSON exit/inventory validation are gzip-compressed in strict folders.
Earlier working red/setup-failure logs are retained with their original names;
only frozen/reuse receipts are acceptance. No browser/whole-CI/app-port claim.
''')
files=sorted(p for p in base.rglob('*') if p.is_file())
(base/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(base)}\n' for p in files))
record=f'''# Protected feed/store prerequisite: fixed relation windows

Design preceded implementation at `07c33f3f`. Implementation checkpoint
`275ca488` and strengthened frozen source `{code}` are independently reviewed.
The test-only authorization-reuse successor is `{latest}`. No runtime or adapter
bytes changed at that successor. **Canonical feed/store still use legacy Rust
data layers.** This source-scoped prerequisite does not complete their ports.

## Behavior

A declared relation returns public target rows selected by membership in an
owned/shared/public source table, using both explicit source identities and
declared lookup paths. Compiler nominal/refinement identity and target-row
annotation visibility are checked; the host independently checks stored types,
source/target metadata, public target/order, complete ABI and both table grants
in the contract and actual Granted set. An unused import or compiled predicate
cannot borrow the body target's authority. Reader handles remain caller-bound;
private source fields do not reach target rows. Owner-only private matching is
allowed; a sharer path revealing a private match is refused.

First/last is one GLOBAL target window per source selector, complete target
order+PK including ties. Duplicate edges use EXISTS semantics, not duplicate
target rows. Every eligible set form uses one common limit and returns canonical
key/rows groups including zeros; overlapping groups may each contain the same
target PK. The gate checks exact source group coverage/order/membership and
per-group target row ABI, order, uniqueness and bounds.

Memory retains bounded borrowed target references while looking up memberships.
PostgreSQL runs one scalar EXISTS query or typed-array/ordinality/LATERAL query
with LIMIT inside each selector. At12/1500 authors with3posts each, scalar N2
returns2 SQL rows and <=700 fixture payload bytes under10000fuel; set returns4
rows for2matching groups plus a missing group, <=1400bytes under20000fuel.
Unbounded neighbors grow. This bounds returned result work, not internal DB scans.

Staged predicate/body reads see both staged membership and target writes; held
snapshots pin both while a later writer changes both. Real warm resource-cache
checks run on memory and PostgreSQL: Alice/Bob get different sentinels, repeated
reads add no adapter/table calls, and Bob cannot reuse Alice's warmed reader key.
The successor checks actual `authorize_with_tables_as` with permitted/refused
neighbors, a missing predicate target requirement, predicate reads and body0.

A real transition bug found during implementation is repaired: old-guest owner
classification must use the source membership PK, not the public target PK.
The new SourceKey witness went native red before repair. Review also found a
PW0405 literal plus and several false-green proof gaps; regression witnesses
now isolate each condition. Source-only review and raw native receipts are
recorded separately; they are not hosted landing evidence.

## Frozen local checks

At `{code}`: compiler350, CLI5, host118 (9existingignored), memory132,
PostgreSQL95, selectedserver180; test-compile and preflight5253anchors pass.
Strict complete-inventory campaigns: PG11/11 (baseline95), row14/14 (232),
data7/7 (85), bounded2/2 (40), host2/2 (171). No invalid/surviving controls or
instrument-stopped processes receive credit. Sources restored clean.

The23 new relation faults include wrong source/match, duplicate joins, global
set limit, independent grant axes, schema/type/visibility, SourceKey authority,
group coverage/order and memory selection/bounds. Older moved controls still
kill on their original ordinary paths. Correct-answer fetchall and per-author
then-hostclip faults each use ONE SQL and pass final-answer equality; the real
row counter catches36 and24 rows respectively instead of2 at the small fixture.
The per-key SQL fault preserves answers and is caught by the operation count.

At the test-only successor: memory8, preflight5253 and strict dual-grant2/2
(baseline8) pass with exact source/clean guards. Earlier source results remain
scoped to their named SHA. [Raw evidence](../evidence/E14/protected-relations-2026-11-04/)
includes command inputs, per-binary native/strict receipts and SHA256SUMS.

## Remaining migration

Generic upload claim/publication/reference/collection lifetime is next. Its
existing startup refusal remains. Public initialization, stable IDs/private
child deletion as required, canonical Pleris feed/store ports, deletion of their
legacy data adapters, unchanged assertions, final whole campaigns/browser/CI
and independent final review remain open. H3/H4, remote landing, production
conversion and paid benchmarks are outside this local prerequisite claim.
'''
(root/'docs/diagnostics/protected-feed-store-relations-2026-11-04.md').write_text(record)
for path in files:
    assert hashlib.sha256(path.read_bytes()).hexdigest() in (base/'SHA256SUMS').read_text()
print(f'archived {len(files)} hashed relation inputs/receipts')
