from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'examples/relations/app.pw';assert not p.exists()
p.write_text('''// @corpus: fixture
// @id: RELATION-app
// @category: compiled relation read retains source-derived reader privacy
// @milestone: E14

module relations.app
import RelationPosts
import RelationMembers
import capability.{ User, UserId }

user query Following(reader: User<UserId>, topic: Int, limit: Int) -> List<RelationPosts.Post>
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader,topic,limit
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    RelationMembers.last_posts_by_reader_topic(reader,topic,limit)
}
''')
def change(path,old,new):
    p=root/path;s=p.read_text();assert s.count(old)==1,(path,s.count(old));p.write_text(s.replace(old,new,1))
change('scripts/d3_postgres_mutations.py','TESTS = [\n','TESTS = [\n    ["cargo", "test", "--quiet", "--locked", "-p", "pw-table-postgres", "--test", "compiled_relations"],\n')
change('scripts/row_ownership_mutations.py','TESTS = [\n','TESTS = [\n    ["cargo", "test", "--quiet", "--locked", "-p", "pw-core", "--test", "table_relations"],\n    ["cargo", "test", "--quiet", "--locked", "-p", "pw-table-memory", "--test", "compiled_relations"],\n')
change('scripts/row_ownership_mutations.py','SOURCES = [\n','SOURCES = [\n    ROOT / "compiler/pw-core/tests/table_relations.rs",\n    ROOT / "runtime/pw-table-memory/tests/compiled_relations.rs",\n    ROOT / "runtime/pw-table-memory/tests/support/relations.rs",\n')
change('scripts/data_path_mutations.py','TESTS = [\n','TESTS = [\n    (["cargo", "test", "--quiet", "--locked", "-p", "pw-table-memory", "--test", "compiled_relations"], []),\n')
change('scripts/data_path_mutations.py','SOURCES = [\n','SOURCES = [\n    ROOT / "runtime/pw-table-memory/tests/compiled_relations.rs",\n    ROOT / "runtime/pw-table-memory/tests/support/relations.rs",\n')
change('just/d3-postgres.just','for binary in compiled_ranges','for binary in compiled_relations compiled_ranges')
change('just/row-ownership.just','--test table_owners --test table_counts --test table_windows --test table_ranges','--test table_owners --test table_counts --test table_windows --test table_ranges --test table_relations')
change('just/row-ownership.just','--test compiled_owners --test compiled_counts --test compiled_windows --test compiled_ranges','--test compiled_owners --test compiled_counts --test compiled_windows --test compiled_ranges --test compiled_relations')
change('just/data-path.just','--test compiled_windows --test compiled_ranges','--test compiled_windows --test compiled_ranges --test compiled_relations')
