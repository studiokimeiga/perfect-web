from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
support=root/'runtime/pw-table-memory/tests/support/relations.rs'
test=root/'runtime/pw-table-memory/tests/compiled_relations.rs'
assert not support.exists() and not test.exists()
support.write_text(r'''// One standalone compiled relation program, reused by both generic adapters.
fn relation_program() -> Program {
    let roots=r#"module Roots
import capability.{ UserId }
type Root = Root { id: Int, author: UserId, stamp: Int, text: String }
table Roots
    row Root
    key id
    order stamp
    index by_author on author
"#;
    let links=r#"module Links
import Roots
import capability.{ UserId }
type Link = Link { reader: UserId, topic: Int, author: UserId, edge: Int, to: UserId, secret: String }
table Links
    row Link
    key reader, topic, author, edge
    order edge
    index by_recipient_topic_author on to, topic, author
    owned by reader
    shares with to
    private secret
    window posts from Roots row Roots.Root on author to author
"#;
    let data=r#"module RelationData
import Roots
import Links
source RelationData
    holds Roots, Links
    transactions serializable
    reads strong
    changes none
    sets one_call
"#;
    let mut app="module owned.app\nimport List\nimport Roots\nimport Links\nimport capability.{ User, UserId }\n".to_string();
    for (name,returns,body) in [
        ("RelFirst","List<Roots.Root>","Links.first_posts_by_reader_topic(reader,topic,n)"),
        ("RelLast","List<Roots.Root>","Links.last_posts_by_reader_topic(reader,topic,n)"),
        ("RelShared","List<Roots.Root>","Links.first_posts_by_to_topic(reader,topic,n)"),
    ] {
        app.push_str(&format!("\nuser query {name}(reader: User<UserId>, topic: Int, n: Int) -> {returns}\n    freshness 0.seconds\n    consistency read_your_writes\n    cache private\n    key reader,topic,n\n    concurrency one_per_key\n    on_key_change cancel\n    timeout 2.seconds\n{{\n    {body}\n}}\n"));
    }
    for (name,returns,body) in [
        ("RelMany","List<Links.LinksReaderTopicPostsWindow>","Links.last_posts_by_reader_topic_many(reader,topics,n)"),
        ("RelSharedMany","List<Links.LinksToTopicPostsWindow>","Links.first_posts_by_to_topic_many(reader,topics,n)"),
    ] {
        app.push_str(&format!("\nuser query {name}(reader: User<UserId>, topics: List<Int>, n: Int) -> {returns}\n    freshness 0.seconds\n    consistency read_your_writes\n    cache private\n    key reader,topics,n\n    concurrency one_per_key\n    on_key_change cancel\n    timeout 2.seconds\n{{\n    {body}\n}}\n"));
    }
    built_from(&[("Roots.pw",roots),("Links.pw",links),("RelationData.pw",data),("app.pw",&app)])
}

fn relation_roots() -> Vec<serde_json::Value> {
    [(1,BOB,1,"B1"),(2,CAROL,2,"C2"),(3,BOB,3,"B3"),(4,CAROL,3,"C3"),(5,ALICE,99,"other-reader-sentinel")]
        .into_iter().map(|(id,author,stamp,text)|json!({"id":id,"author":author,"stamp":stamp,"text":text})).collect()
}
fn relation_links() -> Vec<serde_json::Value> {
    [(ALICE,10,BOB,1,BOB),(ALICE,10,BOB,2,BOB),(ALICE,10,CAROL,3,BOB),(ALICE,20,BOB,4,BOB),
     (BOB,10,ALICE,5,CAROL),(CAROL,10,ALICE,6,ALICE)]
        .into_iter().map(|(reader,topic,author,edge,to)|json!({"reader":reader,"topic":topic,"author":author,"edge":edge,"to":to,"secret":format!("{reader} private membership metadata")})).collect()
}
fn relation_root_value(id:i64)->Val {
    let row=relation_roots().into_iter().find(|r|r["id"]==id).unwrap();
    Val::Record(vec![("id".into(),Val::S64(id)),("author".into(),Val::String(row["author"].as_str().unwrap().into())),
        ("stamp".into(),Val::S64(row["stamp"].as_i64().unwrap())),("text".into(),Val::String(row["text"].as_str().unwrap().into()))])
}
fn relation_group(reader_field:&str, reader:&str, topic:i64, ids:&[i64])->Val {
    Val::Record(vec![("key".into(),Val::Record(vec![(reader_field.into(),Val::String(reader.into())),("topic".into(),Val::S64(topic))])),
        ("rows".into(),Val::List(ids.iter().map(|id|relation_root_value(*id)).collect()))])
}
''')
test.write_text(r'''//! Global relation windows execute actual compiled owned/sharer imports.
#![allow(dead_code)]
include!("support/owned.rs");
include!("support/relations.rs");

#[test]
fn compiled_relation_windows_are_global_and_sets_keep_overlapping_empty_groups() {
    let program=relation_program();
    let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");
    tables.transaction(|tx|{
        for row in relation_roots() {tx.write("pw:tables/roots#insert",&[row])?;}
        for row in relation_links() {tx.write("pw:tables/links#insert",&[row])?;}
        Ok(())
    }).assert_ok("seed independent public posts/private edges");
    for (name,ids) in [("RelFirst",vec![1,2]),("RelLast",vec![4,3])] {
        assert_eq!(query(&program,&tables,name,&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(2)]),
            Ok(vec![Val::List(ids.into_iter().map(relation_root_value).collect())]));
    }
    assert_eq!(query(&program,&tables,"RelMany",&as_user(ALICE),&[handle(ALICE),Val::List(vec![Val::S64(20),Val::S64(999),Val::S64(10),Val::S64(10)]),Val::S64(2)]),
        Ok(vec![Val::List(vec![relation_group("reader",ALICE,10,&[4,3]),relation_group("reader",ALICE,20,&[3,1]),relation_group("reader",ALICE,999,&[])])]));
    assert_eq!(query(&program,&tables,"RelLast",&as_user(BOB),&[handle(BOB),Val::S64(10),Val::S64(2)]),Ok(vec![Val::List(vec![relation_root_value(5)])]));
    assert_eq!(query(&program,&tables,"RelSharedMany",&as_user(BOB),&[handle(BOB),Val::List(vec![Val::S64(999),Val::S64(10)]),Val::S64(2)]),
        Ok(vec![Val::List(vec![relation_group("to",BOB,10,&[1,2]),relation_group("to",BOB,999,&[])])]));
    for n in [0,-9] {
        assert_eq!(query(&program,&tables,"RelLast",&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(n)]),Ok(vec![Val::List(vec![])]));
    }
    assert_eq!(query(&program,&tables,"RelLast",&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(i64::MAX)]),
        Ok(vec![Val::List([4,3,2,1].into_iter().map(relation_root_value).collect())]));
}

#[test]
fn a_relation_never_uses_another_readers_memberships() {
    let program=relation_program();
    let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");
    let before=tables.operation_statements();
    let forged=query(&program,&tables,"RelLast",&as_user(ALICE),&[handle(BOB),Val::S64(10),Val::S64(0)]);
    assert!(forged.is_err(),"forged reader even at zero: {forged:?}");
    let absent=query(&program,&tables,"RelLast",&Caller::None,&[handle(ALICE),Val::S64(10),Val::S64(2)]);
    assert!(absent.is_err(),"no caller: {absent:?}");
    assert_eq!(tables.operation_statements()-before,0,"no adapter calls");
}
''')
