from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/spikes/own-renderer/server/src/tests/conformance.rs');s=p.read_text()
old='''fn published(s: &Server, table: &Table, row: &Map<String, Json>) -> Vec<Val> {
    let [(reads, granted), _] = suite_contracts(std::slice::from_ref(table));''';assert s.count(old)==1
s=s.replace(old,'''fn published(s: &Server, table: &Table, row: &Map<String, Json>) -> Vec<Val> {
    let mut only_get=table.clone();
    only_get.functions.retain(|f|f.primitive=="get");
    let [(reads, granted), _] = suite_contracts(std::slice::from_ref(&only_get));''')
old='''fn held(s: &Server, table: &Table) -> usize {
    let [(reads, granted), _] = suite_contracts(std::slice::from_ref(table));''';assert s.count(old)==1
s=s.replace(old,'''fn held(s: &Server, table: &Table) -> usize {
    let mut only_all=table.clone();
    only_all.functions.retain(|f|f.primitive=="all");
    let [(reads, granted), _] = suite_contracts(std::slice::from_ref(&only_all));''')
p.write_text(s)
