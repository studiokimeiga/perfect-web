from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/runtime/pw-table-postgres/tests/compiled_relations.rs');s=p.read_text()
assert 'growing_membership' not in s
p.write_text(s+r'''

#[test]
fn relation_result_work_is_bounded_across_growing_membership_and_target_cardinality() {
    let program=relation_program();
    let Some(url)=common::database() else{return;};
    for size in [12i64,1500] {
        let scratch=common::Scratch::new(&url,"relation_result_work");
        let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");
        let text="T".repeat(280);
        tables.transaction(|tx|{
            for author in 0..size {
                let author_id=format!("author-{author}");
                for topic in [10,20] {
                    tx.write("pw:tables/links#insert",&[json!({"reader":ALICE,"topic":topic,"author":author_id,"edge":author,"to":BOB,"secret":text})])?;
                }
                for item in 1..=3 {
                    let id=author*3+item;
                    tx.write("pw:tables/roots#insert",&[json!({"id":id,"author":author_id,"stamp":id,"text":text})])?;
                }
            }
            Ok(())
        }).assert_ok("many members and posts");
        let row=|id|Val::Record(vec![("id".into(),Val::S64(id)),("author".into(),Val::String(format!("author-{}",(id-1)/3))),
            ("stamp".into(),Val::S64(id)),("text".into(),Val::String(text.clone()))]);
        let mut limits=pw_host::Limits::unbounded();limits.fuel=Some(10_000);
        let ops=tables.operation_statements();let rows=tables.returned_rows();let bytes=tables.returned_bytes();
        let scalar=q_limited(&program,&tables,"RelLast",&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(2)],&Arc::default(),&limits);
        assert_eq!(scalar,Ok(vec![Val::List(vec![row(size*3),row(size*3-1)])]),"same scalar fuel ceiling at{size}");
        assert_eq!(tables.operation_statements()-ops,1,"one global query at{size}");
        assert_eq!(tables.returned_rows()-rows,2,"only final target rows cross SQL at{size}");
        assert!(tables.returned_bytes()-bytes<=700,"bounded fixture payload at{size}: {}",tables.returned_bytes()-bytes);
        limits.fuel=Some(20_000);
        let ops=tables.operation_statements();let rows=tables.returned_rows();let bytes=tables.returned_bytes();
        let input=[handle(ALICE),Val::List(vec![Val::S64(20),Val::S64(999),Val::S64(10),Val::S64(10)]),Val::S64(2)];
        let group=|topic|Val::Record(vec![("key".into(),Val::Record(vec![("reader".into(),handle(ALICE)),("topic".into(),Val::S64(topic))])),
            ("rows".into(),Val::List(if topic==999 {vec![]}else{vec![row(size*3),row(size*3-1)]}))]);
        assert_eq!(q_limited(&program,&tables,"RelMany",&as_user(ALICE),&input,&Arc::default(),&limits),Ok(vec![Val::List(vec![group(10),group(20),group(999)])]),"same set fuel ceiling at{size}");
        assert_eq!(tables.operation_statements()-ops,1,"one lateral query for all distinct keys");
        assert_eq!(tables.returned_rows()-rows,4,"per-selector global limit, duplicates coalesced, no fake absent target");
        assert!(tables.returned_bytes()-bytes<=1400,"four bounded payloads including slots at{size}: {}",tables.returned_bytes()-bytes);
        limits.fuel=Some(1);
        assert!(q_limited(&program,&tables,"RelLast",&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(2)],&Arc::default(),&limits).is_err(),"fuel ceiling has a failing neighbor");
        let rows=tables.returned_rows();let bytes=tables.returned_bytes();
        let all=tables.read("pw:tables/links#of-reader",&[json!(ALICE)]).assert_ok("unbounded membership neighbor");
        assert_eq!(all.as_array().unwrap().len(),(size*2) as usize);
        assert_eq!(tables.returned_rows()-rows,(size*2) as u64);
        assert!(tables.returned_bytes()-bytes>(size*2*280) as u64,"all-membership materialization grows");
        let rows=tables.returned_rows();
        let all=tables.read("pw:tables/links#last-posts-by-reader-topic",&[json!(ALICE),json!(10),json!(i64::MAX)]).assert_ok("explicit all qualifying targets neighbor");
        assert_eq!(all.as_array().unwrap().len(),(size*3) as usize);
        assert_eq!(tables.returned_rows()-rows,(size*3) as u64,"many targets really qualify for the small global window");
    }
}
''')
