from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/runtime/pw-table-memory/tests/compiled_relations.rs');s=p.read_text()
assert 'relation_reply_gate' not in s
p.write_text(s+r'''

fn relation_fake(program:&Program,id:&str,args:&[Val],answer:serde_json::Value)->Result<Vec<Val>,String> {
    let component=program.component(id);
    let granted=component.granted();
    let reads=program.manifest.admit_reads(&component.contract,&granted).assert_ok("fake callback admitted");
    let mut host=program.platform(ALICE);
    for (key,read) in reads {
        let answer=answer.clone();
        host.insert(key,pw_host::engine::table_read_host::host_fn(read,Arc::new(move |_|Ok(answer.clone()))));
    }
    pw_host::engine::call_with_tables_as(&component.bytes,&component.contract,&granted,&pw_host::Limits::unbounded(),&host,&program.manifest,&as_user(ALICE),&component.export(),args)
}

#[test]
fn the_relation_reply_gate_checks_nested_groups_and_target_rows_whole() {
    let program=relation_program();
    let rows=relation_roots();
    let scalar_args=[handle(ALICE),Val::S64(10),Val::S64(2)];
    assert_eq!(relation_fake(&program,"RelLast",&scalar_args,json!([rows[3],rows[2]])),Ok(vec![Val::List(vec![relation_root_value(4),relation_root_value(3)])]));
    for bad in [json!([rows[2],rows[3]]),json!([rows[3],rows[3]]),json!([rows[3],rows[2],rows[1]]),json!([{"id":4,"author":CAROL,"stamp":3,"text":"C3","secret":"foreign source metadata"}]),json!([{"id":4,"author":CAROL,"stamp":3}])] {
        let result=relation_fake(&program,"RelLast",&scalar_args,bad.clone());
        assert!(result.is_err(),"malformed scalar target {bad}: {result:?}");
    }
    let group=|topic,ids:&[usize]|json!({"key":{"reader":ALICE,"topic":topic},"rows":ids.iter().map(|i|rows[*i].clone()).collect::<Vec<_>>()});
    let args=[handle(ALICE),Val::List(vec![Val::S64(20),Val::S64(10),Val::S64(10),Val::S64(999)]),Val::S64(2)];
    let valid=json!([group(10,&[3,2]),group(20,&[2,0]),group(999,&[])]);
    assert_eq!(relation_fake(&program,"RelMany",&args,valid.clone()),Ok(vec![Val::List(vec![relation_group("reader",ALICE,10,&[4,3]),relation_group("reader",ALICE,20,&[3,1]),relation_group("reader",ALICE,999,&[])])]));
    let mut foreign=valid.clone();foreign[0]["key"]["reader"]=json!(BOB);
    let mut extra=valid.clone();extra[0]["extra"]=json!(true);
    for bad in [json!([group(10,&[3,2]),group(20,&[2,0])]),json!([group(20,&[2,0]),group(10,&[3,2]),group(999,&[])]),json!([group(10,&[3,2]),group(10,&[]),group(20,&[2,0]),group(999,&[])]),json!([group(10,&[3,2,1]),group(20,&[2,0]),group(999,&[])]),json!([group(10,&[2,3]),group(20,&[2,0]),group(999,&[])]),foreign,extra,json!([])] {
        let result=relation_fake(&program,"RelMany",&args,bad.clone());
        assert!(result.is_err(),"malformed nested relation reply {bad}: {result:?}");
    }
}
''')
