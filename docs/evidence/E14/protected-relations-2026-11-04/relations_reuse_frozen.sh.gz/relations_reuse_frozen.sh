#!/bin/bash
set -euo pipefail
cd /home/haki/code/pw-wt/data-path
source /home/haki/pw-setup/env.sh
expected="${1:?exact successor SHA required}"
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
log=/tmp/pw-protected-migration
git rev-parse HEAD > "$log/relations-reuse-source.txt"
cargo test --locked -p pw-table-memory --test compiled_relations > "$log/relations-reuse-memory.log" 2>&1
just preflight > "$log/relations-reuse-preflight.log" 2>&1
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration/relations_reuse_controls.py > "$log/relations-reuse-controls.log" 2>&1
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> "$log/relations-reuse-source.txt"
echo 0 > "$log/relations-reuse.exit"
