from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
for name,old,new in [
('d3-postgres','compiled_windows compiled_ranges; do','compiled_windows compiled_ranges compiled_relations; do'),
('row-ownership','--test table_owners --test table_counts --test table_windows --test table_ranges;','--test table_owners --test table_counts --test table_windows --test table_ranges --test table_relations;'),
('row-ownership','--test compiled_owners --test compiled_counts --test compiled_windows --test compiled_ranges;','--test compiled_owners --test compiled_counts --test compiled_windows --test compiled_ranges --test compiled_relations;'),
('data-path','--test compiled_guarded --test compiled_snapshot --test compiled_ranges;','--test compiled_guarded --test compiled_snapshot --test compiled_ranges --test compiled_relations;'),
]:
    p=root/f'just/{name}.just';s=p.read_text();assert s.count(old)==1,(name,old);p.write_text(s.replace(old,new,1))
