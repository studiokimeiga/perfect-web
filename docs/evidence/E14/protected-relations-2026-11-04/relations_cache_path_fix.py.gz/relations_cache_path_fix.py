from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/spikes/own-renderer/server/src/tests/conformance.rs')
s=p.read_text();start=s.index('pub(super) fn warm_relation_cache(');end=s.index('\n#[test]',start)
a=s[start:end];assert a.count('s.answer(')==6
a=a.replace('    let query = "relations.app.Following";','''    let binding = serde_json::json!({
        "resource":"relations.app.Following",
        "policy":{"freshness_ms":30_000,"cache":"private","privacy":"user","key":[0,1,2]}
    });''')
import re
a=re.sub(r's.answer\(query,\s*"([ab])",\s*',r's.fetch_answer("\1", &binding, ',a)
assert 's.answer(' not in a
p.write_text(s[:start]+a+s[end:])
