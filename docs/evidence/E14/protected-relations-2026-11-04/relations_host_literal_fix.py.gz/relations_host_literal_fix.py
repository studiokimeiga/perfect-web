from pathlib import Path
import re
root=Path('/home/haki/code/pw-wt/data-path')
count=0
for name in ['table_selectors','table_results','table_read_host','table_link','table_owners']:
    p=root/f'runtime/pw-host/src/engine/{name}.rs';s=p.read_text()
    pattern=r'(?m)^(\s*)(?:Read \{|Access::Read\(Read \{|let own = Access::Read\(Read \{)\n'
    s,n=re.subn(pattern,lambda m:m[0]+m[1]+'    target: None,\n',s)
    count+=n;p.write_text(s)
assert count==6,count
p=root/'runtime/pw-table-memory/src/lib.rs';s=p.read_text();assert s.count('    source_match: String,')==1
s=s.replace('    source_match: String,\n','')
old='                    source_match: window.source_field.clone(),\n';assert s.count(old)==1
p.write_text(s.replace(old,''))
