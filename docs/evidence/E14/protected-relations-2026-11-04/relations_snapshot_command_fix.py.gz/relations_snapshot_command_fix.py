from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-table-memory/tests/support/relations.rs';s=p.read_text()
old='user query RelHeld(reader: User<UserId>, topic: Int, id: Int)';assert s.count(old)==1
new='''command RelGuarded(topic: Int, id: Int) -> Option<Roots.Root>
    requires Selected(topic,id)
    transaction serializable
{
    Roots.get(id)
}
user query RelHeld(reader: User<UserId>, topic: Int, id: Int)'''
p.write_text(s.replace(old,new))
for crate in ['pw-table-memory','pw-table-postgres']:
    p=root/f'runtime/{crate}/tests/compiled_relations.rs';s=p.read_text()
    old='authorized(&program,"RelHeld",ALICE,&command,&pw_host::Limits::unbounded(),&args,false,&asked)';assert s.count(old)==1
    p.write_text(s.replace(old,'authorized(&program,"RelGuarded",ALICE,&command,&pw_host::Limits::unbounded(),&[Val::S64(77),Val::S64(6)],false,&asked)'))
