from pathlib import Path
p=Path('/home/haki/code/pw-wt/data-path/compiler/pw-core/src/bounded.rs');s=p.read_text()
old="\n+                 match each turn's key/rows group";assert s.count(old)==1
p.write_text(s.replace(old,"\n                 match each turn's key/rows group"))
