from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')

def change(path, old, new):
    p=root/path
    s=p.read_text()
    assert s.count(old)==1,(path,s.count(old),old[:100])
    p.write_text(s.replace(old,new,1))

path='compiler/pw-core/src/tables.rs'
change(path,'use std::collections::{BTreeMap, BTreeSet};','use std::collections::{BTreeMap, BTreeSet};\n\nmod relations;')
change(path,'    /// Every row, of a bounded table.\n    All,','''    /// Global target rows selected through one declared membership relation.
    RelatedFirst,
    RelatedFirstMany,
    RelatedLast,
    RelatedLastMany,
    /// Every row, of a bounded table.
    All,''')
change(path,'            Primitive::All => "all",','''            Primitive::RelatedFirst => "related-first",
            Primitive::RelatedFirstMany => "related-first-many",
            Primitive::RelatedLast => "related-last",
            Primitive::RelatedLastMany => "related-last-many",
            Primitive::All => "all",''')
change(path,'    pub fn window(self) -> bool {','''    pub fn related(self) -> bool {
        matches!(self, Self::RelatedFirst | Self::RelatedFirstMany | Self::RelatedLast | Self::RelatedLastMany)
    }

    pub fn window(self) -> bool {''')
change(path,'Primitive::First | Primitive::FirstMany | Primitive::Last | Primitive::LastMany\n','Primitive::First | Primitive::FirstMany | Primitive::Last | Primitive::LastMany\n                | Primitive::RelatedFirst | Primitive::RelatedFirstMany | Primitive::RelatedLast | Primitive::RelatedLastMany\n')
change(path,'matches!(self, Primitive::Last | Primitive::LastMany)','matches!(self, Primitive::Last | Primitive::LastMany | Primitive::RelatedLast | Primitive::RelatedLastMany)')
change(path,'                | Primitive::LastMany\n        )','                | Primitive::LastMany\n                | Primitive::RelatedFirstMany\n                | Primitive::RelatedLastMany\n        )')
change(path,'    RangeCounted { fields: Vec<String> },','''    RangeCounted { fields: Vec<String> },
    /// A full source selector and bounded public target rows.
    RelatedGroup { fields: Vec<String>, window: WindowClause },''')
change(path,'/// `refers owner to Users`.','''/// One fixed equality relation; its row annotation is checked against the target.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct WindowClause {
    pub name: String,
    pub target: String,
    pub row_type: String,
    pub source_field: String,
    pub target_field: String,
}

/// `refers owner to Users`.''')
change(path,'    pub references: Vec<Clause<Reference>>,','    pub references: Vec<Clause<Reference>>,\n    pub windows: Vec<Clause<WindowClause>>,')
change(path,'        references: Vec::new(),\n        bounded: None,','        references: Vec::new(),\n        windows: Vec::new(),\n        bounded: None,')
change(path,'            "refers" => match reference(v) {','''            "window" => match relations::clause(v) {
                Ok(window) => { t.windows.push(clause(window)); None }
                Err(why) => Some(why),
            },
            "refers" => match reference(v) {''')
change(path,'    (out, records, seen)\n}', '''    // Relation meanings are never coalesced by only primitive/by. Their
    // declaration/name/target is retained; duplicate declarations are refused.
    let (related, groups) = relations::planned(t, fields);
    out.extend(related);
    for (decl, what) in groups {
        if !records.iter().any(|(old, kind)| old.name == decl.name && *kind == what) {
            records.push((decl, what));
        }
    }
    (out, records, seen)
}''')
change(path,'            function(&t.name, p),','''            {
                let mut decl = function(&t.name, p);
                if let Some(window) = relations::of_function(&t, &p.name, p.primitive, &p.by) {
                    decl.declared_effects.as_mut().expect("table effects").push(EffectRef {
                        path: "database.read".into(), written: format!("database.read<{}>", window.target),
                        args: vec![window.target.clone()], span: p.span.clone(),
                    });
                }
                decl
            },''')
change(path,'.chain(t.references.iter().map(|r| (&r.value.table, &r.span)))','.chain(t.references.iter().map(|r| (&r.value.table, &r.span)))\n        .chain(t.windows.iter().map(|r| (&r.value.target, &r.span)))')
change(path,'        found.extend(unambiguous_sources(hirs, unit, ws, t));','        found.extend(unambiguous_sources(hirs, unit, ws, t));\n        found.extend(relations::check(hirs, unit, ws, sigs, t));')
change(path,'                    | Wrote::RangeCounted { .. }\n                    | Wrote::Seen { .. }','                    | Wrote::RangeCounted { .. }\n                    | Wrote::RelatedGroup { .. }\n                    | Wrote::Seen { .. }')
change(path,'            | Wrote::RangeCounted { .. }\n            | Wrote::Seen { .. } => None,','            | Wrote::RangeCounted { .. }\n            | Wrote::RelatedGroup { .. }\n            | Wrote::Seen { .. } => None,')
change(path,'    pub returns: String,\n    /// **The order','    pub returns: String,\n    #[serde(default, skip_serializing_if = "Option::is_none")]\n    pub relation: Option<String>,\n    /// **The order')
change(path,'    pub functions: Vec<FunctionJson>,','    #[serde(default, skip_serializing_if = "Vec::is_empty")]\n    pub windows: Vec<WindowClause>,\n    pub functions: Vec<FunctionJson>,')
change(path,'                        sorted_by: sorted_by(schema, primitive, &by),','''                        relation: relations::of_function(t, &d.name, primitive, &by).map(|r|r.name.clone()),
                        sorted_by: match relations::of_function(t, &d.name, primitive, &by) {
                            Some(r) => now.iter().find(|(_,_,s)|s.name==r.target).map(|(_,_,s)|sorted_by(s, Primitive::First, &[])).unwrap_or_default(),
                            None => sorted_by(schema, primitive, &by),
                        },''')
change(path,'                functions,\n            }','                windows: t.windows.iter().map(|w|w.value.clone()).collect(),\n                functions,\n            }')

# The policy value is checked by the table relation checker, like references.
change('compiler/pw-core/src/policy.rs','"refers" => Domain::Reference,','"refers" | "window" => Domain::Reference,')
change('compiler/pw-core/src/policy.rs','"row" | "order" | "index" | "unique" | "refers" | "bounded" =>','"row" | "order" | "index" | "unique" | "refers" | "window" | "bounded" =>')
change('compiler/pw-core/src/policy.rs','        "refers",\n','        "refers",\n        "window",\n')
change('compiler/pw-syntax/src/grammar.rs','"layout", "set", "sets", "row", "order", "index", "unique", "refers", "migrate",','"layout", "set", "sets", "row", "order", "index", "unique", "refers", "window", "migrate",')
change('compiler/pw-syntax/src/grammar.rs','    "refers",\n    "bounded",','    "refers",\n    "window",\n    "bounded",')

directory=root/'compiler/pw-core/src/tables'
directory.mkdir(exist_ok=True)
file=directory/'relations.rs'
assert not file.exists()
file.write_text(r'''//! Fixed one-hop public-target windows, never a query language or optimizer.
use super::*;

pub(super) fn clause(value: &str) -> Result<WindowClause, String> {
    let words=value.split_whitespace().collect::<Vec<_>>();
    match words.as_slice() {
        [name,"from",target,"row",row_type,"on",source_field,"to",target_field]
            if [name,target,source_field,target_field].iter().all(|n|is_name(n))
                && row_type.split('.').all(is_name) => Ok(WindowClause {
                    name:(*name).into(),target:(*target).into(),row_type:(*row_type).into(),
                    source_field:(*source_field).into(),target_field:(*target_field).into(),
                }),
        _=>Err("is written `window <name> from <table> row <row type> on <field> to <field>`".into()),
    }
}

fn selectors(t:&Table, window:&WindowClause)->Vec<(Vec<String>,Span)> {
    let paths=t.key.iter().map(|key|(&key.value,&key.span))
        .chain(t.indexes.iter().map(|index|(&index.value.fields,&index.span)));
    let mut out=Vec::new();
    for (path,span) in paths {
        if let Some(at)=path.iter().position(|field|field==&window.source_field)
            && at>0 {
            let by=path[..at].to_vec();
            if !matches!(reading(t,&by),Reading::Refused) && !out.iter().any(|(old,_)|old==&by) {
                out.push((by,span.clone()));
            }
        }
    }
    out
}

fn name(window:&WindowClause, primitive:Primitive, by:&[String])->String {
    format!("{}_{}_by_{}{}",if primitive.descending(){"last"}else{"first"},window.name,by.join("_"),if primitive.many(){"_many"}else{""})
}

pub(super) fn of_function<'a>(t:&'a Table, function:&str, primitive:Primitive, by:&[String])->Option<&'a WindowClause> {
    primitive.related().then(||t.windows.iter().find(|w|name(&w.value,primitive,by)==function).map(|w|&w.value)).flatten()
}

pub(super) fn planned(t:&Table, fields:&[(String,DeclaredType)])->(Vec<Planned>,Vec<(Decl,Wrote)>) {
    let mut functions=Vec::new();
    let mut records:Vec<(Decl,Wrote)>=Vec::new();
    let list=|ty|DeclaredType::new("List",vec![ty]);
    let ty=|field:&str|fields.iter().find(|(name,_)|name==field).map(|(_,ty)|ty.clone());
    for window in &t.windows {
        for (by,span) in selectors(t,&window.value) {
            if by.iter().any(|field|ty(field).is_none()) {continue;}
            let mut tuple=|held:&[String]| {
                if held.len()==1 {return ty(&held[0]).unwrap();}
                let name=tuple_name(&t.name,held);
                let what=Wrote::Tuple{fields:held.to_vec()};
                if !records.iter().any(|(d,w)|d.name==name && *w==what) {
                    records.push((record(&name,&held.iter().map(|field|(field.clone(),ty(field).unwrap())).collect::<Vec<_>>(),&span),what));
                }
                DeclaredType::new(name,Vec::new())
            };
            let mode=reading(t,&by);
            let mut given=by.iter().map(|field|(field.clone(),ty(field).unwrap())).collect::<Vec<_>>();
            if matches!(mode,Reading::Owner|Reading::Sharer) {
                given[0].1=DeclaredType::new("capability.User",vec![given[0].1.clone()]);
            }
            let target=DeclaredType::new(&window.value.row_type,Vec::new());
            let mut limit="limit".to_string();
            while given.iter().any(|(field,_)|crate::wit::ident(field)==crate::wit::ident(&limit)) {limit.push_str("_bound");}
            let many=match mode {
                Reading::Plain=>Some(vec![("keys".into(),list(tuple(&by)))]),
                Reading::Owner|Reading::Sharer if by.len()>1=>Some(vec![given[0].clone(),
                    ((if crate::wit::ident(&by[0])=="keys" {"keys_values"} else {"keys"}).into(),list(tuple(&by[1..])))]),
                _=>None,
            };
            let group=if many.is_some() {
                let key=tuple(&by);
                let group=format!("{}{}Window",tuple_name(&t.name,&by),pascal(&window.value.name));
                records.push((record(&group,&[("key".into(),key),("rows".into(),list(target.clone()))],&span),
                    Wrote::RelatedGroup{fields:by.clone(),window:window.value.clone()}));
                Some(group)
            }else{None};
            for (single,batch) in [(Primitive::RelatedFirst,Primitive::RelatedFirstMany),(Primitive::RelatedLast,Primitive::RelatedLastMany)] {
                let mut params=given.clone();
                params.push((limit.clone(),DeclaredType::new("Int",Vec::new())));
                functions.push(Planned{name:name(&window.value,single,&by),params,ret:list(target.clone()),primitive:single,by:by.clone(),span:span.clone()});
                if let (Some(mut params),Some(group))=(many.clone(),group.as_ref()) {
                    let mut bound="limit".to_string();
                    while params.iter().any(|(field,_)|crate::wit::ident(field)==crate::wit::ident(&bound)) {bound.push_str("_bound");}
                    params.push((bound,DeclaredType::new("Int",Vec::new())));
                    functions.push(Planned{name:name(&window.value,batch,&by),params,ret:list(DeclaredType::new(group,Vec::new())),primitive:batch,by:by.clone(),span:span.clone()});
                }
            }
        }
    }
    (functions,records)
}

pub(super) fn check(hirs:&[&Hir],unit:usize,ws:&Workspace,sigs:&Signatures,t:&Table)->Vec<Diagnostic> {
    let mut out=Vec::new();
    let mut names=BTreeSet::new();
    let hir=hirs[unit];
    let module=ws.module_of(unit).map(|m|m.name.as_str());
    let source=source_of(hirs,&t.name);
    let source_row=t.row.as_ref().and_then(|row|match ws.resolve_in(unit,Namespace::Type,&row.value) {
        Resolution::Local(def)=>sigs.type_decl(def).and_then(|d|d.record.as_ref()), _=>None,
    });
    for window in &t.windows {
        let w=&window.value;
        let bad=|message:String|malformed(message,window.span.clone(),Vec::new(),"declare one typed relation between tables of the same source".into());
        if !names.insert(crate::wit::ident(&w.name)) {out.push(bad(format!("window `{}` is declared twice",w.name)));}
        let Some((target_unit,target))=table_module(ws,hirs,unit,&w.target) else {
            out.push(bad(format!("window `{}` names no target table `{}` visible here",w.name,w.target)));continue;
        };
        if target.owner.is_some() || !target.private_fields().is_empty() {
            out.push(unseen(format!("window `{}` requires a public target table, but `{}` is protected",w.name,w.target),&window.span,"use a public target table"));
        }
        if source.is_none() || source!=source_of(hirs,&target.name) {
            out.push(bad(format!("window `{}` requires both tables to have the same source, explicitly declared",w.name)));
        }
        if target.order.is_none() {out.push(bad(format!("window `{}` requires a declared target order",w.name)));}
        let target_module=ws.module_of(target_unit).map(|m|m.name.as_str());
        let annotation=sigs.resolve_type(module,hir.decl(t.decl),&DeclaredType::new(&w.row_type,Vec::new()),window.span.clone());
        let target_type=target.row.as_ref().map(|row|sigs.resolve_type(target_module,hirs[target_unit].decl(target.decl),&DeclaredType::new(&row.value,Vec::new()),row.span.clone()));
        if !annotation.resolved().zip(target_type.as_ref().and_then(|r|r.resolved())).is_some_and(|(a,b)|a.same_as(b)) {
            out.push(bad(format!("window `{}` row type `{}` is not the exact declared row type of `{}`",w.name,w.row_type,w.target)));
        }
        let target_row=target_type.as_ref().and_then(|r|r.resolved()).and_then(|r|r.def_id()).and_then(|def|sigs.type_decl(def)).and_then(|d|d.record.as_ref());
        let source_field=source_row.and_then(|row|row.iter().find(|(name,_)|*name==w.source_field)).and_then(|(_,ty)|ty.resolved());
        let target_field=target_row.and_then(|row|row.iter().find(|(name,_)|*name==w.target_field)).and_then(|(_,ty)|ty.resolved());
        if !source_field.zip(target_field).is_some_and(|(a,b)|a.same_as(b) && keyable_at(sigs,a,0).is_ok()) {
            out.push(bad(format!("window `{}` match fields must have the same complete keyable type",w.name)));
        }
        let indexed=target.key.as_ref().is_some_and(|key|key.value.first()==Some(&w.target_field))
            || target.indexes.iter().any(|index|index.value.fields.first()==Some(&w.target_field));
        if !indexed || selectors(t,w).is_empty() {
            out.push(bad(format!("window `{}` requires a declared lookup path for its source selector/match and target match",w.name)));
        }
        if t.private_fields().contains(&w.source_field) && selectors(t,w).iter().any(|(by,_)|matches!(reading(t,by),Reading::Sharer)) {
            out.push(unseen(format!("window `{}` cannot select through private match field `{}` for a sharer",w.name,w.source_field),&window.span,"match only a field in the shared seen row"));
        }
    }
    out
}
''')
print('initial compiler relation declaration/planning/semantic/metadata implementation applied')
