from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-host/src/tables/relations.rs';s=p.read_text()
start=s.index('fn eligible(');end=s.index('\nimpl Manifest',start)
s=s[:start]+'''fn eligible(source:&Table, window:&Window, by:&[String])->bool {
    let path=|fields:&[String]|fields.get(by.len())==Some(&window.source_field) && fields.get(..by.len())==Some(by);
    !by.is_empty() && (path(&source.key) || source.indexes.iter().any(|index|path(&index.fields)))
}
''' +s[end:];p.write_text(s)
p=root/'runtime/pw-table-memory/tests/compiled_relations.rs';s=p.read_text();assert 'relation_manifest_admission' not in s
p.write_text(s+r'''

#[test]
fn relation_manifest_admission_holds_both_tables_and_both_grants_independently() {
    let program=relation_program();
    let component=program.component("RelLast");
    let reads=program.manifest.admit_reads(&component.contract,&component.granted()).assert_ok("dual relation grant");
    let read=reads.get("pw:tables/links#last-posts-by-reader-topic").unwrap();
    assert_eq!(read.table,"Links");
    assert_eq!(read.target.as_deref(),Some("Roots"));
    assert_eq!(read.by.iter().map(|c|c.name.as_str()).collect::<Vec<_>>(),["reader","topic"]);
    assert_eq!(read.row.iter().map(|c|c.name.as_str()).collect::<Vec<_>>(),["id","author","stamp","text"]);
    assert_eq!(read.key,["id"]);
    let shared=program.component("RelShared");
    let shared_reads=program.manifest.admit_reads(&shared.contract,&shared.granted()).assert_ok("shared source relation");
    assert!(shared_reads.values().all(|r|r.handle.as_ref().is_some_and(|h|h.seen.is_none())),"public target must not receive source's seen projection");
    for missing in ["Links","Roots"] {
        let mut contract=component.contract.clone();
        contract.required_capabilities.retain(|cap|cap.name()!=format!("database.read<{missing}>"));
        for import in &mut contract.imports {
            if import.interface=="pw:tables/links" {import.capability=format!("database.read<{}>",if missing=="Roots" {"Links"}else{"Roots"});}
        }
        let absent=Component{bytes:component.bytes.clone(),imports:component.imports.clone(),contract};
        let result=program.manifest.admit_reads(&absent.contract,&absent.granted());
        assert!(result.is_err(),"missing contract AND actual grant {missing}: {result:?}");
        assert!(result.unwrap_err().contains(missing));
    }
    let mut contract=component.contract.clone();
    for import in &mut contract.imports {
        if import.interface=="pw:tables/links" {import.capability="database.read<Roots>".into();}
    }
    assert!(program.manifest.admit_reads(&contract,&component.granted()).is_ok(),"either canonical primary claim is valid when both grants are required/held");
    let original=serde_json::to_value(&program.tables).unwrap();
    for kind in ["source-absent","source-other","target-owned","target-order","match-kind","match-refinement","repeated-relation","function-relation","source-sort"] {
        let mut value=original.clone();
        let tables=value["tables"].as_array_mut().unwrap();
        let source=tables.iter().position(|t|t["name"]=="Links").unwrap();
        let target=tables.iter().position(|t|t["name"]=="Roots").unwrap();
        match kind {
            "source-absent"=>{tables[source]["source"]=serde_json::Value::Null;},
            "source-other"=>{tables[target]["source"]=json!("AnotherSource");},
            "target-owned"=>{tables[target]["owner"]=json!("author");},
            "target-order"=>{tables[target]["order"]=serde_json::Value::Null;},
            "match-kind"|"match-refinement"=>{
                let field=tables[target]["fields"].as_array_mut().unwrap().iter_mut().find(|f|f["name"]=="author").unwrap();
                field["stored"]=if kind=="match-kind" {json!({"int":{}})} else {json!({"string":{"min_length":1}})};
            },
            "repeated-relation"=>{let duplicate=tables[source]["windows"][0].clone();tables[source]["windows"].as_array_mut().unwrap().push(duplicate);},
            "function-relation"|"source-sort"=>{
                let function=tables[source]["functions"].as_array_mut().unwrap().iter_mut().find(|f|f["name"]=="last_posts_by_reader_topic").unwrap();
                if kind=="function-relation" {function.as_object_mut().unwrap().remove("relation");}
                else {function["sorted_by"]=json!(["reader","topic"]);}
            },
            _=>unreachable!(),
        }
        let result=pw_host::tables::Manifest::from_json(&value.to_string());
        assert!(result.is_err(),"forged {kind} manifest admitted: {result:?}");
    }
}
''')
