from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
def change(path,old,new):
    p=root/path;s=p.read_text();assert s.count(old)==1,(path,s.count(old),old[:80]);p.write_text(s.replace(old,new,1))
path='runtime/pw-host/src/tables.rs'
change(path,'use serde::Deserialize;','use serde::Deserialize;\n\nmod relations;')
change(path,'struct Table {\n    name: String,','struct Table {\n    name: String,\n    #[serde(default)]\n    source: Option<String>,\n    #[serde(default)]\n    windows: Vec<Window>,')
change(path,'/// `refers owner to Users`, as tables.json states it.','''/// A fixed public-target relation declared by the source table.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
struct Window {
    name: String,
    target: String,
    source_field: String,
    target_field: String,
}

/// `refers owner to Users`, as tables.json states it.''')
change(path,'    LastMany,\n    All,','    LastMany,\n    RelatedFirst,\n    RelatedFirstMany,\n    RelatedLast,\n    RelatedLastMany,\n    All,')
change(path,'                | Primitive::LastMany\n        )','                | Primitive::LastMany\n                | Primitive::RelatedFirstMany\n                | Primitive::RelatedLastMany\n        )')
change(path,'            Primitive::All => "all",','''            Primitive::RelatedFirst => "related-first",
            Primitive::RelatedFirstMany => "related-first-many",
            Primitive::RelatedLast => "related-last",
            Primitive::RelatedLastMany => "related-last-many",
            Primitive::All => "all",''')
change(path,'    pub fn window(self) -> bool {','''    pub fn related(self) -> bool {
        matches!(self, Self::RelatedFirst | Self::RelatedFirstMany | Self::RelatedLast | Self::RelatedLastMany)
    }

    pub fn window(self) -> bool {''')
change(path,'Primitive::First | Primitive::FirstMany | Primitive::Last | Primitive::LastMany\n','Primitive::First | Primitive::FirstMany | Primitive::Last | Primitive::LastMany\n                | Primitive::RelatedFirst | Primitive::RelatedFirstMany | Primitive::RelatedLast | Primitive::RelatedLastMany\n')
change(path,'matches!(self, Primitive::Last | Primitive::LastMany)','matches!(self, Primitive::Last | Primitive::LastMany | Primitive::RelatedLast | Primitive::RelatedLastMany)')
change(path,'            | Primitive::LastMany => "selector",','            | Primitive::LastMany\n            | Primitive::RelatedFirst | Primitive::RelatedFirstMany | Primitive::RelatedLast | Primitive::RelatedLastMany => "selector",')
change(path,'struct Function {\n    name: String,','struct Function {\n    name: String,\n    #[serde(default)]\n    relation: Option<String>,')
change(path,'pub struct Read {\n','pub struct Read {\n    /// The public target of a relation; by/table/handle still describe its source.\n    pub target: Option<String>,\n')
change(path,'            Primitive::CountAfter | Primitive::CountAfterMany => {','''            Primitive::RelatedFirst | Primitive::RelatedFirstMany | Primitive::RelatedLast | Primitive::RelatedLastMany => Err("requires its admitted relation declaration".into()),
            Primitive::CountAfter | Primitive::CountAfterMany => {''')
change(path,'let seen = (sharer && !self.private.is_empty()).then(|| {','let seen = (sharer && !function.primitive.related() && !self.private.is_empty()).then(|| {')
change(path,'        let mut imports = BTreeSet::new();\n        for table in &self.tables {','''        let mut imports = BTreeSet::new();
        let mut tables = BTreeSet::new();
        for table in &self.tables {
            if !tables.insert(wit_name(&table.name)) {
                return Err(format!("tables.json repeats table identity {}",table.name));
            }''')
change(path,'                let generated = table\n                    .generated_name(function.primitive, &function.by)\n                    .map_err(|why| format!("tables.json: `{import}` {why}"))?;','''                let (generated, sorted) = if function.primitive.related() {
                    let (window,target)=self.related_target(table,function)?;
                    (relations::function_name(window,function.primitive,&function.by), target.sorted_by(Primitive::First,&[]))
                } else {
                    if function.relation.is_some() {return Err(format!("tables.json: `{import}` attaches a relation to an ordinary read"));}
                    (table.generated_name(function.primitive, &function.by)
                        .map_err(|why| format!("tables.json: `{import}` {why}"))?,table.sorted_by(function.primitive,&function.by))
                };''')
change(path,'                let sorted = table.sorted_by(function.primitive, &function.by);\n','')
change(path,'        self.references_within_one_owner()','        self.relations_whole()?;\n        self.references_within_one_owner()')
change(path,'            let row: Vec<Column> = table.fields.iter().map(Column::of).collect();','''            let target=if function.primitive.related() {Some(self.related_target(table,function).ok()?.1)} else {None};
            let result=target.unwrap_or(table);
            let row: Vec<Column> = result.fields.iter().map(Column::of).collect();''')
change(path,'            Some(Access::Read(Read {\n                import:','            Some(Access::Read(Read {\n                target: target.map(|t|t.name.clone()),\n                import:')
change(path,'                key: table.key.clone(),\n                order: table.order.clone(),','                key: result.key.clone(),\n                order: result.order.clone(),')
change(path,'                bounded: table.bounded,\n                handle:','                bounded: result.bounded,\n                handle:')
change(path,'            if import.capability != capability {','''            let target=match &access {Access::Read(read)=>read.target.as_ref(),_=>None};
            if let Some(target)=target {
                let required=[capability.clone(),format!("database.read<{target}>")];
                if !required.contains(&import.capability) {
                    return Err(refused(format!("its primary claim `{}` is neither relation read grant",import.capability)));
                }
                for required in required {
                    if !contract.required_capabilities.iter().any(|cap|cap.name()==required) || granted.handle(&required).is_none() {
                        return Err(refused(format!("relation read requires `{required}` in the contract and granted here")));
                    }
                }
            } else if import.capability != capability {''')

directory=root/'runtime/pw-host/src/tables';directory.mkdir(exist_ok=True)
p=directory/'relations.rs';assert not p.exists()
p.write_text(r'''//! Admission for fixed public-target relation windows, independent of the compiler.
use super::*;

pub(super) fn function_name(window:&Window, primitive:Primitive, by:&[String])->String {
    format!("{}_{}_by_{}{}",if primitive.descending(){"last"}else{"first"},window.name,by.join("_"),if primitive.many(){"_many"}else{""})
}

fn scalar(stored:&Stored)->bool {
    matches!(stored,Stored::Int{..}|Stored::String{..}|Stored::Bool)
        || matches!(stored,Stored::Cases(cases) if cases.iter().all(|case|case.carries.is_empty()))
}

fn eligible(source:&Table, window:&Window, by:&[String])->bool {
    !by.is_empty() && source.key.iter().any(|_|true) &&
    source.key.iter().collect::<Vec<_>>().as_slice().get(by.len()).is_some_and(|field|***field==window.source_field)
        && source.key.get(..by.len())==Some(by)
        || (!by.is_empty() && source.indexes.iter().any(|index|index.fields.get(by.len())==Some(&window.source_field) && index.fields.get(..by.len())==Some(by)))
}

impl Manifest {
    pub(super) fn related_target<'a>(&'a self, source:&'a Table, function:&Function)->Result<(&'a Window,&'a Table),String> {
        let name=function.relation.as_ref().ok_or("tables.json: a relation read names no relation")?;
        let window=source.windows.iter().find(|w|w.name==*name).ok_or_else(||format!("tables.json: {} has no relation {name}",source.name))?;
        let target=self.window_target(source,window)?;
        if !eligible(source,window,&function.by) {
            return Err(format!("tables.json: {} relation {name} has no declared selector/match lookup",source.name));
        }
        Ok((window,target))
    }

    fn window_target<'a>(&'a self, source:&Table, window:&Window)->Result<&'a Table,String> {
        let refused=|why:&str|format!("tables.json: {} window {} {why}",source.name,window.name);
        let target=self.tables.iter().find(|target|target.name==window.target).ok_or_else(||refused("names no declared target table"))?;
        if target.owner.is_some() || !target.private.is_empty() || !target.shares.is_empty() {
            return Err(refused("requires a public target table"));
        }
        if source.source.as_ref().is_none_or(|s|s.trim().is_empty()) || source.source!=target.source {
            return Err(refused("requires the same explicit source on both tables"));
        }
        if target.order.is_none() {return Err(refused("requires a declared target order"));}
        let from=source.fields.iter().find(|field|field.name==window.source_field).ok_or_else(||refused("names no source match field"))?;
        let to=target.fields.iter().find(|field|field.name==window.target_field).ok_or_else(||refused("names no target match field"))?;
        if from.stored!=to.stored || !scalar(&from.stored) {return Err(refused("match fields differ in stored kind/refinement or are not scalar"));}
        if target.key.first()!=Some(&window.target_field) && !target.indexes.iter().any(|index|index.fields.first()==Some(&window.target_field)) {
            return Err(refused("has no declared target match lookup"));
        }
        let paths=std::iter::once(source.key.as_slice()).chain(source.indexes.iter().map(|index|index.fields.as_slice()));
        let mut found=false;
        for path in paths {
            if let Some(at)=path.iter().position(|field|field==&window.source_field) && at>0 {
                let by=&path[..at];
                if source.owner.is_none() || by.first()==source.owner.as_ref() || by.first().is_some_and(|first|source.shares.contains(first)) {
                    found=true;
                    if source.private.contains(&window.source_field) && by.first().is_some_and(|first|source.shares.contains(first)) {
                        return Err(refused("reveals a private source match field to a sharer"));
                    }
                }
            }
        }
        if !found {return Err(refused("has no declared source selector/match lookup"));}
        Ok(target)
    }

    pub(super) fn relations_whole(&self)->Result<(),String> {
        for source in &self.tables {
            let mut names=BTreeSet::new();
            for window in &source.windows {
                if !names.insert(wit_name(&window.name)) {return Err(format!("tables.json: {} repeats relation {}",source.name,window.name));}
                self.window_target(source,window)?;
            }
        }
        Ok(())
    }
}
''')
print('initial independent host relation metadata/admission implementation applied')
