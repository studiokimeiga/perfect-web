from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'compiler/pw-core/src/tables.rs'
s=p.read_text();old='t.windows.push(clause(window))';assert s.count(old)==1
p.write_text(s.replace(old,'t.windows.push(Clause { value: window, span: span.clone() })'))
p=root/'compiler/pw-core/src/tables/relations.rs';s=p.read_text()
old='out.push(unseen(format!("window `{}` requires a public target table, but `{}` is protected",w.name,w.target),&window.span,"use a public target table"));'
new='out.push(refusal(codes::OWNED_READ_BY_ITS_READER,"owned_read_by_its_reader",Severity::Error,format!("window `{}` requires a public target table, but `{}` is protected",w.name,w.target),window.span.clone(),Vec::new(),READ_BY_ITS_READER,"use a public target table".into()));'
assert s.count(old)==1;s=s.replace(old,new)
old='out.push(unseen(format!("window `{}` cannot select through private match field `{}` for a sharer",w.name,w.source_field),&window.span,"match only a field in the shared seen row"));'
new='out.push(refusal(codes::PRIVATE_FIELD_UNSEEN,"private_field_unseen",Severity::Error,format!("window `{}` cannot select through private match field `{}` for a sharer",w.name,w.source_field),window.span.clone(),Vec::new(),UNSEEN,"match only a field in the shared seen row".into()));'
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
