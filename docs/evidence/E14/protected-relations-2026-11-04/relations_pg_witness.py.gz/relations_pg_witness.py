from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-table-postgres/tests/compiled_relations.rs';assert not p.exists()
old=(root/'runtime/pw-table-postgres/tests/compiled_ranges.rs').read_text()
helpers=old[old.index('fn q('):old.index('#[test]')]
p.write_text('''//! Fixed relation windows through real compiled PostgreSQL calls.
#![allow(dead_code)]
include!("../../pw-table-memory/tests/support/owned.rs");
include!("../../pw-table-memory/tests/support/relations.rs");
mod common;
use pw_host::engine::CallTables;
use pw_table_postgres::PgTables;

'''+helpers+r'''
#[test]
fn pg_relations_return_one_global_window_and_canonical_overlapping_groups_after_reopen() {
    let program=relation_program();
    let Some(url)=common::database() else{return;};
    let scratch=common::Scratch::new(&url,"compiled_relations");
    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");
    tables.transaction(|tx|{
        for row in relation_roots() {tx.write("pw:tables/roots#insert",&[row])?;}
        for row in relation_links() {tx.write("pw:tables/links#insert",&[row])?;}
        Ok(())
    }).assert_ok("seed public targets/private memberships");
    drop(tables);
    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("reopened PostgreSQL");
    for (name,ids) in [("RelFirst",vec![1,2]),("RelLast",vec![4,3])] {
        assert_eq!(q(&program,&tables,name,&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(2)]),
            Ok(vec![Val::List(ids.into_iter().map(relation_root_value).collect())]));
    }
    assert_eq!(q(&program,&tables,"RelMany",&as_user(ALICE),&[handle(ALICE),Val::List(vec![Val::S64(20),Val::S64(999),Val::S64(10),Val::S64(10)]),Val::S64(2)]),
        Ok(vec![Val::List(vec![relation_group("reader",ALICE,10,&[4,3]),relation_group("reader",ALICE,20,&[3,1]),relation_group("reader",ALICE,999,&[])])]));
    assert_eq!(q(&program,&tables,"RelLast",&as_user(BOB),&[handle(BOB),Val::S64(10),Val::S64(2)]),Ok(vec![Val::List(vec![relation_root_value(5)])]));
    assert_eq!(q(&program,&tables,"RelSharedMany",&as_user(BOB),&[handle(BOB),Val::List(vec![Val::S64(999),Val::S64(10)]),Val::S64(2)]),
        Ok(vec![Val::List(vec![relation_group("to",BOB,10,&[1,2]),relation_group("to",BOB,999,&[])])]));
    for n in [0,-9] {
        assert_eq!(q(&program,&tables,"RelLast",&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(n)]),Ok(vec![Val::List(vec![])]));
    }
    assert_eq!(q(&program,&tables,"RelLast",&as_user(ALICE),&[handle(ALICE),Val::S64(10),Val::S64(i64::MAX)]),
        Ok(vec![Val::List([4,3,2,1].into_iter().map(relation_root_value).collect())]));
}

#[test]
fn pg_relation_authority_and_whole_bad_requests_reach_no_data_sql() {
    let program=relation_program();
    let Some(url)=common::database() else{return;};
    let scratch=common::Scratch::new(&url,"relation_request_gate");
    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");
    let before=tables.operation_statements();
    let forged=q(&program,&tables,"RelLast",&as_user(ALICE),&[handle(BOB),Val::S64(10),Val::S64(0)]);
    assert!(forged.is_err(),"forged reader even at zero: {forged:?}");
    let absent=q(&program,&tables,"RelLast",&Caller::Nobody,&[handle(ALICE),Val::S64(10),Val::S64(2)]);
    assert!(absent.is_err(),"no caller: {absent:?}");
    assert_eq!(tables.operation_statements()-before,0,"no data SQL");
    for args in [vec![json!([{ "reader":ALICE,"topic":10},{"reader":ALICE,"topic":true}]),json!(0)],
                 vec![json!([{ "reader":ALICE,"topic":10},{"reader":ALICE}]),json!(2)],
                 vec![json!([{ "reader":ALICE,"topic":10,"extra":1}]),json!(2)],
                 vec![json!([ALICE]),json!(2)],vec![json!([]),json!(true)]] {
        let ops=tables.operation_statements();let rows=tables.returned_rows();let bytes=tables.returned_bytes();
        let result=tables.read("pw:tables/links#last-posts-by-reader-topic-many",&args);
        assert!(result.is_err(),"whole malformed request {args:?}: {result:?}");
        assert_eq!((tables.operation_statements()-ops,tables.returned_rows()-rows,tables.returned_bytes()-bytes),(0,0,0));
    }
    let before=tables.operation_statements();
    assert_eq!(tables.read("pw:tables/links#last-posts-by-reader-topic-many",&[json!([]),json!(2)]).assert_ok("empty set"),json!([]));
    assert_eq!(tables.read("pw:tables/links#last-posts-by-reader-topic-many",&[json!([{ "reader":ALICE,"topic":999}]),json!(0)]).assert_ok("zero set window"),json!([{"key":{"reader":ALICE,"topic":999},"rows":[]}]));
    assert_eq!(tables.operation_statements()-before,0,"empty/zero needs no SQL after whole validation");
}
''')
