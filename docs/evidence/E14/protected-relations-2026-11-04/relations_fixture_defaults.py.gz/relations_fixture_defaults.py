from pathlib import Path
import re
root=Path('/home/haki/code/pw-wt/data-path')
counts=[0,0]
for name in ['runtime/pw-table-memory/tests/memory.rs','runtime/pw-table-memory/src/failure_tests.rs','runtime/pw-table-memory/tests/staged.rs']:
    p=root/name;lines=p.read_text().splitlines(keepends=True);out=[]
    for line in lines:
        out.append(line)
        indent=re.match(r'\s*',line)[0]+'    '
        if 'FunctionJson {\n' in line and '-> FunctionJson' not in line:
            out.append(indent+'relation: None,\n');counts[0]+=1
        if 'TableJson {\n' in line:
            out.append(indent+'windows: Vec::new(),\n');counts[1]+=1
    p.write_text(''.join(out))
assert counts==[4,5],counts
