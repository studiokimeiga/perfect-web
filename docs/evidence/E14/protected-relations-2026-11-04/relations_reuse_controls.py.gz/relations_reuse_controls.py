"""Retest both independent dual-grant faults on the reuse-witness successor."""
from pathlib import Path
import importlib.util,sys,json,hashlib
root=Path('/home/haki/code/pw-wt/data-path');sys.path.insert(0,str(root/'scripts'))
import cargo_assertion_results,producer_process
spec=importlib.util.spec_from_file_location('row',root/'scripts/row_ownership_mutations.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
chosen=['relations contract dual grant requirement is omitted','relations actual secondary grant requirement is omitted']
module.MUTANTS=[m for m in module.MUTANTS if m[0] in chosen];assert len(module.MUTANTS)==2
command=['cargo','test','--quiet','--locked','-p','pw-table-memory','--test','compiled_relations']
inventory=None;run_number=0
out=Path('/tmp/pw-protected-migration/relations-reuse-strict');out.mkdir(exist_ok=True)
def strict():
    global inventory,run_number
    run_number+=1
    child=producer_process.run([*command,'--','--format=pretty','--test-threads=2'],cwd=root,timeout=900)
    p=out/f'run-{run_number:02}.log';p.write_text(child.stdout)
    result=cargo_assertion_results.validate(child.returncode,child.stdout,root=root,sources=module.SOURCES,expected=inventory)
    p.with_suffix('.json').write_text(json.dumps({'command':command,'exit':child.returncode,'valid':result.valid,'passed':result.passed,'failed':result.failed,'sha256':hashlib.sha256(child.stdout.encode()).hexdigest()},indent=2))
    if result.valid and inventory is None:inventory=cargo_assertion_results.names(child.stdout)
    if not result.valid: print(child.stdout[-4000:],flush=True)
    return result.valid,result.passed,result.failed
module.run_tests=strict;sys.argv=[sys.argv[0]]
sys.exit(module.main())
