from pathlib import Path
import re,json
logs=Path('/tmp/pw-protected-migration')
for name in ['core','cli','host','memory','pg','server']:
    text=(logs/f'relations-frozen-{name}.log').read_text()
    summaries=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
    print(name,dict(zip(['passed','failed','ignored'],[sum(x[i] for x in summaries) for i in range(3)])))
for name in ['pg','row','data','bounded','host']:
    path=logs/f'relations-frozen-{name}-controls.log'
    if path.exists():
        lines=path.read_text().splitlines()
        print(name, '\n'.join(lines[-4:]))
for campaign in ['d3_postgres','row_ownership','data_path','bounded_checker','table_host']:
    receipts=logs/f'relations-strict-{campaign}'
    invalid=[]
    for p in receipts.glob('*.json'):
        if not json.loads(p.read_text())['valid']: invalid.append(p.name)
    if invalid: print('INVALID receipts',campaign,invalid)
