"""Focused controls, preserving complete native inventories and raw receipts."""
from pathlib import Path
import importlib.util
import sys
import hashlib
import json

root=Path('/home/haki/code/pw-wt/data-path')
sys.path.insert(0,str(root/'scripts'))
import cargo_assertion_results
import producer_process
campaign=sys.argv[1]
spec=importlib.util.spec_from_file_location(campaign,root/f'scripts/{campaign}_mutations.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
old={
 'd3_postgres':['counts row accounting is not observed','counts byte accounting is not observed','postgres operation accounting hides a data statement','postgres operation accounting counts a transaction boundary as data'],
 'row_ownership':['counts missing result keys are accepted','counts reversed selector order is accepted','windows answer more rows than a selector allows'],
 'data_path':['windows memory retains every matching row','windows memory chooses first rows for last windows'],
 'bounded_checker':['`set` and `sets` head a clause wherever they are written','generated index pairs ignore their queried fields'],
 'table_host':["a function may name a field its table lacks","the gate trusts an import's claim of its capability"],
}
# Existing labels are checked explicitly: a misspelled filter cannot mean green.
labels={m[0] for m in module.MUTANTS}
assert set(old[campaign])<=labels,(campaign,set(old[campaign])-labels)
module.MUTANTS=[m for m in module.MUTANTS if m[0].startswith('relations ') or m[0] in old[campaign]]
assert module.MUTANTS
sources=getattr(module,'SOURCES',[])
if campaign=='bounded_checker':
    sources=[root/'compiler/pw-core/tests/bounded_reads.rs',root/'compiler/pw-core/tests/bounded_tables.rs']
if campaign=='table_host':
    # One cargo invocation per native binary, as the strict producer requires.
    module.TESTS=[['cargo','test','--quiet','--locked','-p','pw-table-memory','--lib']]+[
      ['cargo','test','--quiet','--locked','-p','pw-table-memory','--test',p.stem]
      for p in sorted((root/'runtime/pw-table-memory/tests').glob('*.rs'))]+[
      ['cargo','test','--quiet','--locked','-p','pw-host','--features','engine','--lib']]
    sources=sorted((root/'runtime/pw-table-memory').rglob('*.rs'))+sorted((root/'runtime/pw-host').rglob('*.rs'))
inventory={}
run_number=0
receipts=Path('/tmp/pw-protected-migration')/f'relations-strict-{campaign}'
receipts.mkdir(exist_ok=True)
def strict():
    global run_number
    run_number+=1
    passed=failed=0
    for index,entry in enumerate(module.TESTS):
        command,filters=entry if campaign=='data_path' else (entry,[])
        child=producer_process.run([*command,'--',*filters,'--format=pretty','--test-threads=2'],cwd=root,timeout=1200)
        path=receipts/f'run-{run_number:02}-{index:02}.log'
        path.write_text(child.stdout)
        result=cargo_assertion_results.validate(child.returncode,child.stdout,root=root,sources=sources,expected=inventory.get(index))
        path.with_suffix('.json').write_text(json.dumps({'command':command,'filters':filters,'exit':child.returncode,'valid':result.valid,'passed':result.passed,'failed':result.failed,'sha256':hashlib.sha256(child.stdout.encode()).hexdigest()},indent=2))
        if not result.valid:
            print(child.stdout[-4000:],flush=True)
            return False,passed,failed
        inventory.setdefault(index,cargo_assertion_results.names(child.stdout))
        passed+=result.passed;failed+=result.failed
    return True,passed,failed
if campaign=='bounded_checker': module.run=strict
else: module.run_tests=strict
sys.argv=[sys.argv[0]]
print(f'focused campaign: {campaign}; controls: {[m[0] for m in module.MUTANTS]}',flush=True)
sys.exit(module.main())
