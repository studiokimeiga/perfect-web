#!/bin/bash
set -euo pipefail
cd /home/haki/code/pw-wt/data-path
source /home/haki/pw-setup/env.sh
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
cargo fmt --all
cargo test --locked -p pw-core --test table_relations > /tmp/pw-protected-migration/relations-review-core-final.log 2>&1
cargo test --locked -p pw-table-memory --test compiled_relations > /tmp/pw-protected-migration/relations-review-memory-final.log 2>&1
cargo test --locked -p pw-table-postgres --test compiled_relations > /tmp/pw-protected-migration/relations-review-pg-final.log 2>&1
cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::conformance:: tests::tables_pg::the_suite_holds warm_relation_selections > /tmp/pw-protected-migration/relations-review-server-final.log 2>&1
