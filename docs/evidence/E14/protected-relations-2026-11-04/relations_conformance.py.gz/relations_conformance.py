from pathlib import Path
import re
root=Path('/home/haki/code/pw-wt/data-path')
directory=root/'examples/relations';directory.mkdir(exist_ok=True)
for name,source in {
'RelationPosts.pw':'''module RelationPosts
import capability.{ UserId }
type Post = Post { id: Int, author: UserId, stamp: Int, text: String }
table RelationPosts
    row Post
    key id
    order stamp
    index by_author on author
''',
'RelationMembers.pw':'''module RelationMembers
import RelationPosts
import capability.{ UserId }
type Member = Member { reader: UserId, topic: Int, author: UserId, edge: Int, to: UserId, secret: String }
table RelationMembers
    row Member
    key reader, topic, author, edge
    order edge
    index by_recipient_topic_author on to, topic, author
    owned by reader
    shares with to
    private secret
    window posts from RelationPosts row RelationPosts.Post on author to author
''',
'RelationWindowData.pw':'''module RelationWindowData
import RelationPosts
import RelationMembers
source RelationWindowData
    holds RelationPosts, RelationMembers
    transactions serializable
    reads strong
    changes none
    sets one_call
''',
}.items():
    p=directory/name;assert not p.exists()
    p.write_text(f'// @corpus: fixture\n// @id: RELATION-{p.stem}\n// @category: fixed relation-window conformance fixture\n// @milestone: E14\n\n'+source)

p=root/'spikes/own-renderer/server/src/tests/conformance.rs';s=p.read_text()
def change(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:80]);s=s.replace(old,new,1)
change('pub(super) struct Table {\n','pub(super) struct Table {\n    pub windows: Vec<Relation>,\n')
change('pub(super) struct Function {\n','pub(super) struct Function {\n    pub relation: Option<String>,\n')
change('impl Function {','''#[derive(Debug, Clone)]
pub(super) struct Relation {
    pub name: String,
    pub target: String,
    pub source_field: String,
    pub target_field: String,
}

impl Function {
    fn related(&self)->bool {self.primitive.starts_with("related-")}
''')
change('            "first" | "first-many" | "last" | "last-many"','            "first" | "first-many" | "last" | "last-many" | "related-first" | "related-first-many" | "related-last" | "related-last-many"')
change('matches!(self.primitive.as_str(), "last" | "last-many")','matches!(self.primitive.as_str(), "last" | "last-many" | "related-last" | "related-last-many")')
change('        .map(|t| Table {\n','''        .map(|t| Table {
            windows: t["windows"].as_array().into_iter().flatten().map(|w|Relation {
                name:w["name"].as_str().expect("relation name").into(),
                target:w["target"].as_str().expect("relation target").into(),
                source_field:w["source_field"].as_str().expect("source match").into(),
                target_field:w["target_field"].as_str().expect("target match").into(),
            }).collect(),
''')
change('                .map(|f| Function {\n','                .map(|f| Function {\n                    relation: f["relation"].as_str().map(str::to_string),\n')
# Existing oracle fixture literals keep their old meaning.
s,n=re.subn(r'(let table = Table \{\n)',r'\1        windows: Vec::new(),\n',s);assert n==2,n
s,n=re.subn(r'(let mut function = Function \{\n)',r'\1        relation: None,\n',s);assert n==3,n
change('''                    if function.counts() {
                        assert_eq!(''','''                    if function.related() {
                        assert_eq!(answer,relation_oracle(tables,table,function,rows,&selectors,limit.unwrap_or(0)),
                            "{} given {selectors:?}, at {n} rows a table, {way}",function.import);
                        checked+=1;
                        continue;
                    }
                    if function.counts() {
                        assert_eq!(''')
at=s.index('/// Ordered windows from generated rows, independently')
new=r'''/// Independent semi-join over the suite's own source/target rows. No adapter,
/// production selector/result codec, SQL or primitive implementation is called.
fn relation_oracle(tables:&[Table],source:&Table,function:&Function,rows:&BTreeMap<String,Vec<Map<String,Json>>>,selectors:&[Vec<Json>],limit:i64)->Vec<Val> {
    let relation=source.windows.iter().find(|w|Some(&w.name)==function.relation.as_ref()).expect("declared relation");
    let target=tables.iter().find(|t|t.name==relation.target).expect("declared target");
    let mut order=target.order.iter().cloned().collect::<Vec<_>>();
    for field in &target.key {if !order.contains(field){order.push(field.clone());}}
    let mut keys=selectors.to_vec();
    keys.sort_by(|a,b|a.iter().zip(b).map(|(a,b)|compare(a,b)).find(|o|o.is_ne()).unwrap_or(std::cmp::Ordering::Equal));
    keys.dedup();
    let mut groups=Vec::new();
    for key in keys {
        let mut found=rows[&target.name].iter().filter(|post|rows[&source.name].iter().any(|edge|
            function.by.iter().zip(&key).all(|(field,value)|edge[field]==*value)
                && edge[&relation.source_field]==post[&relation.target_field])).collect::<Vec<_>>();
        found.sort_by(|a,b|order.iter().map(|field|compare(&a[field],&b[field])).find(|o|o.is_ne()).unwrap_or(std::cmp::Ordering::Equal));
        if function.descending(){found.reverse();}
        found.truncate(usize::try_from(limit.max(0)).unwrap_or(usize::MAX));
        let answer=Val::List(found.into_iter().map(|row|Val::Record(target.fields.iter().map(|(field,stored)|
            (pw_host::tables::wit_name(field),wit(stored,&row[field]))).collect())).collect());
        if !function.many(){return vec![answer];}
        groups.push(Val::Record(vec![("key".into(),selector(source,function,&key)),("rows".into(),answer)]));
    }
    vec![Val::List(groups)]
}

#[test]
fn the_relation_oracle_uses_global_targets_and_keeps_overlapping_empty_groups() {
    let int=serde_json::json!({"int":{}});
    let source=Table {name:"Edges".into(),windows:vec![Relation{name:"posts".into(),target:"Posts".into(),source_field:"author".into(),target_field:"author".into()}],
        fields:["reader","topic","author","edge"].into_iter().map(|f|(f.into(),int.clone())).collect(),
        key:vec!["reader".into(),"topic".into(),"author".into(),"edge".into()],order:Some("edge".into()),indexes:vec![],references:vec![],bounded:None,source:"Data".into(),functions:vec![]};
    let target=Table {name:"Posts".into(),windows:vec![],fields:["id","author","stamp"].into_iter().map(|f|(f.into(),int.clone())).collect(),
        key:vec!["id".into()],order:Some("stamp".into()),indexes:vec![],references:vec![],bounded:None,source:"Data".into(),functions:vec![]};
    let source_row=|reader,topic,author,edge|[("reader".into(),Json::from(reader)),("topic".into(),Json::from(topic)),("author".into(),Json::from(author)),("edge".into(),Json::from(edge))].into_iter().collect::<Map<_,_>>();
    let post=|id,author,stamp|[("id".into(),Json::from(id)),("author".into(),Json::from(author)),("stamp".into(),Json::from(stamp))].into_iter().collect::<Map<_,_>>();
    let rows=BTreeMap::from([("Edges".into(),vec![source_row(1,10,7,1),source_row(1,10,7,2),source_row(1,10,8,3),source_row(1,20,7,4),source_row(2,10,9,5)]),
        ("Posts".into(),vec![post(1,7,1),post(2,8,2),post(3,7,3),post(4,8,3),post(5,9,99)])]);
    let mut function=Function {relation:Some("posts".into()),import:"test".into(),primitive:"related-last-many".into(),by:vec!["reader".into(),"topic".into()],sorted_by:vec!["stamp".into(),"id".into()]};
    let tables=vec![source.clone(),target];
    let selectors=[vec![Json::from(1),Json::from(20)],vec![Json::from(1),Json::from(999)],vec![Json::from(1),Json::from(10)],vec![Json::from(1),Json::from(10)]];
    let encoded=|id|{let row=rows["Posts"].iter().find(|row|row["id"]==id).unwrap();Val::Record(["id","author","stamp"].into_iter().map(|field|(field.into(),Val::S64(row[field].as_i64().unwrap()))).collect())};
    let group=|topic,ids:&[i64]|Val::Record(vec![("key".into(),Val::Record(vec![("reader".into(),Val::S64(1)),("topic".into(),Val::S64(topic))])),("rows".into(),Val::List(ids.iter().map(|id|encoded(*id)).collect()))]);
    assert_eq!(relation_oracle(&tables,&source,&function,&rows,&selectors,2),vec![Val::List(vec![group(10,&[4,3]),group(20,&[3,1]),group(999,&[])])]);
    assert_eq!(relation_oracle(&tables,&source,&function,&rows,&selectors,0),vec![Val::List(vec![group(10,&[]),group(20,&[]),group(999,&[])])]);
    assert_eq!(relation_oracle(&tables,&source,&function,&rows,&[],2),vec![Val::List(vec![])]);
    function.primitive="related-first".into();
    assert_eq!(relation_oracle(&tables,&source,&function,&rows,&[vec![Json::from(1),Json::from(10)]],2),vec![Val::List(vec![encoded(1),encoded(2)])]);
    function.primitive="related-last".into();
    assert_eq!(relation_oracle(&tables,&source,&function,&rows,&[vec![Json::from(2),Json::from(10)]],2),vec![Val::List(vec![encoded(5)])]);
}

'''
s=s[:at]+new+s[at:]
s+='''

pub(super) fn relations_build()->(tempfile::TempDir,std::path::PathBuf) {
    build_of(&["examples/relations"])
}

#[test]
fn the_suite_holds_for_fixed_relation_windows_on_memory() {
    let (_dir,out)=relations_build();
    let checked=conformance(&out,&memory);
    assert!(checked.reads>0 && checked.writes>0);
    let tables=tables_of(&out);
    for n in [3,24] {
        let rows=generated(&tables,n,0);
        for source in &tables {for function in source.functions.iter().filter(|f|f.related() && !f.many()) {
            let selector=function.by.iter().map(|field|rows[&source.name][0][field].clone()).collect::<Vec<_>>();
            let answer=relation_oracle(&tables,source,function,&rows,&[selector],2);
            assert!(matches!(answer.as_slice(),[Val::List(rows)] if !rows.is_empty()),"generated relation fixture has real positive matches at {n}: {answer:?}");
        }}
    }
}
'''
p.write_text(s)
p=root/'spikes/own-renderer/server/src/tests/tables_pg.rs';s=p.read_text();assert 'the_suite_holds_for_fixed_relation' not in s
p.write_text(s+'''

#[test]
fn the_suite_holds_for_fixed_relation_windows_on_postgresql() {
    let Some(url)=database() else{return;};
    let (_dir,out)=super::conformance::relations_build();
    let checked=suite_on_postgresql(&out,&url,"suite_relations");
    assert!(checked.reads>0 && checked.writes>0);
}
''')
