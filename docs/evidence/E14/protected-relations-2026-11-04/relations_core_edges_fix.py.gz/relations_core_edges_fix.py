from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
def change(path,old,new):
    p=root/path;s=p.read_text();assert s.count(old)==1,(path,s.count(old));p.write_text(s.replace(old,new,1))
change('compiler/pw-core/src/bounded.rs','                        Primitive::Last => Primitive::LastMany,','''                        Primitive::Last => Primitive::LastMany,
                        Primitive::RelatedFirst => Primitive::RelatedFirstMany,
                        Primitive::RelatedLast => Primitive::RelatedLastMany,''')
change('compiler/pw-core/src/bounded.rs','.find(|(_, p, fields)| *p == many && fields == by)','.find(|(candidate, p, fields)| *p == many && fields == by\n                            && (!primitive.related() || hir.decl(*candidate).name == format!("{}_many",hir.decl(*id).name)))')
change('compiler/pw-core/src/bounded.rs','        let (entries, missing) = if primitive.counts() {','''        if primitive.related() {
            return Some(format!(
                "read them together, before the {place}, with `{table}.{}`: supply {input}{reader}{bound}; \\\n+                 match each turn's key/rows group from the result, including an empty rows group for a missing key",
                many.name
            ));
        }
        let (entries, missing) = if primitive.counts() {''')
change('compiler/pw-core/src/tables.rs','        let identity = crate::wit::ident(&decl.name);\n        if let Some((first, span)) = generated_shapes.get(&identity)','''        let identity = crate::wit::ident(&decl.name);
        if !t.windows.is_empty()
            && let Some((other, _)) = hir.all_decls().find(|(id,d)| !hir.generated.contains_key(id) && crate::wit::ident(&d.name)==identity)
        {
            out.push(malformed(
                format!("`{}` is a generated selector or relation group record of `{}`, and the program declares it",decl.name,t.name),
                decl.name_span.clone(),vec![Related::new(hir.decl_span(other),"the program's declaration")],
                "rename the program's declaration so the generated record is distinct".into(),
            ));
        }
        if let Some((first, span)) = generated_shapes.get(&identity)''')
