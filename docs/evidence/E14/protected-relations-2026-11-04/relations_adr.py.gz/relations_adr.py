from pathlib import Path
import gzip
import hashlib
import shutil
import subprocess

root = Path('/home/haki/code/pw-wt/data-path')
work = Path('/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
draft = (work / 'RELATION-DESIGN-DRAFT.md').read_text()
body = 'Problem:' + draft.split('Problem:', 1)[1]
body = body.replace('Proposed membership table clause (name/syntax pending review):', 'Declare a fixed membership relation:')
body = body.replace('window posts from RootPosts on author to author', 'window posts from RootPosts row RootPosts.RootRow on author to author')
body = body.replace('This declares the equality', '''The explicit row annotation uses ordinary imported type resolution. Generation
runs in single-file lowering, before a Workspace exists; discovering a target's
chosen row name would otherwise require a new cross-unit generation/reindex
phase across checking and executable preparation. Keep the narrower typed
declaration. Later semantic checking requires the annotation to be the target
table's exact resolved row type, including nominal identity/arguments, never
merely matching fields or WIT shape. Runtime row metadata comes from the validated
target table, not a second annotation authority. Cover structurally identical
different row types, missing/wrong target, stale/private/nonexported annotation,
qualified/imported aliases of the same type and reversed file order.

This declares the equality''')
body = body.replace('Primary docs already checked: PostgreSQL18 functions-subquery.html (EXISTS and\ncorrelation) and sql-select.html (ORDER/LIMIT/LATERAL).', '''Primary documentation checked: PostgreSQL18
[subquery expressions](https://www.postgresql.org/docs/18/functions-subquery.html)
(EXISTS/correlation) and
[SELECT](https://www.postgresql.org/docs/18/sql-select.html)
(ORDER/LIMIT/LATERAL).''')
body = body.replace('Local synthetic probe relation_probe.sql ran', 'The [local synthetic probe](../evidence/E14/protected-relations-design-2026-11-04/primary-probe.log) ran')
path = root / 'docs/DECISIONS/ADR-XXXX-protected-feed-store.md'
old = path.read_text()
assert '### Next fixed read: relation windows' not in old
path.write_text(old + '''

### Next fixed read: relation windows

Decision made before implementation, 2026-11-04. Independent read-only design
review accepted the fixed one-hop rewrite with the limits below. Implementation
and all native/strict/frozen acceptance remain pending. No app port or startup
guard relaxation follows merely from this decision.

''' + body)
base = root / 'docs/evidence/E14/protected-relations-design-2026-11-04'
base.mkdir()
shutil.copy2('/tmp/pw-protected-migration/relation-primary-probe.log', base / 'primary-probe.log')
shutil.copy2(work / 'relation_probe.sql', base / 'primary-probe.sql')
(base / 'probe.sh.gz').write_bytes(gzip.compress((work / 'relation_probe.sh').read_bytes(), mtime=0))
(base / 'reproduce.md').write_text('''# Relation-window SQL design probe

Run `source /home/haki/pw-setup/env.sh`, then the archived probe runner with a
throwaway `PW_STORE_DATABASE_URL`. The runner retains the original local helper
path; alternatively pass this directory's `primary-probe.sql` to the same psql
command. It creates TEMP fixtures in a transaction and rolls back. This is SQL
semantics evidence only; no generic relation implementation existed for it.
The exact original SQL and runner are retained, with no credentials.
''')
files = sorted(base.iterdir())
(base / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in files))
print('fixed relation-window ADR recorded before code; SQL probe retained')
