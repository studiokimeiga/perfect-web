from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-host/src/engine/table_owners.rs';s=p.read_text();old='Access::Read(read) => read.key.first() == Some(&handle.field),';assert s.count(old)==1
p.write_text(s.replace(old,'Access::Read(read) => read.source_key.as_ref().unwrap_or(&read.key).first() == Some(&handle.field),'))
p=root/'runtime/pw-host/src/engine/table_link.rs';s=p.read_text();old='    target.target = None;';assert s.count(old)==1
p.write_text(s.replace(old,old+'\n    target.source_key = None;'))
