from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-table-memory/tests/support/relations.rs';s=p.read_text()
old='    let files=[("Roots.pw",roots)';assert s.count(old)==1
insert=r'''    app.push_str(r#"
import context.{ current_user }
predicate Selected(topic: Int, id: Int)
    says "This post is no longer selected."
{
    List.any(Links.last_posts_by_reader_topic(current_user(),topic,1),post => post.id == id)
}
user query RelHeld(reader: User<UserId>, topic: Int, id: Int) -> Option<Roots.Root>
    requires Selected(topic,id)
    freshness 0.seconds
    consistency read_your_writes
    cache private
    key reader,topic,id
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    Roots.get(id)
}
"#);
'''
s=s.replace(old,insert+old);p.write_text(s)
body=r'''
    tables.transaction(|tx|{
        for row in relation_roots() {tx.write("pw:tables/roots#insert",&[row])?;}
        for row in relation_links() {tx.write("pw:tables/links#insert",&[row])?;}
        Ok(())
    }).assert_ok("seed relation snapshot");
    let root=json!({"id":6,"author":BOB,"stamp":100,"text":"STAGED ORIGINAL"});
    let edge=json!({"reader":ALICE,"topic":77,"author":BOB,"edge":7,"to":BOB,"secret":"only alice's membership"});
    let mut command=tables.begin().assert_ok("command");
    command.write("pw:tables/roots#insert",&[root.clone()]).assert_ok("stage target");
    command.write("pw:tables/links#insert",&[edge]).assert_ok("stage source membership");
    let args=[handle(ALICE),Val::S64(77),Val::S64(6)];
    let asked=AtomicUsize::new(0);
    let staged=authorized(&program,"RelHeld",ALICE,&command,&pw_host::Limits::unbounded(),&args,false,&asked).assert_ok("compiled predicate sees BOTH staged tables");
    assert!(matches!(staged.as_slice(),[Val::Option(Some(_))]));
    assert_eq!(asked.load(Ordering::SeqCst),0,"no deployment predicate");
    assert_eq!(tables.read("pw:tables/roots#get",&[json!(6)]).assert_ok("published target before commit"),serde_json::Value::Null);
    command.commit().assert_ok("publish source and target");
    let snapshot=tables.snapshot().assert_ok("held relation snapshot");
    let held=authorized(&program,"RelHeld",ALICE,&snapshot,&pw_host::Limits::unbounded(),&args,false,&asked).assert_ok("pin membership AND body");
    assert_eq!(held,staged);
    tables.transaction(|tx|{
        let mut changed=root.clone();changed["text"]=json!("CHANGED AFTER PIN");
        tx.write("pw:tables/roots#put",&[changed])?;
        tx.write("pw:tables/links#delete",&[json!(ALICE),json!(77),json!(BOB),json!(7)])?;
        tx.write("pw:tables/links#insert",&[json!({"reader":ALICE,"topic":77,"author":CAROL,"edge":8,"to":BOB,"secret":"changed membership"})])
    }).assert_ok("later writer changes source membership AND target body");
    assert_eq!(tables.read("pw:tables/roots#get",&[json!(6)]).assert_ok("live target body")["text"],"CHANGED AFTER PIN");
    assert_eq!(authorized(&program,"RelHeld",ALICE,&snapshot,&pw_host::Limits::unbounded(),&args,false,&asked),Ok(held));
    let fresh=tables.snapshot().assert_ok("fresh relation snapshot");
    let watched=Watched::new(&fresh);
    let denied=authorized(&program,"RelHeld",ALICE,&watched,&pw_host::Limits::unbounded(),&args,false,&asked);
    assert!(denied.as_ref().is_err_and(|why|why.contains("Selected")),"fresh predicate follows new membership: {denied:?}");
    assert_eq!(watched.body.load(Ordering::SeqCst),0,"fresh refused body never runs");
'''
p=root/'runtime/pw-table-memory/tests/compiled_relations.rs';s=p.read_text();assert 'both_staged_tables' not in s
p.write_text(s+'\n#[test]\nfn a_relation_predicate_sees_both_staged_tables_and_pins_membership_with_the_body() {\n    let program=relation_program();\n    let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");\n'+body+'}\n')
p=root/'runtime/pw-table-postgres/tests/compiled_relations.rs';s=p.read_text();assert 'both_staged_tables' not in s
p.write_text(s+'\n#[test]\nfn a_relation_predicate_sees_both_staged_tables_and_pins_membership_with_the_body() {\n    let program=relation_program();\n    let Some(url)=common::database() else{return;};\n    let scratch=common::Scratch::new(&url,"relation_snapshot");\n    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");\n'+body+'}\n')
