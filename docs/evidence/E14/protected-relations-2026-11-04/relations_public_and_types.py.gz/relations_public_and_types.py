from pathlib import Path
root=Path('/home/haki/code/pw-wt/data-path')
p=root/'runtime/pw-table-memory/tests/support/relations.rs';s=p.read_text();assert 'relation_public_program' not in s
p.write_text(s+r'''

fn relation_public_program() -> Program {
    let roots=r#"module Roots
import capability.{ UserId }
type Root = Root { id: Int, author: UserId, stamp: Int, text: String }
table Roots
    row Root
    key id
    order stamp
    index by_author on author
"#;
    let links=r#"module Links
import Roots
import capability.{ UserId }
type Link = Link { topic: Bool, author: UserId, edge: Int, text: String }
table Links
    row Link
    key topic, author, edge
    order edge
    window posts from Roots row Roots.Root on author to author
"#;
    let source=r#"module RelationData
import Links
import Roots
source RelationData
    holds Links, Roots
    transactions serializable
    reads strong
    changes none
    sets one_call
"#;
    let app=r#"module owned.app
import Roots
import Links
public query PlainLast(topic: Bool, n: Int) -> List<Roots.Root>
    freshness 0.seconds
    consistency snapshot
    cache shared
    key topic,n
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    Links.last_posts_by_topic(topic,n)
}
public query PlainMany(topics: List<Bool>, n: Int) -> List<Links.LinksTopicPostsWindow>
    freshness 0.seconds
    consistency snapshot
    cache shared
    key topics,n
    concurrency one_per_key
    on_key_change cancel
    timeout 2.seconds
{
    Links.last_posts_by_topic_many(topics,n)
}
"#;
    built_from(&[("Roots.pw",roots),("Links.pw",links),("RelationData.pw",source),("app.pw",app)])
}
fn relation_public_links()->Vec<serde_json::Value> {
    [(false,BOB,1),(false,BOB,2),(true,BOB,3),(true,CAROL,4)].into_iter()
        .map(|(topic,author,edge)|json!({"topic":topic,"author":author,"edge":edge,"text":"public membership"})).collect()
}
fn relation_public_group(topic:bool,ids:&[i64])->Val {
    Val::Record(vec![("key".into(),Val::Bool(topic)),("rows".into(),Val::List(ids.iter().map(|id|relation_root_value(*id)).collect()))])
}
''')
body=r'''
    tables.transaction(|tx|{
        for row in relation_roots() {tx.write("pw:tables/roots#insert",&[row])?;}
        for row in relation_public_links() {tx.write("pw:tables/links#insert",&[row])?;}
        Ok(())
    }).assert_ok("public Bool memberships");
    assert_eq!(QUERY(&program,&tables,"PlainLast",&Caller::Nobody,&[Val::Bool(false),Val::S64(2)]),Ok(vec![Val::List(vec![relation_root_value(3),relation_root_value(1)])]));
    let args=[Val::List(vec![Val::Bool(true),Val::Bool(false),Val::Bool(true)]),Val::S64(2)];
    assert_eq!(QUERY(&program,&tables,"PlainMany",&Caller::Nobody,&args),Ok(vec![Val::List(vec![relation_public_group(false,&[3,1]),relation_public_group(true,&[4,3])])]));
    let args=[Val::List(vec![Val::Bool(true),Val::Bool(false)]),Val::S64(0)];
    assert_eq!(QUERY(&program,&tables,"PlainMany",&Caller::Nobody,&args),Ok(vec![Val::List(vec![relation_public_group(false,&[]),relation_public_group(true,&[])])]));
    tables.transaction(|tx|{
        tx.write("pw:tables/links#delete-prefix",&[json!(true)])
    }).assert_ok("remove one public selector's members");
    assert_eq!(QUERY(&program,&tables,"PlainMany",&Caller::Nobody,&[Val::List(vec![Val::Bool(true),Val::Bool(false)]),Val::S64(2)]),Ok(vec![Val::List(vec![relation_public_group(false,&[3,1]),relation_public_group(true,&[])])]));
'''
for crate,query,setup in [('pw-table-memory','query','    let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");'),('pw-table-postgres','q','    let Some(url)=common::database() else{return;};\n    let scratch=common::Scratch::new(&url,"public_relation_keys");\n    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");')]:
    # Compiler gives a key-prefix delete its actual generated of_topic name.
    native=body.replace('QUERY(',query+'(').replace('pw:tables/links#delete-prefix','pw:tables/links#delete-of-topic')
    p=root/f'runtime/{crate}/tests/compiled_relations.rs';s=p.read_text();assert 'public_relations_use_scalar' not in s
    p.write_text(s+'\n#[test]\nfn public_relations_use_scalar_bool_group_keys_and_allow_anonymous_callers() {\n    let program=relation_public_program();\n'+setup+'\n'+native+'}\n')

p=root/'compiler/pw-core/tests/table_relations.rs';s=p.read_text();assert 'nominal_names_are_qualified' not in s
p.write_text(s+r'''

#[test]
fn nominal_names_are_qualified_and_imported_row_spellings_preserve_identity() {
    let roots=ROOTS.replace("import capability", "import Beta\nimport capability").replace("author: UserId","author: Beta.Tag");
    let links=LINKS.replace("import Roots", "import Alpha\nimport Roots").replace("author: UserId","author: Alpha.Tag");
    let extra=[("Alpha.pw".into(),"module Alpha\nopaque type Tag = String\n".into()),("Beta.pw".into(),"module Beta\nopaque type Tag = String\n".into())];
    let mut bad=files(&links,&roots,DATA);bad.extend(extra.clone());
    let got=check_sources(&bad).into_iter().flat_map(|(_,ds)|ds).collect::<Vec<_>>();
    assert!(got.iter().any(|d|d.code=="PW0361" && d.message.contains("same complete keyable type")),"same local Tag/string is not same nominal type: {got:#?}");
    let mut good=files(&links.replace("Alpha","Beta"),&roots,DATA);good.extend(extra);
    let got=check_sources(&good);
    assert!(got.iter().all(|(_,ds)|ds.is_empty()),"one imported nominal Tag: {got:#?}");
    let imported=LINKS.replace("import Roots\n","import Roots\nimport Roots.{ Root }\n").replace("row Roots.Root on","row Root on");
    assert!(diagnostics(&imported,ROOTS,DATA).is_empty(),"unqualified import denotes the same row");
    let twins=ROOTS.split("table Roots").next().unwrap().replace("module Roots","module Twins");
    let wrong=LINKS.replace("import Roots\n","import Roots\nimport Twins\n").replace("row Roots.Root on","row Twins.Root on");
    let mut sources=files(&wrong,ROOTS,DATA);sources.push(("Twins.pw".into(),twins));
    let got=check_sources(&sources).into_iter().flat_map(|(_,ds)|ds).collect::<Vec<_>>();
    assert!(got.iter().any(|d|d.code=="PW0361" && d.message.contains("row type")),"same local Root/layout is not the same row: {got:#?}");
}

#[test]
fn relation_row_annotations_obey_visibility_and_require_the_declared_shape() {
    let private=ROOTS.replace("type Root =","private type Root =");
    let got=diagnostics(LINKS,&private,DATA);
    assert!(got.iter().any(|(code,message)|(code=="PW0361" && message.contains("row type")) || code=="PW0023"),"private row annotation is not importable: {got:#?}");
    refused(&LINKS.replace("row Roots.Root ",""),ROOTS,DATA,"PW0361","window");
    refused(&LINKS.replace("row Roots.Root on","row Roots.Missing on"),ROOTS,DATA,"PW0361","row type");
    refused(&LINKS.replace("from Roots row","from Missing row"),ROOTS,DATA,"PW0361","target table");
}
''')
