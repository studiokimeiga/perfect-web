"""Bound local Fallow refusal and working refactor without claiming SHA gates."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

root=Path('/home/haki/code/pw-wt/session-followup-20261027')
work=Path(__file__).resolve().parent
head='8da9ab54e1e462628efbe8e71c2b32647f5d1a33'
out=root/'docs/evidence/E14/renderer-complexity-2026-10-29'
out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
rows=[]
def add(name,raw):
    payload=gzip.compress(raw,mtime=0)
    path=out/(name+'.gz');path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb')as stream:stream.write(payload)
    if gzip.decompress(path.read_bytes())!=raw:raise RuntimeError('Archive mismatch')
    rows.append({'path':path.relative_to(out).as_posix(),'bytes':len(payload),'sha256':sha(payload),
                 'decoded_bytes':len(raw),'decoded_sha256':sha(raw)})
old=work/'session-followup-exact-8da9ab54-prepublication'
red=json.loads((old/'fallow.log').read_text())
green_path=work/'renderer-complexity-fallow-working-final-20261029.json'
green=json.loads(green_path.read_text())
node_path=work/'renderer-complexity-node-working-final-20261029.log'
node=node_path.read_text()
if red['verdict']!='fail' or red['attribution']['complexity_introduced']!=3:
    raise RuntimeError('Wrong refusal')
if green['verdict']!='pass' or any(green['attribution'][key]for key in
    ['dead_code_introduced','complexity_introduced','duplication_introduced','styling_introduced']):
    raise RuntimeError('Working analyzer refused')
for key,count in [('tests',13),('pass',13),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:
    if not re.search(r'^ℹ '+key+' '+str(count)+r'$',node,re.M):raise RuntimeError('Incomplete native tests')
for name in ['preflight.log','ruff.log','fallow.log','progress.json','inputs-before.json']:
    add('failed-immutable-8da9/'+name,(old/name).read_bytes())
add('working-green/fallow.json',green_path.read_bytes())
add('working-green/node.log',node_path.read_bytes())
for name in ['spikes/own-renderer/public/pw-runtime.mjs','spikes/own-renderer/renderer-contract.test.mjs']:
    add('source-8da9/'+name,subprocess.check_output(['git','show',head+':'+name],cwd=root))
    add('working-source/'+name,(root/name).read_bytes())
add('working-source.diff',subprocess.check_output(['git','diff','--binary',head],cwd=root))
add('collector.py',Path(__file__).read_bytes())
report={'kind':'LOCAL_FAILED_CANDIDATE_AND_WORKING_REFACTOR_ONLY','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'failed_candidate':head,'candidate_was_pushed':False,'refactor_behavior_claim':'Same coordinator predicate, retirement phase order, source seams and assertions.',
        'failed_immutable_gates':{'preflight':0,'ruff':0,'fallow':1,'new_complexity_findings':3},
        'working_checks':[{'command':['node','--test','--test-reporter=spec','spikes/own-renderer/renderer-contract.test.mjs'],
                           'exit':0,'cases':13,'failed':0,'skipped':0,'retries':0},
                          {'command':['fallow','--format','json','--quiet','audit','--base','a0db8884deb2b3ba37faee59afcdee44a92c6b1c'],
                           'exit':0,'new_findings':0}],
        'qualifications':['Working green reports do not check an immutable successor.',
                          'Working native/analyzer commands were directly launched; no separate durable PID receipt is claimed.',
                          'The successor still requires fresh owned pre-publication, browser, recipe and all hosted gates.',
                          'No analyzer threshold, suppression, policy or domain assertion changed.',
                          'The original WebKit trap low-level cause remains unresolved.'],
        'files':rows}
with(out/'manifest.json').open('x')as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({'out':str(out),'payloads':len(rows),'manifest_sha256':sha((out/'manifest.json').read_bytes())},indent=2))
