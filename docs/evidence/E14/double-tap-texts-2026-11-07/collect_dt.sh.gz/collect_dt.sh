#!/usr/bin/env bash
# Evidence for the double-tap texts (2026-11-07), recorded at HEAD of the
# worktree it runs in, into docs/evidence/E14/double-tap-texts-2026-11-07/.
set -uo pipefail
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
: "${CARGO_TARGET_DIR:?set CARGO_TARGET_DIR}"
OUT=docs/evidence/E14/double-tap-texts-2026-11-07
BASE=$(git merge-base origin/master HEAD)
PW="$CARGO_TARGET_DIR/debug/pw"
mkdir -p "$OUT"
head() {
  echo "$1"; echo
  echo "commit: $(git rev-parse HEAD)$(git diff --quiet HEAD -- . ':(exclude)docs/evidence' || echo ' + uncommitted changes')"
  echo "base: $BASE"; echo "rust: $(rustc --version)"; echo
}
STD="packages/pw-std/*.pw packages/pw-platform-web/*.pw examples/domain.pw examples/lib/*.pw"
{
  head "The canonical store, built at the base and at this commit"
  W=$(mktemp -d); mkdir -p "$W/base/store"
  for f in examples/store/*.pw; do git show "$BASE:$f" > "$W/base/store/$(basename "$f")"; done
  echo "$ pw build --out BASE-OUT <packages, domain, lib> <the store at the base>"
  $PW build --out "$W/out-base" $STD "$W"/base/store/*.pw > /dev/null 2>&1; echo "exit $?"
  echo "$ pw build --out THIS-OUT <packages, domain, lib> examples/store/*.pw"
  $PW build --out "$W/out-this" $STD examples/store/*.pw > /dev/null 2>&1; echo "exit $?"
  echo; echo "== every file built, compared"
  if diff -r "$W/out-base" "$W/out-this" > /dev/null; then
    echo "byte-identical: $(find "$W/out-this" -type f | wc -l) files"
  else
    echo "DIFFERENT:"; diff -rq "$W/out-base" "$W/out-this" | sed "s#$W/##g"
  fi
  echo; echo "== templates.json against the committed spikes/own-renderer/store-ir.json"
  cmp "$W/out-this/templates.json" spikes/own-renderer/store-ir.json && echo "identical"
  echo; echo "== the store's source, byte and line counts"
  echo "examples/store/app.pw: base $(git show "$BASE:examples/store/app.pw" | wc -c) bytes, $(git show "$BASE:examples/store/app.pw" | wc -l) lines; this $(wc -c < examples/store/app.pw) bytes, $(wc -l < examples/store/app.pw) lines"
  echo; echo "== pw fmt --check examples/store/*.pw"; $PW fmt --check examples/store/*.pw; echo "exit $?"
  echo; echo "== pw check, the store with its library"; $PW check $STD examples/store/*.pw 2>&1 | tail -1
  rm -rf "$W"
} > "$OUT/store-builds.txt" 2>&1
{
  head "The guide's examples (compiler/pw-cli/tests/guide.rs)"
  cargo test --locked -p pw-cli --test guide 2>&1 | grep -E '^(test |test result)|panicked at'
} > "$OUT/guide-test.txt"
{
  head "Mutation anchors, and the parts of just preflight a change of comments and prose reaches"
  echo "== python3 scripts/mutation_anchors.py"; python3 scripts/mutation_anchors.py; echo "exit $?"
  echo; echo "== cargo fmt --all -- --check"; cargo fmt --all -- --check; echo "exit $?"
  echo; echo "== bash scripts/case-check.sh"; bash scripts/case-check.sh; echo "exit $?"
  echo; echo "== python3 -m compileall -q scripts research/failures/tools"; python3 -m compileall -q scripts research/failures/tools; echo "exit $?"
  echo; echo "Not run here: just preflight's clippy (no Rust source changed); the PR's CI runs it."
} > "$OUT/checks.txt" 2>&1
{
  head "What the change reaches (python3 scripts/ci_plan.py --changed BASE HEAD)"
  python3 scripts/ci_plan.py --shards 1 --changed "$BASE" HEAD | python3 -c 'import json,sys; s=sys.stdin.read().split("=",1)[1]; r=sorted(x for sh in json.loads(s) for x in sh["recipes"]); print(len(r), "recipes:"); print("\n".join("  "+x for x in r))'
  echo; echo "Left to this branch's hosted verification (the PC runs no heavy recipes, 2026-11-07)."
} > "$OUT/ci-plan.txt" 2>&1
ls "$OUT"
