#!/usr/bin/env bash
# Fallow's audit as CI runs it, in a clean checkout of HEAD: no node_modules, no
# builds, nothing the worktree has installed (a shared clone: the objects are
# not copied). usage: clean-audit.sh <commit> <out.json>
set -u
SHA=${1:-HEAD}
OUT=${2:-$HOME/h2h-scratch/fallow-clean.json}
SRC=/home/haki/code/pw-wt/head-to-head
CL=/tmp/h2h-clean-audit
rm -rf "$CL"
git clone -q --shared --no-checkout "$SRC" "$CL" || exit 1
cd "$CL" || exit 1
git checkout -q "$(git -C "$SRC" rev-parse "$SHA")" || exit 1
git rev-parse --short HEAD
ls | head -3
test -d node_modules && echo "node_modules present?!" || echo "no node_modules (as on CI)"
npx -y fallow@3.23.0 audit --root . --quiet --format json --changed-since 45e0c1a6e9f6331bcce7fb3fb35528b169397934 --gate new-only > "$OUT" 2> "${OUT%.json}.stderr"
echo "fallow exit: $?"
python3 - "$OUT" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
print("verdict:", d["verdict"], "| changed files:", d["changed_files_count"], "| head:", d["head_sha"])
print("attribution:", json.dumps(d["attribution"]))
PY
cd / && rm -rf "$CL"
