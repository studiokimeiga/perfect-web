#!/usr/bin/env python3
"""How many times a request occurs in each run of a cell, in each of the live runs."""
import json

RUNS = (("before1 (original, loaded VM)", "smoke-before.json"), ("before2 (original, calm VM)", "smoke-before2.json"), ("after3 (result, calm VM)", "smoke-after3.json"))
PROBES = [
    ("store", "next-react", "POST", "/stores/blue-bottle"),
    ("store", "next-react", "GET", "/stores/blue-bottle"),
    ("store", "sveltekit", "GET", "/stores/blue-bottle/__data.json?x-sveltekit-invalidated=01"),
]
data = {name: json.load(open(path)) for name, path in RUNS}
for app, stack, method, suffix in PROBES:
    print(f"--- {app}/{stack} {method} ...{suffix}, per run, in the interaction 'add' (chromium)")
    for name, d in data.items():
        a = [x for x in d["apps"] if x["app"] == app][0]
        for cond in ("cold", "warm"):
            for shaped in (False, True):
                cells = sorted(
                    (r for r in a["runs"] if r["stack"] == stack and r["engine"] == "chromium" and r["condition"] == cond and bool(r.get("network")) == shaped),
                    key=lambda r: r["i"],
                )
                counts = [
                    sum(1 for q in r.get("requests") or [] if q["method"] == method and q["url"].endswith(suffix) and q["phase"] == "interaction:add" and not q.get("failed"))
                    for r in cells
                ]
                label = "slow-4g" if shaped else "unshaped"
                print(f"  {name:32s} {cond:5s} {label:8s} {counts}")
