#!/usr/bin/env bash
# The instrument as it was (35f1943d's sources, exactly as 53b9954b had them, with
# `export` added to the four functions of head-to-head.mjs that 82a19c8d's tests call),
# run against every test that was written before a function was split into helpers.
# usage: pins-on-original-2.sh <out.tap>
set -u
OUT=${1:-$HOME/h2h-scratch/pins-on-original-2.tap}
SRC=/home/haki/code/pw-wt/head-to-head
D=/tmp/h2h-orig
rm -rf "$D"
mkdir -p "$D"
git -C "$SRC" archive 53b9954b | tar -x -C "$D" || exit 1
cd "$D" || exit 1
echo "tree: 53b9954b ($(git -C "$SRC" rev-parse --short 53b9954b))"
echo "head-to-head.mjs at 53b9954b vs 35f1943d: $(git -C "$SRC" diff --stat 35f1943d 53b9954b -- benchmarks/headtohead/head-to-head.mjs | tail -1 | tr -s ' ')"
git -C "$SRC" show 82a19c8d:benchmarks/headtohead/head-to-head.mjs > benchmarks/headtohead/head-to-head.mjs || exit 1
git -C "$SRC" show 82a19c8d:benchmarks/headtohead/test/head-to-head.test.mjs > benchmarks/headtohead/test/head-to-head.test.mjs || exit 1
echo "head-to-head.mjs now vs 35f1943d (should be only the four exports):"
diff <(git -C "$SRC" show 35f1943d:benchmarks/headtohead/head-to-head.mjs) benchmarks/headtohead/head-to-head.mjs
ln -s "$SRC/node_modules" "$D/node_modules"
[ -e "$SRC/benchmarks/headtohead/node_modules" ] && ln -s "$SRC/benchmarks/headtohead/node_modules" "$D/benchmarks/headtohead/node_modules"
mkdir -p "$D/target"
[ -e "$SRC/target/release" ] && ln -s "$SRC/target/release" "$D/target/release"
node --version
node --test --test-reporter=tap benchmarks/headtohead/test/*.mjs > "$OUT" 2> "${OUT%.tap}.stderr"
echo "node --test exit: $?"
tail -9 "$OUT"
