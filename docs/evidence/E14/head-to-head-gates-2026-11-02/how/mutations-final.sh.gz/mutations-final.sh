#!/usr/bin/env bash
# The head-to-head's mutation script, whole, at the code commit: its 41 mutants and
# 4 integrity controls. Detached from whoever starts it. The repository's files must
# not be edited while it runs (each mutant is applied to them and restored).
cd /home/haki/code/pw-wt/head-to-head || exit 1
rm -f "$HOME/h2h-scratch/mutations-final.txt"
{
  echo "start: $(date -u +%FT%TZ) head $(git rev-parse --short HEAD) load $(cut -d' ' -f1-3 /proc/loadavg)"
  git status --short | head -5
  PORT=13441 python3 scripts/head_to_head_mutations.py 2>&1
  echo "script-exit=$?"
  echo "end: $(date -u +%FT%TZ)"
  git status --short | head -5
} > "$HOME/h2h-scratch/mutations-final.txt" 2>&1
