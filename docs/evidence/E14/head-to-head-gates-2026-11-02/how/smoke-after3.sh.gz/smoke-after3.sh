#!/usr/bin/env bash
# The live run after the refactor, the same flags, seed and ports as the run before it
# (smoke-before.json), at the code commit. Detached from whoever starts it.
# usage: smoke-after3.sh [extra head-to-head flags replacing the defaults: name prefix]
cd /home/haki/code/pw-wt/head-to-head || exit 1
rm -f "$HOME/h2h-scratch/smoke-after3.exit"
echo "start: $(date -u +%FT%TZ) head $(git rev-parse --short HEAD) load $(cut -d' ' -f1-3 /proc/loadavg)" > "$HOME/h2h-scratch/smoke-after3.start"
PORT=13441 node benchmarks/headtohead/head-to-head.mjs --apps todomvc,store --engines chromium,firefox,webkit --conditions cold,warm --runs 5 --server-runs 5 --load-seconds 2 --settle 0 --json "$HOME/h2h-scratch/smoke-after3.json" > "$HOME/h2h-scratch/smoke-after3.txt" 2> "$HOME/h2h-scratch/smoke-after3.err"
echo "exit=$?" > "$HOME/h2h-scratch/smoke-after3.exit"
echo "end: $(date -u +%FT%TZ)" >> "$HOME/h2h-scratch/smoke-after3.start"
