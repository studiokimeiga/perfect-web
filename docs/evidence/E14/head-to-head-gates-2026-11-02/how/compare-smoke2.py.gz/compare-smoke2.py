#!/usr/bin/env python3
"""Compare two live runs of the instrument (the same flags, before and after the
refactor) by what must not change: the shape of the result, the orders its seed
fixes, the stacks described, the requests each build serves (their status, type,
sizes and blobs), the counts of runs, the problems, and the failures. Times,
bytes received and server costs vary run to run and are not compared.

A cell in which either run lost a run to the machine (a browser closed from
outside, a page that timed out while the machine swapped) is compared again,
from a run made again for it: `--again RERUN.json:BASE.json` compares the cells
the first comparison set aside, taken from RERUN, with the same cells of BASE.

usage: compare-smoke2.py BEFORE.json AFTER.json [--again RERUN.json:BASE.json]..."""
import json
import re
import sys
from collections import Counter, defaultdict

DETERMINISTIC = ("phase", "method", "url", "kind", "status", "type", "encoding", "cacheControl", "validator",
                 "minified", "minifiedBytes", "failed")
# A body's sizes and git blob are compared where the content is the same in every run of a
# cell (a script, a style, a static page); a page or an answer that differs run to run
# (a session, a cart's id) is not compared by them.
CONTENT = ("raw", "br", "gzip", "blob")


def load(path):
    return json.load(open(path))


def cell_key(r):
    return (r["app"], r["stack"], r["engine"], r["condition"], r.get("network"))


def keyset(items):
    out = set()
    for x in items:
        out |= set(x.keys())
    return sorted(out)


def shape(run):
    return {
        "keys": sorted(run.keys()),
        "timings": sorted((run.get("timings") or {}).keys()),
        "interaction_keys": keyset(run.get("interactions") or []),
        "interaction_names": [i["name"] for i in run.get("interactions") or []],
        "request_keys": keyset(run.get("requests") or []),
        "received_keys": keyset(run.get("received") or []),
    }


def requests_of(run):
    return Counter(tuple(json.dumps(q.get(k)) for k in DETERMINISTIC) for q in run.get("requests") or [] if not q.get("failed"))


def contents_of(runs):
    """{(phase, url): the set of (raw, br, gzip, blob) its answers had in these runs}."""
    out = defaultdict(set)
    for run in runs:
        for q in run.get("requests") or []:
            if not q.get("failed"):
                out[(q.get("phase"), q.get("url"))].add(tuple(json.dumps(q.get(k)) for k in CONTENT))
    return out


def runs_by_cell(app):
    out = defaultdict(list)
    for r in app["runs"]:
        out[cell_key(r)].append(r)
    return out


def failed_cells(app):
    return {c for c, rs in runs_by_cell(app).items() if any(r.get("error") for r in rs)}


def compare_cells(a_b, a_a, cells, problems, label):
    """The cells' runs of two apps: counts, orders, failures, shapes, and (for unshaped cold Chromium) requests."""
    cb, ca = runs_by_cell(a_b), runs_by_cell(a_a)
    compared = 0
    for cell in sorted(cells, key=str):
        rb, ra = cb.get(cell, []), ca.get(cell, [])
        if not rb and not ra:
            continue
        compared += 1
        if len(rb) != len(ra):
            problems.append(f"{label}{cell}: {len(rb)} runs before, {len(ra)} after")
            continue
        if [r["order"] for r in rb] != [r["order"] for r in ra] or [r["i"] for r in rb] != [r["i"] for r in ra]:
            problems.append(f"{label}{cell}: orders or rounds differ")
        if [bool(r.get("error")) for r in rb] != [bool(r.get("error")) for r in ra]:
            problems.append(f"{label}{cell}: failures differ")
        sb = {json.dumps(shape(r), sort_keys=True) for r in rb if not r.get("error")}
        sa = {json.dumps(shape(r), sort_keys=True) for r in ra if not r.get("error")}
        if sb != sa:
            problems.append(f"{label}{cell}: shape differs\n   before {sb}\n   after  {sa}")
        qb, qa = Counter(), Counter()
        for r in rb:
            qb.update(requests_of(r))
        for r in ra:
            qa.update(requests_of(r))
        if cell[2] == "chromium" and cell[3] == "cold" and not cell[4] and qb != qa:
            only_b, only_a = qb - qa, qa - qb
            problems.append(f"{label}{cell}: requests differ: before-only {sum(only_b.values())}, after-only {sum(only_a.values())}")
            for q in list(only_b)[:3]:
                problems.append(f"     before-only {q[:8]}")
            for q in list(only_a)[:3]:
                problems.append(f"     after-only  {q[:8]}")
        if cell[2] == "chromium" and cell[3] == "cold" and not cell[4]:
            cb_, ca_ = contents_of(rb), contents_of(ra)
            for key in sorted(set(cb_) | set(ca_), key=str):
                sb_, sa_ = cb_.get(key, set()), ca_.get(key, set())
                if len(sb_) == 1 and len(sa_) == 1 and sb_ != sa_:
                    problems.append(f"{label}{cell}: the same answer for {key[1]} has other content: before {sorted(sb_)}, after {sorted(sa_)}")
    return compared


def compare_app(a_b, a_a, problems, label, skip):
    app = a_a["app"]
    assert a_b["app"] == app
    if a_b["targets"] != a_a["targets"]:
        problems.append(f"{label}{app}: targets described differently")
    for key in ("loads", "idle", "presses"):
        lb, la = a_b[key], a_a[key]
        if len(lb) != len(la):
            problems.append(f"{label}{app}.{key}: {len(lb)} runs before, {len(la)} after")
            continue
        if [(x["stack"], x["i"], x["order"]) for x in lb] != [(x["stack"], x["i"], x["order"]) for x in la]:
            problems.append(f"{label}{app}.{key}: stacks, rounds or orders differ")
        if keyset(lb) != keyset(la):
            problems.append(f"{label}{app}.{key}: keys differ {keyset(lb)} / {keyset(la)}")
        if [x.get("statuses") for x in lb] != [x.get("statuses") for x in la]:
            problems.append(f"{label}{app}.{key}: statuses differ")
        if [bool(x.get("error")) for x in lb] != [bool(x.get("error")) for x in la]:
            problems.append(f"{label}{app}.{key}: failures differ")
    cells = (set(runs_by_cell(a_b)) | set(runs_by_cell(a_a))) - skip
    n = compare_cells(a_b, a_a, cells, problems, label)
    if a_b["problems"] != a_a["problems"]:
        problems.append(f"{label}{app}: problems differ: {a_b['problems'][:2]} / {a_a['problems'][:2]}")
    if sorted(a_b["browsers"]) != sorted(a_a["browsers"]):
        problems.append(f"{label}{app}: browsers differ")
    return n


def check_meta(before, after, problems):
    mb, ma = before["meta"], after["meta"]
    if sorted(mb) != sorted(ma):
        problems.append(f"meta keys differ: {sorted(mb)} / {sorted(ma)}")
    for key in ("args", "minRuns", "network", "playwright"):
        a = dict(mb[key]) if isinstance(mb[key], dict) else mb[key]
        b = dict(ma[key]) if isinstance(ma[key], dict) else ma[key]
        if isinstance(a, dict):
            a.pop("json", None)
            b.pop("json", None)
        if a != b:
            problems.append(f"meta.{key} differs: {a} / {b}")
    if sorted(mb["machine"]) != sorted(ma["machine"]):
        problems.append("machine keys differ")


def app_of(run_file, name):
    for a in run_file["apps"]:
        if a["app"] == name:
            return a
    return None


def main(argv):
    again = []
    rest = []
    it = iter(argv[1:])
    for a in it:
        if a == "--again":
            rerun, base = next(it).split(":")
            again.append((rerun, base))
        else:
            rest.append(a)
    before, after = load(rest[0]), load(rest[1])
    problems = []
    check_meta(before, after, problems)
    set_aside = {}
    compared = 0
    for a_b, a_a in zip(before["apps"], after["apps"]):
        dirty = failed_cells(a_b) | failed_cells(a_a)
        set_aside[a_a["app"]] = dirty
        compared += compare_app(a_b, a_a, problems, "", dirty)
    print(f"runs: before {sum(len(a['runs']) for a in before['apps'])}, after {sum(len(a['runs']) for a in after['apps'])}")
    print(f"cells compared in the two runs: {compared}")
    for app, cells in set_aside.items():
        for c in sorted(cells, key=str):
            print(f"  set aside ({app}): a run was lost in {c}")
    for rerun_path, base_path in again:
        rerun, base = load(rerun_path), load(base_path)
        for a_r in rerun["apps"]:
            a_base = app_of(base, a_r["app"])
            if a_base is None:
                continue
            cells = {c for c in set_aside.get(a_r["app"], set()) if c in runs_by_cell(a_r)}
            lost_again = failed_cells(a_r) | failed_cells(a_base)
            n = compare_cells(a_base, a_r, cells, problems, f"[again {rerun_path.split('/')[-1]}] ")
            print(f"again {rerun_path.split('/')[-1]} vs {base_path.split('/')[-1]}: {n} cells compared, runs lost again in {sorted(lost_again, key=str)}")
    print(f"problems recorded: before {[len(a['problems']) for a in before['apps']]}, after {[len(a['problems']) for a in after['apps']]}")
    print(f"differences: {len(problems)}")
    for p in problems[:60]:
        print(" ", p)
    return 1 if problems else 0


sys.exit(main(sys.argv))
