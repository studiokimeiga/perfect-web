#!/usr/bin/env bash
# The instrument's own tests before any change: node and python, at the PR's head
# as it was (35f1943d), in a copy of the files they need.
# usage: before-run.sh <out-dir>
set -u
OUT=${1:-$HOME/h2h-scratch}
SRC=/home/haki/code/pw-wt/head-to-head
D=/tmp/h2h-before
rm -rf "$D"
mkdir -p "$D"
df -h /tmp | tail -1
git -C "$SRC" archive 35f1943d benchmarks scripts spikes/todomvc-cypress docs/evidence/E14 package.json pnpm-workspace.yaml .nvmrc justfile just 2>/dev/null | tar -x -C "$D" || { echo "archive failed"; exit 1; }
cd "$D" || exit 1
du -sh "$D" | tail -1
ln -s "$SRC/node_modules" "$D/node_modules"
[ -e "$SRC/benchmarks/headtohead/node_modules" ] && ln -s "$SRC/benchmarks/headtohead/node_modules" "$D/benchmarks/headtohead/node_modules"
mkdir -p "$D/target"
[ -e "$SRC/target/release" ] && ln -s "$SRC/target/release" "$D/target/release"
echo "tree: 35f1943d ($(git -C "$SRC" rev-parse --short 35f1943d))"
node --version
node --test --test-reporter=tap benchmarks/headtohead/test/*.mjs > "$OUT/node-before.tap" 2> "$OUT/node-before.stderr"
echo "node --test exit: $?"
tail -9 "$OUT/node-before.tap"
cd scripts || exit 1
python3 --version
python3 -m unittest -v tests.test_head_to_head > "$OUT/python-before.txt" 2>&1
echo "python unittest exit: $?"
tail -6 "$OUT/python-before.txt"
