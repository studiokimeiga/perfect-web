#!/usr/bin/env bash
# The live run of the instrument as it was (35f1943d's sources of the instrument), on a calm
# machine, with the flags, seed and ports of the run after the refactor (smoke-after3.sh).
# The ten instrument modules are checked out as they were at 35f1943d for the run and as
# HEAD has them again after it (also when the script is stopped by a signal it can catch).
cd /home/haki/code/pw-wt/head-to-head || exit 1
FILES=""
for f in head-to-head lib load measure report validate targets static-host feature-change museum-classes; do
  FILES="$FILES benchmarks/headtohead/$f.mjs"
done
restore() {
  git checkout HEAD -- $FILES
  echo "restored: $(git status --short | grep -v '^ M docs/' | wc -l) files differ from HEAD" >> "$HOME/h2h-scratch/smoke-before2.start"
}
trap restore EXIT
rm -f "$HOME/h2h-scratch/smoke-before2.exit"
if [ -n "$(git status --short | grep -v '^ M docs/')" ]; then
  echo "the tree is not as expected: $(git status --short | head -3)" > "$HOME/h2h-scratch/smoke-before2.start"
  exit 1
fi
git checkout 35f1943d -- $FILES
echo "start: $(date -u +%FT%TZ) head $(git rev-parse --short HEAD), the instrument's modules as at $(git rev-parse --short 35f1943d), load $(cut -d' ' -f1-3 /proc/loadavg)" > "$HOME/h2h-scratch/smoke-before2.start"
git status --short | grep -v '^ M docs/' >> "$HOME/h2h-scratch/smoke-before2.start"
PORT=13441 node benchmarks/headtohead/head-to-head.mjs --apps todomvc,store --engines chromium,firefox,webkit --conditions cold,warm --runs 5 --server-runs 5 --load-seconds 2 --settle 0 --json "$HOME/h2h-scratch/smoke-before2.json" > "$HOME/h2h-scratch/smoke-before2.txt" 2> "$HOME/h2h-scratch/smoke-before2.err"
echo "exit=$?" > "$HOME/h2h-scratch/smoke-before2.exit"
echo "end: $(date -u +%FT%TZ)" >> "$HOME/h2h-scratch/smoke-before2.start"
