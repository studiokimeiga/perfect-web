#!/usr/bin/env bash
# Looks for a test that fails when the machine is slow: the instrument's node tests,
# on two cores shared with busy loops. usage: flake-hunt.sh <runs> <busy loops>
RUNS=${1:-12}
BUSY=${2:-6}
cd /home/haki/code/pw-wt/head-to-head/benchmarks/headtohead || exit 1
pids=""
for n in $(seq 1 "$BUSY"); do
  taskset -c 0,1 bash -c 'while :; do :; done' &
  pids="$pids $!"
done
for i in $(seq 1 "$RUNS"); do
  taskset -c 0,1 node --test --test-reporter=tap test/*.test.mjs > "$HOME/h2h-scratch/flake-$i.tap" 2>&1
  rc=$?
  echo "run $i exit=$rc $(grep -E '^# (pass|fail)' "$HOME/h2h-scratch/flake-$i.tap" | tr '\n' ' ')"
  if [ "$rc" -ne 0 ]; then grep -E '^not ok' "$HOME/h2h-scratch/flake-$i.tap" | head -5; fi
done
kill $pids 2>/dev/null
wait 2>/dev/null
echo "hunt done"
