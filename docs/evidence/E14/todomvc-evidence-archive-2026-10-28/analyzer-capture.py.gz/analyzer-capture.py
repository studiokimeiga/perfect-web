"""Capture actual before/after analyzer outcomes, without altering source."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/haki/code/pw-wt/session-followup-20261027')
work=Path('/mnt/c/Users/haki/Documents/Codex/2026-10-26/con/work')
label,expect=sys.argv[1:]
need_pass={'red':False,'green':True}[expect]
out=work/label;out.mkdir(exist_ok=False)
os.chdir(root);sys.path.insert(0,str(root/'scripts'))
import producer_process
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
inputs={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if p}
(out/'all-inputs-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
rows=[]
commands=[('ruff',['python3','scripts/quality_delta.py','--base','a0db8884deb2b3ba37faee59afcdee44a92c6b1c']),
          ('fallow',['/home/haki/.npm/_npx/7955810aeed8257f/node_modules/@fallow-cli/linux-x64-gnu/fallow','--format','json','--quiet','audit','--base','a0db8884deb2b3ba37faee59afcdee44a92c6b1c'])]
if need_pass:commands.insert(0,('preflight',['just','preflight']))
for name,cmd in commands:
    start=time.time();owned=[]
    result=producer_process.run(cmd,cwd=root,timeout=600,grace=2,
        on_reaped=lambda pid,status,timed_out,cancelled:owned.append({'pid':pid,'status':status,'timed_out':timed_out,'cancelled':cancelled}))
    raw=result.stdout
    (out/(name+'.log')).write_text(raw)
    row={'head':head,'name':name,'cmd':cmd,'started':start,'finished':time.time(),'exit':result.returncode,
         'owned_reaped':owned,'log_sha256':hashlib.sha256(raw.encode()).hexdigest()}
    rows.append(row)
    (out/(name+'.result.json')).write_text(json.dumps(row,indent=2)+'\n')
    if (result.returncode==0)!=need_pass:raise RuntimeError(name+' unexpected analyzer outcome')
    print(name,'exit='+str(result.returncode),flush=True)
if any(hashlib.sha256((root/p).read_bytes()).hexdigest()!=digest for p,digest in inputs.items()):raise RuntimeError('input drift')
if subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()!=head:raise RuntimeError('head drift')
(out/'all-inputs-after.json').write_text(json.dumps(inputs,indent=2)+'\n')
(out/'complete.json').write_text(json.dumps({'head':head,'complete':True,'expectation':expect,'gates':rows,
    'all_tracked_inputs_unchanged':True,'scope':'actual quality reproduction/repair checks only; no whole recipe or merge acceptance'},indent=2)+'\n')
