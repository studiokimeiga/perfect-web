#!/bin/bash
set -euo pipefail
cd /home/haki/code/pw-wt/data-path
source /home/haki/pw-setup/env.sh
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration/upload_lifetime_probe.py > /tmp/pw-protected-migration/upload-lifetime-design-probe.log 2>&1
