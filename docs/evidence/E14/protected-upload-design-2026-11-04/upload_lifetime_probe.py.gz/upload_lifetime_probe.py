"""Synthetic proposed-protocol probe, NOT a generic adapter/upload test."""
from pathlib import Path
import os,subprocess,select,time,tempfile,uuid,hashlib
from urllib.parse import urlsplit,unquote

class Psql:
    def __init__(self):
        env=os.environ.copy();url=urlsplit(env['PW_TABLES_DATABASE_URL'])
        env.update(PGHOST=url.hostname,PGPORT=str(url.port or 5432),PGUSER=unquote(url.username or ''),PGPASSWORD=unquote(url.password or ''),PGDATABASE=url.path.lstrip('/'))
        self.p=subprocess.Popen(['psql','-XqAt','-v','ON_ERROR_STOP=1'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,bufsize=0)
        self.pending=b'';self.n=0
    def sql(self,sql):
        self.n+=1;marker=f'END_{self.n}_{id(self)}'.encode()
        self.p.stdin.write(sql.encode()+b'\n\\echo '+marker+b'\n');self.p.stdin.flush()
        until=time.monotonic()+15
        while marker+b'\n' not in self.pending:
            if self.p.poll() is not None: raise RuntimeError('psql ended: '+self.p.stderr.read().decode())
            ready,_,_=select.select([self.p.stdout],[],[],max(0,until-time.monotonic()))
            if not ready: raise TimeoutError('psql marker timed out')
            self.pending+=os.read(self.p.stdout.fileno(),8192)
        value,self.pending=self.pending.split(marker+b'\n',1)
        return value.decode().strip()
    def close(self):
        if self.p.poll() is None:
            self.p.terminate()
            try:self.p.wait(timeout=5)
            except subprocess.TimeoutExpired:self.p.kill();self.p.wait()

schema='pw_upload_probe_'+uuid.uuid4().hex[:16]
sessions=[]
def opened():
    c=Psql();sessions.append(c);c.sql(f'SET search_path TO {schema};');return c
lock=7712345678123
admin=opened()
try:
    print('SYNTHETIC lifetime protocol probe: no generic adapter/upload implementation exists yet.',flush=True)
    print('PostgreSQL '+admin.sql('SHOW server_version;'),flush=True)
    admin.sql(f'CREATE SCHEMA {schema}; CREATE TABLE registry (key text PRIMARY KEY, generation text NOT NULL); CREATE TABLE refs (key text PRIMARY KEY REFERENCES registry(key));')
    data=b'synthetic identical bytes';key=hashlib.sha256(data).hexdigest()
    with tempfile.TemporaryDirectory(prefix='pw-upload-lifetime-') as directory:
        root=Path(directory)
        for versioned in [False,True]:
            a=opened();b=opened();pid=int(a.sql('SELECT pg_backend_pid();'))
            admin.sql("TRUNCATE refs,registry; INSERT INTO registry VALUES ('asset','old'); INSERT INTO refs VALUES ('asset');")
            old=root/('old' if versioned else 'flat')/key;old.parent.mkdir(exist_ok=True);old.write_bytes(data)
            assert a.sql(f'SELECT pg_advisory_lock({lock}); BEGIN ISOLATION LEVEL SERIALIZABLE; DELETE FROM refs; COMMIT; SELECT count(*) FROM refs;').splitlines()[-1]=='0'
            # A has committed and inspected no references, then pauses before
            # its captured physical cleanup; kill its ACTUAL lock-owning backend.
            assert admin.sql(f'SELECT pg_terminate_backend({pid});')=='t'
            new=root/('new' if versioned else 'flat')/key;new.parent.mkdir(exist_ok=True)
            b.sql(f"SELECT pg_advisory_lock({lock}); BEGIN ISOLATION LEVEL SERIALIZABLE; UPDATE registry SET generation='new' WHERE key='asset'; INSERT INTO refs VALUES ('asset');")
            new.write_bytes(data) # B keeps BEFORE committing its new ref.
            b.sql('COMMIT;')
            assert b.sql("SELECT count(*) FROM refs JOIN registry USING(key) WHERE generation='new';")=='1'
            old.unlink() # A resumes old captured cleanup after losing its lock.
            if versioned:
                assert new.read_bytes()==data
                print('PASS immutable generations: new committed reference and actual bytes survive stale old cleanup.',flush=True)
            else:
                assert not new.exists()
                print('REPRODUCED advisory-only fault: live committed reference, identical republished bytes deleted by stale cleanup.',flush=True)
            b.sql(f'SELECT pg_advisory_unlock({lock});')
            a.close();b.close()
        a=opened();b=opened()
        admin.sql("TRUNCATE refs,registry; INSERT INTO registry VALUES ('asset','old'); INSERT INTO refs VALUES ('asset');")
        assert a.sql('BEGIN ISOLATION LEVEL REPEATABLE READ; SELECT count(*) FROM refs;')=='1'
        b.sql('DELETE FROM refs;')
        assert a.sql(f'SELECT pg_advisory_lock({lock}); SELECT count(*) FROM refs;').splitlines()[-1]=='1'
        a.sql(f'ROLLBACK; SELECT pg_advisory_unlock({lock});')
        assert a.sql(f'SELECT pg_advisory_lock({lock}); BEGIN ISOLATION LEVEL SERIALIZABLE; SELECT count(*) FROM refs;').splitlines()[-1]=='0'
        a.sql(f'ROLLBACK; SELECT pg_advisory_unlock({lock});')
        print('PASS snapshot placement witness: late lock retains stale refs; lock before BEGIN sees latest committed refs.',flush=True)
finally:
    try:admin.sql(f'DROP SCHEMA IF EXISTS {schema} CASCADE;')
    finally:
        for c in sessions:c.close()
