#!/usr/bin/env bash
set -euo pipefail
. /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export PW_MUTANT_SLOTS=4 CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
source=$(git rev-parse HEAD)
expected=$(cat /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/current_owned_source.txt)
[ "$source" = "$expected" ]
log_dir=/tmp/pw-owned-final/$source
mkdir -p "$log_dir"
printf '%s\n' "$source" > "$log_dir/source.txt"
git status --porcelain --untracked-files=all > "$log_dir/start-status.txt"
git diff --quiet HEAD -- . ':(exclude)docs/evidence'
psql "$PW_TABLES_DATABASE_URL" -Atc 'SHOW server_version' > "$log_dir/postgres-version.txt"
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/audit_row_preservation.py > "$log_dir/row-preservation-start.json"
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/audit_durable_preservation.py > "$log_dir/durable-preservation-start.json"
printf '%s\n' 'All native mutation recipes use ADR0357 four isolated copies, four Cargo jobs and two native test threads per copy. Refusal parts execute concurrently in root and copy3, each using its normal sequential producer. CI unsets slots and uses eight native test threads.' > "$log_dir/execution-settings.txt"
run_step() {
  local label="$1"
  shift
  local status=0
  local started=$SECONDS
  "$@" > "$log_dir/$label.log" 2>&1 || status=$?
  printf '%s\n' "$status" > "$log_dir/$label.exit"
  printf '%s %s %s\n' "$label" "$status" "$((SECONDS-started))" >> "$log_dir/steps.txt"
  if [ "$status" -ne 0 ]; then tail -75 "$log_dir/$label.log"; return "$status"; fi
  git diff --quiet HEAD -- . ':(exclude)docs/evidence'
}
run_step row just e14-row-ownership
run_step data-path just e14-data-path
run_step d3-postgres just e14-d3-postgres
run_step durable-tables just e14-durable-tables
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/run_owned_refusal_pair.py "$source" "$log_dir" > "$log_dir/refusal-pair.log" 2>&1
git diff --quiet HEAD -- . ':(exclude)docs/evidence'
git status --porcelain --untracked-files=all > "$log_dir/ci-start-status.txt"
python3 - "$log_dir" <<'PY'
import hashlib,json,pathlib,subprocess,sys
repo=pathlib.Path.cwd()
names=subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines()
assert all(name.startswith('docs/evidence/') for name in names), names
output={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in names}
(pathlib.Path(sys.argv[1])/'ci-input-hashes.json').write_text(json.dumps(output,indent=2)+'\n')
PY
run_step ci env -u PW_MUTANT_SLOTS RUST_TEST_THREADS=8 just ci
run_step anchors python3 scripts/mutation_anchors.py
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/audit_row_preservation.py > "$log_dir/row-preservation-end.json"
python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/audit_durable_preservation.py > "$log_dir/durable-preservation-end.json"
git status --porcelain --untracked-files=all > "$log_dir/end-status.txt"
printf 'Completed all local row/browser/PostgreSQL gates at %s. Logs: %s\n' "$source" "$log_dir"
