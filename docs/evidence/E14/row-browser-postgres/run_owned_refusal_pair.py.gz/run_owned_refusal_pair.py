from pathlib import Path
import json,os,re,signal,subprocess,sys,time
repo=Path('/home/haki/code/pw-wt/data-path')
source=sys.argv[1];logs=Path(sys.argv[2]);slot=repo/'target/mutant-slots/3'
for root in [repo,slot]:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
    subprocess.run(['git','diff','--quiet','HEAD','--','.',':(exclude)docs/evidence'],cwd=root,check=True)
jobs=[]
try:
    for label,root,port in [('refusal',repo,3141),('refusal-2',slot,3909)]:
        env=os.environ.copy()
        for key in ['PW_MUTANT_SLOTS','PW_MUTANT_PICK','PW_MUTANT_SLOT']: env.pop(key,None)
        env.update(PORT=str(port),CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='2')
        output=(logs/f'{label}.log').open('wb')
        started=time.monotonic()
        child=subprocess.Popen(['just','e14-'+label],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
        jobs.append((label,root,port,child,output,started))
    finished={}
    while len(finished)<len(jobs):
        for label,_,_,child,_,started in jobs:
            code=child.poll()
            if label not in finished and code is not None:
                finished[label]=(code,round(time.monotonic()-started))
        if len(finished)<len(jobs): time.sleep(0.2)
    results=[]
    for label,root,port,child,output,started in jobs:
        code,elapsed=finished[label];output.close()
        (logs/f'{label}.exit').write_text(str(code)+'\n')
        with (logs/'steps.txt').open('a') as f: f.write(f'{label} {code} {elapsed}\n')
        results.append({'label':label,'cwd':str(root),'port_base':port,'exit':code,'elapsed_seconds_observed':elapsed})
    (logs/'refusal-execution-settings.json').write_text(json.dumps({'source':source,'parts_execute_concurrently':True,'each_uses_standard_sequential_producer':True,'results':results},indent=2)+'\n')
    failures=[r for r in results if r['exit']]
    if failures:
        for r in failures: print((logs/(r['label']+'.log')).read_text(errors='replace')[-12000:])
        raise SystemExit(1)
    for label,root,_,_,_,_ in jobs:
        subprocess.run(['git','diff','--quiet','HEAD','--','.',':(exclude)docs/evidence'],cwd=root,check=True)
        receipt=root/f'docs/evidence/E14/{label}.txt';text=receipt.read_text()
        expected=23 if label=='refusal' else 7
        assert source in text[:1500] and source+' + uncommitted changes' not in text[:1500]
        assert f'{expected} of {expected} mutants killed; 0 refused' in text
        if root!=repo: (repo/f'docs/evidence/E14/{label}.txt').write_bytes(receipt.read_bytes())
    print('Both complete refusal recipes passed at '+source)
finally:
    for _,_,_,child,output,_ in jobs:
        if child.poll() is None:
            try: os.killpg(child.pid,signal.SIGINT)
            except ProcessLookupError: pass
            try: child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                try: os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                child.wait()
        if not output.closed: output.close()
