#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
expected=df206cfa002494c224611e178e5eb0764834b56c
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
log=/tmp/pw-protected-migration
git rev-parse HEAD > "$log/upload-cases-reviewed-source.txt"
run() { local name="$1"; shift; echo "starting $name"; "$@" > "$log/upload-cases-reviewed-$name.log" 2>&1; echo "$name passed"; }
run host cargo test --locked -p pw-host --features engine
run memory cargo test --locked -p pw-table-memory
run pg cargo test --locked -p pw-table-postgres
run server cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::conformance:: tests::tables:: tests::tables_pg::
run preflight just preflight
helper=/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration/upload_cases_controls.py
run row-controls python3 "$helper" row_ownership
run pg-controls python3 "$helper" d3_postgres
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> "$log/upload-cases-reviewed-source.txt"
echo 0 > "$log/upload-cases-reviewed.exit"
