"""Complete per-binary native inventories for all fifteen closed-case faults."""
from pathlib import Path
import importlib.util,sys,json,hashlib
root=Path('/home/haki/code/pw-wt/data-path');sys.path.insert(0,str(root/'scripts'))
import cargo_assertion_results,producer_process
campaign=sys.argv[1];assert campaign in ['row_ownership','d3_postgres']
spec=importlib.util.spec_from_file_location(campaign,root/f'scripts/{campaign}_mutations.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.MUTANTS=[m for m in module.MUTANTS if m[0].startswith('closed cases ')]
assert len(module.MUTANTS)==(14 if campaign=='row_ownership' else 4)
crate='pw-table-memory' if campaign=='row_ownership' else 'pw-table-postgres'
module.TESTS=[['cargo','test','--quiet','--locked','-p',crate,'--test',test] for test in ['compiled_cases','compiled_assets']]
if campaign=='row_ownership': module.TESTS.append(['cargo','test','--quiet','--locked','-p','pw-host','--features','engine','--lib'])
sources=sorted((root/'runtime').rglob('*.rs'));inventory={};n=0
out=Path('/tmp/pw-protected-migration')/f'upload-cases-reviewed-strict-{campaign}';out.mkdir(exist_ok=True)
def strict():
 global n
 n+=1;passed=failed=0
 for i,cmd in enumerate(module.TESTS):
  child=producer_process.run(cmd+['--','--format=pretty','--test-threads=2'],cwd=root,timeout=1200)
  path=out/f'run-{n:02}-{i:02}.log';path.write_text(child.stdout)
  result=cargo_assertion_results.validate(child.returncode,child.stdout,root=root,sources=sources,expected=inventory.get(i))
  path.with_suffix('.json').write_text(json.dumps({'command':cmd,'exit':child.returncode,'valid':result.valid,'passed':result.passed,'failed':result.failed,'sha256':hashlib.sha256(child.stdout.encode()).hexdigest()},indent=2))
  if not result.valid:
   print(child.stdout[-3000:],flush=True);return False,passed,failed
  inventory.setdefault(i,cargo_assertion_results.names(child.stdout));passed+=result.passed;failed+=result.failed
 return True,passed,failed
module.run_tests=strict;sys.argv=[sys.argv[0]];sys.exit(module.main())
