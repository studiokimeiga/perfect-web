from pathlib import Path
import gzip,hashlib,re,subprocess
root=Path('/home/haki/code/pw-wt/data-path');logs=Path('/tmp/pw-protected-migration')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='df206cfa002494c224611e178e5eb0764834b56c'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
assert (logs/'upload-cases-reviewed.exit').read_text().strip()=='0'
assert '14 of 14 mutants killed' in (logs/'upload-cases-reviewed-row-controls.log').read_text()
assert '4 of 4 mutants killed' in (logs/'upload-cases-reviewed-pg-controls.log').read_text()
out=root/'docs/evidence/E14/protected-upload-cases-2026-11-04';assert not out.exists();out.mkdir()
files=list(logs.glob('upload-cases-reviewed-*.*'))+[logs/'upload-cases-reviewed.exit',logs/'upload-cases-native-red2.log',logs/'upload-cases-upgrade-red.log',logs/'upload-cases-payload-abi2.log']
for d in logs.glob('upload-cases-reviewed-strict-*'):
 if d.is_dir():
  for p in d.iterdir():
   (out/(d.name+'-'+p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in files:
 if p.is_file():(out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
helper=Path('/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration')
for name in ['upload_cases_reviewed_frozen.sh','upload_cases_controls.py','upload_cases_record.py']:
 (out/(name+'.gz')).write_bytes(gzip.compress((helper/name).read_bytes(),mtime=0))
counts={kind:sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',(logs/f'upload-cases-reviewed-{kind}.log').read_text())) for kind in ['host','memory','pg','server']}
(out/'review.txt').write_text('Immutable review of a5608eb6 found additive optional case column type drift: migrate::kind_of JSON fallback versus fresh shape bytea. Parent reproduced actual json vs bytea before repair. Successor df206cfa uses shared mapping; re-review CLEAR. Added actual WIT payload mismatch valid neighbor and invalid empty/punctuation names. Final exact-source native/control receipts are separate. Upload storage/lifetime remain disabled and unproved.\n')
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir())))
record=root/'docs/diagnostics/protected-upload-cases-2026-11-04.md'
record.write_text(f'''# Upload kind wire encoding: reviewed local prerequisite

Frozen source df206cfa002494c224611e178e5eb0764834b56c, clean before/after.
Host {counts['host']} (9 existing ignored), memory {counts['memory']}, actual
configured PostgreSQL {counts['pg']}, selected server {counts['server']} and
preflight 5,283 passed. Strict native complete inventories: row baseline48,
14/14 controls killed; PostgreSQL baseline7, 4/4 killed. No stopped process or
invalid producer counts. This closes the closed-case wire slice only: generic
upload storage/lifetime/HTTP and canonical feed/store migration remain pending.

Closed payload-free variants store canonical WIT tag strings, use actual
Val::Variant values, and compare tags consistently in host/memory/PostgreSQL
bytea keys, indexes, counts, windows and range marks. Nested fields round-trip.
AB/A_Z reverse declaration/source order relative to wire ab/a-z. The independent
conformance suite checks both adapters at its existing two sizes. Forged whole
inputs, unknown stored tags, unsupported schemas and ABI mismatches refuse.

The first source a5608eb6 passed its then-covered native/15 controls, but review
found a genuine untested upgrade path: adding Option<Kind> used migrate.rs's JSON
fallback while fresh creation used bytea. The retained actual-PG red assertion
shows json versus bytea. Shared shape::column_of now owns both mappings; the
upgrade regression preserves an old row as None, checks actual bytea, writes
Some through compiled code, and checks Some/None after reopening. A focused
mutation reinstates the old additive-only mapping and fails that assertion.
Separate immutable re-review is clear.

Review also prompted actual Wasmtime payload-bearing variant ABI versus closed
metadata with identical names/order and a valid payload-free neighbor, plus
empty/punctuation-only names. Separate faults isolate each. Unbound asset guards
now have otherwise-supported Ref.kind neighbors: removing either guard causes
the corresponding native test to fail, rather than being masked by unsupported
variant storage. The guards remain closed.

Reproduce from the frozen source with the gzip archived runner and control
helper in [the evidence directory](../evidence/E14/protected-upload-cases-2026-11-04/).
Per-binary outputs and validator JSON, source guards, raw native red witnesses
and immutable review summary are hash covered by SHA256SUMS. No upload lifecycle,
browser, whole final campaign, hosted landing or production conversion claim.
''')
status=root/'docs/STATUS.md';s=status.read_text();needle='Earlier green records below apply to their named sources only.';assert s.count(needle)==1
s=s.replace(needle,'''Closed-case upload kind wire source `df206cfa` passed frozen host119 (9 existing
ignored), memory140, actual PostgreSQL102, selected server63, preflight5,283 and
18/18 strict controls. Review-reproduced additive-column type drift is repaired
and independently re-reviewed. See the [wire record](diagnostics/protected-upload-cases-2026-11-04.md).
Asset storage/lifetime integration remains next; its guards stay closed.
'''+needle);status.write_text(s)
print(counts)
