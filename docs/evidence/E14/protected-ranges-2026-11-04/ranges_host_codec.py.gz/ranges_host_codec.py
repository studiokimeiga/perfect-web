from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'runtime/pw-host/src/engine/table_link.rs'
text = path.read_text()
assert 'fn range_params' not in text
text = text.replace('    let params = window_params(read, params)?;', '    let params = range_params(read, params)?;', 1)
old = '        selector(words, &read.by, &given.ty())?;'
assert text.count(old) == 1
text = text.replace(old, '''        if read.primitive.range() {
            record(&read.count_columns()?, &given.ty())?;
        } else {
            selector(words, &read.by, &given.ty())?;
        }''', 1)
anchor = 'pub(super) fn window_params'
assert text.count(anchor) == 1
text = text.replace(anchor, r'''/// Scalar range marks use the actual order type, not a window's Int limit.
pub(super) fn range_params<'a>(read: &Read, params: &'a [Type]) -> Result<&'a [Type], String> {
    if read.primitive.range() && !read.many() {
        let (mark, selectors) = params.split_last().ok_or("a range count takes its order mark after the selectors")?;
        stored(&read.mark_column()?.stored, mark)?;
        return Ok(selectors);
    }
    window_params(read, params)
}

''' + anchor, 1)
start = text.index('pub(super) fn count_results(')
end = text.index('\n}', start) + 2
block = text[start:end]
assert block.count('match read.by.as_slice()') == 1
block = block.replace('    match read.by.as_slice()', '    let columns = read.count_columns()?;\n    match columns.as_slice()', 1)
text = text[:start] + block + text[end:]
start = text.index('fn count_answer(')
end = text.index('\nfn write_answer(', start)
block = text[start:end]
block = block.replace('    if !read.many() {', '    let columns = read.count_columns()?;\n    if !read.many() {', 1)
block = block.replace('args.len() != read.by.len()', 'args.len() != columns.len()', 1)
block = block.replace('read.by.iter().zip(args)', 'columns.iter().zip(args)', 1)
block = block.replace('match read.by.as_slice()', 'match columns.as_slice()', 1)
text = text[:start] + block + text[end:]
start = text.index('fn asked_selectors(')
end = text.index('\nfn shown(', start)
block = text[start:end]
block = block.replace('    let words =', '    let columns = read.count_columns()?;\n    let words =', 1)
block = block.replace('read.by.as_slice()', 'columns.as_slice()', 1)
block = block.replace('                        atom(value)', '                        check_value(&column.stored, value)?;\n                        atom(value)', 1)
text = text[:start] + block + text[end:]
path.write_text(text)

path = root / 'runtime/pw-host/src/engine/table_selectors.rs'
text = path.read_text()
anchor = 'pub fn decode_read_arguments(read: &Read, args: &[Val]) -> Result<Vec<Value>, String> {\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + r'''    if read.primitive.range() {
        let columns = read.count_columns()?;
        if read.many() {
            let [Val::List(requests)] = args else { return Err("a set range count takes one list of selector-and-mark records".into()); };
            let requests = requests.iter().map(|value| key(&columns, value)).collect::<Result<Vec<_>, _>>()?;
            return Ok(vec![Value::Array(requests)]);
        }
        return positional(read.primitive, &columns, args);
    }
''', 1)
path.write_text(text)

path = root / 'runtime/pw-host/src/engine/table_results.rs'
text = path.read_text()
start = text.index('fn encode_count(')
end = text.index('\n/// Encode a single-row', start)
block = text[start:end]
anchor = '    let entries = value'
assert block.count(anchor) == 1
block = block.replace(anchor, '    let columns = read.count_columns()?;\n' + anchor, 1)
block = block.replace('match read.by.as_slice()', 'match columns.as_slice()', 1)
text = text[:start] + block + text[end:]
path.write_text(text)

path = root / 'runtime/pw-host/src/engine/table_owners.rs'
text = path.read_text()
anchor = '''        Access::Read(read) if read.many() => {
'''
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + r'''            if read.primitive.range() {
                let [_, Val::List(requests)] = args.as_slice() else {
                    return Err(format!("`{import}` takes its reader and selector-and-mark records"));
                };
                let columns = read.count_columns()?;
                let (first, following) = columns.split_first().ok_or("a range has no reader")?;
                let keys = requests.iter().map(|request| {
                    let rest = table_link::exact_row(following, request)?;
                    let mut fields = vec![(first.wit.clone(), Val::String(user.clone()))];
                    fields.extend(rest.iter().cloned());
                    Ok(Val::Record(fields))
                }).collect::<Result<Vec<_>, String>>()?;
                return Ok(vec![Val::List(keys)]);
            }
''', 1)
text = text.replace('            let params = table_link::window_params(read, params)?;', '            let params = table_link::range_params(read, params)?;', 1)
old = '                table_link::selector(words, &read.by[1..], &rest.ty())?;'
assert text.count(old) == 1
text = text.replace(old, '''                if read.primitive.range() {
                    table_link::record(&read.count_columns()?[1..], &rest.ty())?;
                } else {
                    table_link::selector(words, &read.by[1..], &rest.ty())?;
                }''', 1)
path.write_text(text)
print('range typed WIT input/result checks and owned record normalization added')
