#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
cargo fmt --all
cargo test --locked -p pw-table-postgres --test primitives --test parity > /tmp/pw-protected-migration/ranges-pg-contracts.log 2>&1
cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::conformance:: tests::tables_pg::the_suite_holds > /tmp/pw-protected-migration/ranges-conformance-green.log 2>&1
