from pathlib import Path

root=Path('/home/haki/code/pw-wt/data-path')
path=root/'runtime/pw-table-memory/tests/support/ranges.rs'
text=path.read_text()
assert 'MaybeSince' not in text
anchor='    if let Some(kind) = kind {'
assert text.count(anchor)==1
text=text.replace(anchor,'''    app=app.replace("import Notes\\n","import Notes\\nimport List\\nimport Notes.{ NotesToAfter }\\n");
    let request_mark=if kind.is_some() {"Mark"} else {"Int"};
    app.push_str(&format!("\\ntype RangeRequest = RangeRequest {{ to: UserId, mark: {request_mark} }}\\n"));
''' + anchor,1)
anchor='        ("SinceMine", '
assert text.count(anchor)==1
new='''        ("MaybeSince", "reader: User<UserId>, mark: Int, run: Bool", "Int", "reader, mark, run", "NotesChanged(reader)", "if run { Notes.count_after_by_author(reader, mark) } else { 0 }"),
        ("RangeFromRequests", "reader: User<UserId>, requests: List<RangeRequest>", "List<NotesAuthorToAfterCount>", "reader, requests", "NotesChanged(reader)", "let ranges = List.map(requests, request => NotesToAfter { to: request.to, __range_mark: request.mark })\\n    Notes.count_after_by_author_to_many(reader, ranges)"),
'''
text=text.replace(anchor,new+anchor,1)
anchor='        let params = if kind.is_some()'
assert text.count(anchor)==1
text=text.replace(anchor,'''        let body=body.replace("__range_mark",if owner==Some("after") {"after_mark"} else {"after"});
''' + anchor,1)
text=text.replace('vec![json!(0),json!(1),json!(1),json!(5)],vec![(json!(0),3),(json!(1),1),(json!(5),0)]','vec![json!(0),json!(1),json!(1),json!(5),json!(9_007_199_254_740_993i64)],vec![(json!(0),4),(json!(1),2),(json!(5),1),(json!(9_007_199_254_740_992i64),1),(json!(9_007_199_254_740_993i64),0)]',1)
path.write_text(text)

body=r'''

#[test]
fn pleris_constructs_heterogeneous_ranges_before_one_set_import() {
    let program=range_program(false);
    let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");
    tables.transaction(|tx| { for row in range_rows() { tx.write("pw:tables/notes#insert",&[row])?; } Ok(()) }).assert_ok("seed");
    let request=|to:&str,mark|Val::Record(vec![("to".into(),handle(to)),("mark".into(),Val::S64(mark))]);
    let args=[handle(ALICE),Val::List(vec![request(CAROL,1),request(BOB,1),request(BOB,0),request(BOB,1)])];
    let before=tables.statements();
    assert_eq!(query(&program,&tables,"RangeFromRequests",&as_user(ALICE),&args),Ok(vec![Val::List(vec![
        counted_range(vec![("author",handle(ALICE)),("to",handle(BOB))],0,2),
        counted_range(vec![("author",handle(ALICE)),("to",handle(BOB))],1,0),
        counted_range(vec![("author",handle(ALICE)),("to",handle(CAROL))],1,1),
    ])]));
    assert_eq!(tables.statements()-before,1,"pure map constructs the records, one data read follows");
}

#[test]
fn a_stale_scalar_range_import_is_refused_before_a_body_that_would_skip_it() {
    let mut stale=range_program(false);
    let current=range_program_order("bool");
    stale.manifest=current.manifest;
    let tables=MemoryTables::new(current.tables).assert_ok("current Bool-order tables");
    let before=tables.statements();
    let result=query(&stale,&tables,"MaybeSince",&as_user(ALICE),&[handle(ALICE),Val::S64(0),Val::Bool(false)]);
    assert!(result.as_ref().is_err_and(|why|why.contains("typed otherwise than tables.json")),"stale Int import must fail at link, even with its call on the unchosen branch: {result:?}");
    assert_eq!(tables.statements()-before,0);
}
'''
path=root/'runtime/pw-table-memory/tests/compiled_ranges.rs'
text=path.read_text(); assert 'fn pleris_constructs_heterogeneous_ranges' not in text
path.write_text(text+body)
pg=body.replace('let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");','''let Some(url)=common::database() else { return; };
    let scratch=common::Scratch::new(&url,"range_constructed");
    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");''')
pg=pg.replace('let tables=MemoryTables::new(current.tables).assert_ok("current Bool-order tables");','''let Some(url)=common::database() else { return; };
    let scratch=common::Scratch::new(&url,"range_stale_import");
    let tables=PgTables::open(&url,scratch.schema(),current.tables).assert_ok("current Bool-order tables");''')
pg=pg.replace('query(', 'q(').replace('tables.statements()', 'tables.operation_statements()')
path=root/'runtime/pw-table-postgres/tests/compiled_ranges.rs'
text=path.read_text(); assert 'fn pleris_constructs_heterogeneous_ranges' not in text
path.write_text(text+pg)
print('actual Pleris request construction, 2^53+1 precision, and stale-import-before-body witnesses added')
