#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
expected=f4fc668f9d6783993203fe27e02180a3e377fc0e
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
log=/tmp/pw-protected-migration
git rev-parse HEAD > "$log/ranges-frozen-source.txt"
run() { local name="$1"; shift; echo "starting $name"; "$@" > "$log/ranges-frozen-$name.log" 2>&1; echo "$name passed"; }
run core cargo test --locked -p pw-core --lib --test tables --test table_counts --test table_windows --test table_ranges --test table_owners --test bounded_reads --test bounded_tables --test invoked_by --test scheduled --test head_only
run cli cargo test --locked -p pw-cli --test tables
run host cargo test --locked -p pw-host --features engine
run memory cargo test --locked -p pw-table-memory
run pg cargo test --locked -p pw-table-postgres
run server cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::protected_migration:: identity:: tests::store_accounts:: tests::sign_in:: tests::tables:: tests::conformance:: tests::tables_pg:: tests::second_host::
run test-compile just test-compile
run preflight just preflight
run pg-controls python3 scripts/d3_postgres_mutations.py 'ranges ' 'counts row accounting' 'counts byte accounting' 'postgres operation accounting'
run row-controls python3 scripts/row_ownership_mutations.py 'ranges ' 'counts missing result keys' 'counts reversed selector order'
run data-controls python3 scripts/data_path_mutations.py 'ranges '
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> "$log/ranges-frozen-source.txt"
echo 0 > "$log/ranges-frozen.exit"
echo 'range frozen checks and source guard passed'
