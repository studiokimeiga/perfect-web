from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'compiler/pw-core/src/tables.rs'
text = path.read_text()
assert 'CountAfter' not in text
text = text.replace('    CountMany,\n', '''    CountMany,
    /// Rows of a declared selector strictly after its declared order mark.
    CountAfter,
    /// A count per distinct selector-and-mark request, including zero.
    CountAfterMany,
''', 1)
text = text.replace('            Primitive::CountMany => "count-many",', '''            Primitive::CountMany => "count-many",
            Primitive::CountAfter => "count-after",
            Primitive::CountAfterMany => "count-after-many",''', 1)
text = text.replace('matches!(self, Primitive::Count | Primitive::CountMany)', 'matches!(self, Primitive::Count | Primitive::CountMany | Primitive::CountAfter | Primitive::CountAfterMany)', 1)
anchor = '    pub fn window(self) -> bool {'
assert text.count(anchor) == 1
text = text.replace(anchor, '''    pub fn range(self) -> bool {
        matches!(self, Primitive::CountAfter | Primitive::CountAfterMany)
    }

''' + anchor, 1)
text = text.replace('                | Primitive::CountMany\n', '                | Primitive::CountMany\n                | Primitive::CountAfterMany\n', 1)
text = text.replace('    Counted { fields: Vec<String> },', '''    Counted { fields: Vec<String> },
    /// Selector fields plus a distinct typed order mark, never a stored row.
    Range { fields: Vec<String>, mark: String },
    /// Counts keyed by the complete selector and order mark.
    RangeCounted { fields: Vec<String> },''', 1)
anchor = '/// **The read of a prefix of the key**'
assert text.count(anchor) == 1
text = text.replace(anchor, '''/// A mark is distinct from every stored field, including its emitted identity.
pub fn after_field<'a>(fields: impl IntoIterator<Item = &'a str>) -> String {
    let fields = fields.into_iter().map(crate::wit::ident).collect::<BTreeSet<_>>();
    let mut name = "after".to_string();
    while fields.contains(&crate::wit::ident(&name)) {
        name.push_str("_mark");
    }
    name
}

''' + anchor, 1)
text = text.replace('    let mut counted_records: Vec<(Decl, Wrote)> = Vec::new();', '''    let mut counted_records: Vec<(Decl, Wrote)> = Vec::new();
    let mut range_records: Vec<(Decl, Wrote)> = Vec::new();
    let mark_name = after_field(fields.iter().map(|(name, _)| name.as_str()));
    let mark_ty = t.order.as_ref().and_then(|order| ty(&order.value));''', 1)
anchor = '        let name = format!("count_by_{}", by.join("_"));'
assert text.count(anchor) == 1
addition = r'''        if let Some(mark_ty) = &mark_ty {
            let name = format!("count_after_by_{}", by.join("_"));
            let mut given = keyed(r, &by);
            given.push((mark_name.clone(), mark_ty.clone()));
            push(Planned {
                name: name.clone(), params: given,
                ret: DeclaredType::new("Int", Vec::new()),
                primitive: Primitive::CountAfter, by: by.clone(), span: span.clone(),
            });
            let held = match r {
                Reading::Owner | Reading::Sharer => &by[1..],
                _ => by.as_slice(),
            };
            let input_name = format!("{}After", tuple_name(&t.name, held));
            let full_name = format!("{}After", tuple_name(&t.name, &by));
            for (record_name, selected) in [(&input_name, held), (&full_name, by.as_slice())] {
                let mut columns = params(selected);
                columns.push((mark_name.clone(), mark_ty.clone()));
                range_records.push((record(record_name, &columns, &span), Wrote::Range {
                    fields: selected.to_vec(), mark: mark_name.clone(),
                }));
            }
            let count_name = format!("{full_name}Count");
            range_records.push((record(&count_name, &[
                ("key".into(), DeclaredType::new(full_name, Vec::new())),
                ("count".into(), DeclaredType::new("Int", Vec::new())),
            ], &span), Wrote::RangeCounted { fields: by.clone() }));
            let input = ("values".to_string(), list(DeclaredType::new(input_name, Vec::new())));
            let given = match r {
                Reading::Owner | Reading::Sharer => {
                    let list_name = if crate::wit::ident(&by[0]) == "values" { "values_keys" } else { "values" };
                    vec![(by[0].clone(), handle(&by[0])), (list_name.to_string(), input.1)]
                },
                _ => vec![input],
            };
            push(Planned {
                name: format!("{name}_many"), params: given,
                ret: list(DeclaredType::new(count_name, Vec::new())),
                primitive: Primitive::CountAfterMany, by: by.clone(), span: span.clone(),
            });
        }
'''
text = text.replace(anchor, addition + anchor, 1)
text = text.replace('for (record, what) in counted_records {', 'for (record, what) in counted_records.into_iter().chain(range_records) {', 1)
text = text.replace('Wrote::Tuple { .. } | Wrote::Counted { .. } | Wrote::Seen { .. }', 'Wrote::Tuple { .. } | Wrote::Counted { .. } | Wrote::Range { .. } | Wrote::RangeCounted { .. } | Wrote::Seen { .. }')
anchor = 'fn sorted_by(t: &TableSchema, primitive: Primitive, by: &[String]) -> Vec<String> {\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '    if primitive.range() {\n        return Vec::new();\n    }\n', 1)
path.write_text(text)

path = root / 'compiler/pw-core/src/bounded.rs'
text = path.read_text()
assert 'Primitive::CountAfter' not in text
text = text.replace('                        Primitive::Count => Primitive::CountMany,', '                        Primitive::Count => Primitive::CountMany,\n                        Primitive::CountAfter => Primitive::CountAfterMany,', 1)
anchor = '        let held = by.get(list_at..)?;'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + r'''
        let range_fields;
        let held = if primitive.range() {
            let record = list.args().first()?.written();
            range_fields = hir.all_decls().find(|(_, d)| d.name == record)?
                .1.fields.as_ref()?.iter().map(|f| f.name.clone()).collect::<Vec<_>>();
            range_fields.as_slice()
        } else { held };
''', 1)
anchor = '            format!("scalar values for {fields}")'
assert text.count(anchor) == 1
text = text.replace(anchor, '''            if primitive.range() {
                let record = list.args().first()?.written();
                format!("key records of `{table}.{record}` with fields {fields}")
            } else {
                format!("scalar values for {fields}")
            }''', 1)
path.write_text(text)
print('range scalar/set declarations and generated-key meanings implemented')
