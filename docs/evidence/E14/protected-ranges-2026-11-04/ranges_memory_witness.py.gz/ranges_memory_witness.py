from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
support = root / 'runtime/pw-table-memory/tests/support/ranges.rs'
assert not support.exists()
support.write_text(r'''
fn range_program(predicate: bool) -> Program {
    let notes = std::fs::read_to_string(root().join("examples/owned/Notes.pw")).unwrap()
        .replace("index   by_to on to", "index   by_to on to\n    index   by_author_to on author, to\n    index   by_to_added on to, added");
    let mut app = std::fs::read_to_string(root().join("examples/owned/app.pw")).unwrap();
    if predicate {
        let old = "    match Notes.get(current_user(), id) {\n        Some(_) => true,\n        None => false,\n    }";
        assert!(app.contains(old));
        app = app.replace(old, "    match Notes.get(current_user(), id) {\n        Some(note) => Notes.count_after_by_author(current_user(), note.added) > 0,\n        None => false,\n    }");
    }
    for (name, params, returns, keys, invalidates, body) in [
        ("SinceMine", "reader: User<UserId>, mark: Int", "Int", "reader, mark", "NotesChanged(reader)", "Notes.count_after_by_author(reader, mark)"),
        ("SinceShared", "reader: User<UserId>, mark: Int", "Int", "reader, mark", "NoteSent(reader), NotesForgotten(_)", "Notes.count_after_by_to(reader, mark)"),
        ("RangeMarks", "reader: User<UserId>, ranges: List<NotesAfter>", "List<NotesAuthorAfterCount>", "reader, ranges", "NotesChanged(reader)", "Notes.count_after_by_author_many(reader, ranges)"),
        ("RangeRecipients", "reader: User<UserId>, ranges: List<NotesToAfter>", "List<NotesAuthorToAfterCount>", "reader, ranges", "NotesChanged(reader)", "Notes.count_after_by_author_to_many(reader, ranges)"),
        ("RangeTimes", "reader: User<UserId>, ranges: List<NotesAddedAfter>", "List<NotesToAddedAfterCount>", "reader, ranges", "NoteSent(reader), NotesForgotten(_)", "Notes.count_after_by_to_added_many(reader, ranges)"),
    ] {
        app.push_str(&format!("\nuser query {name}({params}) -> {returns}\n    freshness 0.seconds\n    consistency read_your_writes\n    cache private\n    key {keys}\n    invalidates_on {invalidates}\n    concurrency one_per_key\n    on_key_change cancel\n    timeout 2.seconds\n{{\n    {body}\n}}\n"));
    }
    built(&[("Notes.pw", &notes), ("app.pw", &app)])
}

fn range_rows() -> Vec<serde_json::Value> {
    [(ALICE,"n1",BOB,1),(ALICE,"n2",BOB,1),(ALICE,"n3",CAROL,5),(CAROL,"n4",BOB,1)]
        .into_iter().map(|(author,id,to,stamp)| note_json(author,id,to,stamp)).collect()
}

fn requested(fields: Vec<(&str, Val)>, mark: i64) -> Val {
    let mut fields = fields.into_iter().map(|(name,value)| (name.to_string(),value)).collect::<Vec<_>>();
    fields.push(("after".into(),Val::S64(mark)));
    Val::Record(fields)
}

fn counted_range(fields: Vec<(&str, Val)>, mark: i64, count: i64) -> Val {
    Val::Record(vec![("key".into(),requested(fields,mark)),("count".into(),Val::S64(count))])
}
''')
path = root / 'runtime/pw-table-memory/tests/compiled_ranges.rs'
assert not path.exists()
path.write_text(r'''//! Real compiled range calls: strict marks, heterogeneous keys and authority.
#![allow(dead_code)]
include!("support/owned.rs");
include!("support/ranges.rs");

#[test]
fn ranges_count_strict_order_marks_and_keep_full_heterogeneous_request_identity() {
    let program = range_program(false);
    let tables = MemoryTables::new(program.tables.clone()).assert_ok("memory");
    tables.transaction(|tx| { for row in range_rows() { tx.write("pw:tables/notes#insert", &[row])?; } Ok(()) }).assert_ok("seed");
    for (mark,count) in [(-1,3),(0,3),(1,1),(5,0),(i64::MAX,0)] {
        assert_eq!(query(&program,&tables,"SinceMine",&as_user(ALICE),&[handle(ALICE),Val::S64(mark)]),Ok(vec![Val::S64(count)]));
    }
    assert_eq!(query(&program,&tables,"SinceShared",&as_user(BOB),&[handle(BOB),Val::S64(0)]),Ok(vec![Val::S64(3)]));
    let input = Val::List(vec![requested(vec![],1),requested(vec![],0),requested(vec![],1),requested(vec![],9)]);
    assert_eq!(query(&program,&tables,"RangeMarks",&as_user(ALICE),&[handle(ALICE),input]),Ok(vec![Val::List(vec![
        counted_range(vec![("author",handle(ALICE))],0,3),
        counted_range(vec![("author",handle(ALICE))],1,1),
        counted_range(vec![("author",handle(ALICE))],9,0),
    ])]));
    let input = Val::List(vec![requested(vec![("to",handle(CAROL))],1),requested(vec![("to",handle(BOB))],1),requested(vec![("to",handle(BOB))],0),requested(vec![("to",handle("u-nobody"))],0)]);
    assert_eq!(query(&program,&tables,"RangeRecipients",&as_user(ALICE),&[handle(ALICE),input]),Ok(vec![Val::List(vec![
        counted_range(vec![("author",handle(ALICE)),("to",handle(BOB))],0,2),
        counted_range(vec![("author",handle(ALICE)),("to",handle(BOB))],1,0),
        counted_range(vec![("author",handle(ALICE)),("to",handle(CAROL))],1,1),
        counted_range(vec![("author",handle(ALICE)),("to",handle("u-nobody"))],0,0),
    ])]));
    let input = Val::List(vec![requested(vec![("added",Val::S64(1))],1),requested(vec![("added",Val::S64(1))],0),requested(vec![("added",Val::S64(9))],0)]);
    assert_eq!(query(&program,&tables,"RangeTimes",&as_user(BOB),&[handle(BOB),input]),Ok(vec![Val::List(vec![
        counted_range(vec![("to",handle(BOB)),("added",Val::S64(1))],0,3),
        counted_range(vec![("to",handle(BOB)),("added",Val::S64(1))],1,0),
        counted_range(vec![("to",handle(BOB)),("added",Val::S64(9))],0,0),
    ])]));
    let reads = Arc::new(AtomicUsize::new(0));
    for caller in [Caller::Nobody, as_user(BOB)] {
        let answer = query_counted(&program,&tables,"RangeMarks",&caller,&[handle(ALICE),Val::List(vec![requested(vec![],0)])],&reads);
        assert!(answer.is_err());
        assert_eq!(reads.load(Ordering::SeqCst),0,"forged/no caller reaches no range adapter");
    }
    tables.transaction(|tx| tx.write("pw:tables/notes#delete", &[json!(ALICE),json!("n1")])).assert_ok("delete before mark");
    assert_eq!(query(&program,&tables,"SinceMine",&as_user(ALICE),&[handle(ALICE),Val::S64(1)]),Ok(vec![Val::S64(1)]));
    tables.transaction(|tx| tx.write("pw:tables/notes#delete", &[json!(ALICE),json!("n3")])).assert_ok("delete after mark");
    assert_eq!(query(&program,&tables,"SinceMine",&as_user(ALICE),&[handle(ALICE),Val::S64(1)]),Ok(vec![Val::S64(0)]));
}

#[test]
fn range_predicates_read_staged_rows_and_the_pinned_query_keeps_predicate_and_body() {
    let program = range_program(true);
    let tables = MemoryTables::new(program.tables.clone()).assert_ok("memory");
    tables.transaction(|tx| { for row in range_rows() { tx.write("pw:tables/notes#insert", &[row])?; } Ok(()) }).assert_ok("seed");
    let s = |v:&str| Val::String(v.into());
    let mut command = tables.begin().assert_ok("command");
    let watched = Watched::new(&command);
    let denied = authorized(&program,"edit",ALICE,&watched,&pw_host::Limits::unbounded(),&[s("n3"),s(CAROL),s("WRONG")],false,&AtomicUsize::new(0));
    assert!(denied.as_ref().is_err_and(|why|why.contains("Wrote")),"no newer row: {denied:?}");
    assert_eq!(watched.body.load(Ordering::SeqCst),0);
    command.write("pw:tables/notes#insert",&[note_json(ALICE,"n5",BOB,9)]).assert_ok("stage after mark");
    assert_eq!(authorized(&program,"edit",ALICE,&command,&pw_host::Limits::unbounded(),&[s("n3"),s(CAROL),s("EDITED")],false,&AtomicUsize::new(0)),Ok(vec![]));
    command.commit().assert_ok("commit");
    let snapshot = tables.snapshot().assert_ok("snapshot");
    let args = [handle(ALICE),s("n3")];
    let held = authorized(&program,"Shown",ALICE,&snapshot,&pw_host::Limits::unbounded(),&args,false,&AtomicUsize::new(0)).assert_ok("pin range predicate/body");
    assert!(matches!(held.as_slice(),[Val::Option(Some(_))]));
    tables.transaction(|tx| {
        let mut changed = note_json(ALICE,"n3",CAROL,5); changed["text"]=json!("CHANGED AFTER PIN");
        tx.write("pw:tables/notes#put",&[changed])?;
        tx.write("pw:tables/notes#delete",&[json!(ALICE),json!("n5")])
    }).assert_ok("remove newer row and change body");
    assert_eq!(tables.read("pw:tables/notes#get",&[json!(ALICE),json!("n3")]).assert_ok("live body")["text"],"CHANGED AFTER PIN");
    assert_eq!(authorized(&program,"Shown",ALICE,&snapshot,&pw_host::Limits::unbounded(),&args,false,&AtomicUsize::new(0)),Ok(held));
    let fresh=tables.snapshot().assert_ok("fresh");
    let denied=authorized(&program,"Shown",ALICE,&fresh,&pw_host::Limits::unbounded(),&args,false,&AtomicUsize::new(0));
    assert!(denied.as_ref().is_err_and(|why|why.contains("Wrote")),"fresh range predicate sees deletion: {denied:?}");
}
''')
print('compiled memory range authority, heterogeneous marks, deletion and snapshot witnesses added')
