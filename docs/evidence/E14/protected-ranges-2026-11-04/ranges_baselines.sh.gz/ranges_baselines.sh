#!/bin/bash
set -uo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
cargo test --locked -p pw-core --lib --test tables --test table_counts --test table_windows --test table_ranges --test table_owners --test bounded_reads --test bounded_tables --test head_only > /tmp/pw-protected-migration/ranges-baseline-core.log 2>&1
printf 'core exit: %s\n' "$?"
cargo test --locked -p pw-host --features engine > /tmp/pw-protected-migration/ranges-baseline-host.log 2>&1
printf 'host exit: %s\n' "$?"
cargo test --locked -p pw-table-memory > /tmp/pw-protected-migration/ranges-baseline-memory.log 2>&1
printf 'memory exit: %s\n' "$?"
cargo test --locked -p pw-table-postgres > /tmp/pw-protected-migration/ranges-baseline-pg.log 2>&1
printf 'PostgreSQL exit: %s\n' "$?"
cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::conformance:: tests::tables_pg::the_suite_holds > /tmp/pw-protected-migration/ranges-baseline-conformance.log 2>&1
printf 'conformance exit: %s\n' "$?"
