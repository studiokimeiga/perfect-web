from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'spikes/own-renderer/server/src/tests/conformance.rs'
text = path.read_text()
assert 'fn range_oracle' not in text
text = text.replace('    pub key: Vec<String>,\n', '    pub key: Vec<String>,\n    pub order: Option<String>,\n', 1)
text = text.replace('            key: strings(&t["key"]),', '            key: strings(&t["key"]),\n            order: t["order"].as_str().map(str::to_string),', 1)
text = text.replace('        key: vec!["group".into(), "id".into()],', '        key: vec!["group".into(), "id".into()],\n        order: None,', 1)
anchor = '    fn window(&self) -> bool {'
assert text.count(anchor) == 1
text = text.replace(anchor, '''    fn range(&self) -> bool {
        matches!(self.primitive.as_str(), "count-after" | "count-after-many")
    }
''' + anchor, 1)
anchor = '/// Ordered windows from generated rows'
assert text.count(anchor) == 1
addition = r'''/// Independently choose the mark field by emitted identity; no adapter helper.
fn range_mark(table: &Table) -> String {
    let mut mark = "after".to_string();
    while table.fields.iter().any(|(field,_)|pw_host::tables::wit_name(field)==pw_host::tables::wit_name(&mark)) {
        mark.push_str("_mark");
    }
    mark
}

fn range_key(table: &Table, function: &Function, request: &[Json]) -> Val {
    let order = table.order.as_ref().expect("range has declared order");
    let mut fields = function.by.iter().zip(request).map(|(field,value)|
        (pw_host::tables::wit_name(field),wit(table.stored(field),value))).collect::<Vec<_>>();
    fields.push((pw_host::tables::wit_name(&range_mark(table)),wit(table.stored(order),request.last().expect("mark"))));
    Val::Record(fields)
}

fn range_arguments(table: &Table, function: &Function, requests: &[Vec<Json>]) -> Vec<Val> {
    if function.many() {
        vec![Val::List(requests.iter().map(|request|range_key(table,function,request)).collect())]
    } else {
        let mut args=function.by.iter().zip(&requests[0]).map(|(field,value)|wit(table.stored(field),value)).collect::<Vec<_>>();
        args.push(wit(table.stored(table.order.as_ref().expect("order")),requests[0].last().expect("mark")));
        args
    }
}

/// Counts directly from generated rows, equality fields and the declared order;
/// no production selection/count codec or adapter supplies this answer.
fn range_oracle(table: &Table, function: &Function, rows: &[Map<String,Json>], requests: &[Vec<Json>]) -> Vec<Val> {
    let order=table.order.as_ref().expect("range has order");
    let count = |request:&Vec<Json>| rows.iter().filter(|row| {
        function.by.iter().zip(request).all(|(field,value)|row[field]==*value)
            && compare(&row[order],request.last().expect("mark")).is_gt()
    }).count() as i64;
    if !function.many() { return vec![Val::S64(count(&requests[0]))]; }
    let mut keys=requests.to_vec();
    keys.sort_by(|a,b|a.iter().zip(b).map(|(a,b)|compare(a,b)).find(|o|o.is_ne()).unwrap_or(std::cmp::Ordering::Equal));
    keys.dedup();
    vec![Val::List(keys.iter().map(|request|Val::Record(vec![
        ("key".into(),range_key(table,function,request)),("count".into(),Val::S64(count(request))),
    ])).collect())]
}

#[test]
fn the_range_oracle_keeps_marks_ties_missing_zeros_and_canonical_pair_order() {
    let integer=serde_json::json!({"int":{"at_least":null,"at_most":null}});
    let table=Table { name:"Ranges".into(),fields:vec![("group".into(),integer.clone()),("id".into(),integer.clone()),("stamp".into(),integer)],
        key:vec!["group".into(),"id".into()],order:Some("stamp".into()),indexes:vec![],references:vec![],bounded:None,source:"RangeData".into(),functions:vec![] };
    let rows=[(1,1,1),(1,2,1),(1,3,3),(2,4,2)].into_iter().map(|(group,id,stamp)|[
        ("group".into(),Json::from(group)),("id".into(),Json::from(id)),("stamp".into(),Json::from(stamp))
    ].into_iter().collect()).collect::<Vec<_>>();
    let mut function=Function { import:String::new(),primitive:"count-after".into(),by:vec!["group".into()],sorted_by:vec![] };
    assert_eq!(range_oracle(&table,&function,&rows,&[vec![Json::from(1),Json::from(1)]]),vec![Val::S64(1)]);
    function.primitive="count-after-many".into();
    let entry=|group,mark,count|Val::Record(vec![("key".into(),Val::Record(vec![("group".into(),Val::S64(group)),("after".into(),Val::S64(mark))])),("count".into(),Val::S64(count))]);
    assert_eq!(range_oracle(&table,&function,&rows,&[vec![Json::from(1),Json::from(1)],vec![Json::from(9),Json::from(0)],vec![Json::from(1),Json::from(0)],vec![Json::from(1),Json::from(1)]]),vec![Val::List(vec![entry(1,0,3),entry(1,1,1),entry(9,0,0)])]);
    assert_eq!(range_oracle(&table,&function,&rows,&[]),vec![Val::List(vec![])]);
}

'''
text = text.replace(anchor, addition + anchor, 1)
anchor = '            for selectors in cases {'
assert text.count(anchor) == 1
addition = r'''            if function.range() {
                let order=table.order.as_ref().expect("range order");
                let marks = vec![all[0][order].clone(),all.last().expect("rows")[order].clone(),value(table.stored(order),0),value(table.stored(order),10_000+n)];
                let requests=present.iter().chain(std::iter::once(&missing)).flat_map(|selector|marks.iter().map(|mark|{
                    let mut request=selector.clone(); request.push(mark.clone()); request
                }).collect::<Vec<_>>()).collect::<Vec<_>>();
                let cases=if function.many() {
                    let mut duplicated=requests.clone(); duplicated.push(requests[0].clone()); duplicated.reverse();
                    vec![requests,duplicated,vec![]]
                } else { requests.into_iter().map(|request|vec![request]).collect() };
                for requests in cases {
                    let args=range_arguments(table,function,&requests);
                    let before=statements(s);
                    let answer=call(&ops,&function.import,&args);
                    let made=statements(s)-before;
                    let most=match sets.get(&table.source).map(String::as_str) { Some("one_call")=>1,_=>requests.len().max(1) as u64 };
                    let least=u64::from(!(function.many() && requests.is_empty()));
                    assert!((least..=most).contains(&made),"{} range statements {made}, {way}, source bound {most}",function.import);
                    assert_eq!(answer,range_oracle(table,function,all,&requests),"{} ranges {requests:?}, {way}, {n} rows",function.import);
                    checked+=1;
                }
                continue;
            }
'''
text = text.replace(anchor, addition + anchor, 1)
path.write_text(text)
print('independent range oracle and generated scalar/set cases added without changing row/count/window oracles')
