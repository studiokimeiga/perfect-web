from pathlib import Path
import re
import shutil

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'compiler/pw-core/tests/table_ranges.rs'
text = path.read_text()
text, count = re.subn(r'\.fields\n(\s*)\.iter\(\)\n', lambda m: '.fields\n' + m[1] + '.iter()\n' + m[1] + '.flatten()\n', text)
assert count == 2
old = 'format!("{}{}", field[..1].to_uppercase(), &field[1..])'
assert text.count(old) == 1
text = text.replace(old, 'field.split(\'_\').map(|part| format!("{}{}", part[..1].to_uppercase(), &part[1..])).collect::<String>()')
path.write_text(text)
shutil.copy2('/tmp/pw-protected-migration/ranges-compiler-red.log', '/tmp/pw-protected-migration/ranges-compiler-fixture-invalid.log')
