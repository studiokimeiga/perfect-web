from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
memory = (root / 'runtime/pw-table-memory/tests/compiled_ranges.rs').read_text()
window = (root / 'runtime/pw-table-postgres/tests/compiled_windows.rs').read_text()
query_helpers = window[window.index('fn q('):window.index('#[test]')]
text = memory.replace('//! Real compiled range calls: strict marks, heterogeneous keys and authority.', '//! Real PostgreSQL range calls through the compiled owner/sharer boundary.')
text = text.replace('include!("support/owned.rs");', 'include!("../../pw-table-memory/tests/support/owned.rs");')
text = text.replace('include!("support/ranges.rs");', 'include!("../../pw-table-memory/tests/support/ranges.rs");\nmod common;\nuse pw_table_postgres::PgTables;\nuse pw_host::engine::CallTables;\n\n' + query_helpers)
old = '    let tables = MemoryTables::new(program.tables.clone()).assert_ok("memory");'
assert text.count(old) == 2
new = '''    let Some(url) = common::database() else { return; };
    let scratch = common::Scratch::new(&url,"compiled_ranges");
    let tables = PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");'''
text = text.replace(old, new)
text = text.replace('query_counted(', 'q_counted(').replace('query(', 'q(')
path = root / 'runtime/pw-table-postgres/tests/compiled_ranges.rs'
assert not path.exists()
path.write_text(text)
print('same compiled heterogeneous/deletion/staging/snapshot fixtures registered for PostgreSQL')
