from pathlib import Path
import re

logs = Path('/tmp/pw-protected-migration')
for name in ['core', 'cli', 'host', 'memory', 'pg', 'server']:
    path = logs / f'ranges-frozen-{name}.log'
    text = path.read_text()
    results = [tuple(map(int, match)) for match in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
    print(name, tuple(sum(row[i] for row in results) for i in range(3)), 'binaries', len(results))
for name in ['pg-controls', 'row-controls', 'data-controls']:
    path = logs / f'ranges-frozen-{name}.log'
    if path.exists():
        print(name, '\n'.join(path.read_text().splitlines()[-14:]))
