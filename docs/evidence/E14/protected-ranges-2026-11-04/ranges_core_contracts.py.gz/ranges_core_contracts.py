from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'compiler/pw-core/src/tables.rs'
text = path.read_text()
rows = [
    ('owner','Owner','owner: Owner'),
    ('owner_store','OwnerStore','owner: Owner, store: StoreId'),
    ('owner_store_item','OwnerStoreItem','owner: Owner, store: StoreId, item: ItemId'),
    ('store','Store','store: StoreId'),
    ('owner_item','OwnerItem','owner: Owner, item: ItemId'),
]
anchor = '            fn get(owner: Owner, store: StoreId, item: ItemId)'
assert text.count(anchor) == 1
records = ''.join(f'            type CartLines{pascal}After = CartLines{pascal}After {{ {params}, after: Int }}\\n\\\n            type CartLines{pascal}AfterCount = CartLines{pascal}AfterCount {{ key: CartLines{pascal}After, count: Int }}\\n\\\n' for _,pascal,params in rows)
text = text.replace(anchor, records + anchor, 1)
for fields,pascal,params in rows:
    anchor = f'            fn count_by_{fields}('
    assert text.count(anchor) == 1
    new = f'            fn count_after_by_{fields}({params}, after: Int) -> Int !{{ database.read<CartLines> }}\\n    host \\"pw:tables/cart-lines#count-after-by-{fields.replace("_","-")}\\"\\n\\\n'
    new += f'            fn count_after_by_{fields}_many(values: List<CartLines{pascal}After>) -> List<CartLines{pascal}AfterCount> !{{ database.read<CartLines> }}\\n    host \\"pw:tables/cart-lines#count-after-by-{fields.replace("_","-")}-many\\"\\n\\\n'
    # One literal quote escape, as the existing handwritten source uses.
    new = new.replace('\\\\"', '\\"')
    text = text.replace(anchor, new + anchor, 1)
path.write_text(text)

path = root / 'compiler/pw-core/tests/table_owners.rs'
text = path.read_text()
anchor = '        (\n            "NoteSeen".into(),'
assert text.count(anchor) == 1
records = [
    ('NotesAfter','after'),('NotesAuthorAfter','author, after'),('NotesAuthorAfterCount','key, count'),
    ('NotesIdAfter','id, after'),('NotesAuthorIdAfter','author, id, after'),('NotesAuthorIdAfterCount','key, count'),
    ('NotesToAfter','to, after'),('NotesToAfterCount','key, count'),
]
new = ''.join(f'        ("{name}".into(), "{fields}".into(), &none, ""),\n' for name,fields in records)
text = text.replace(anchor, new + anchor, 1)
for fields,params,input_name,result,reader in [
    ('author','{handle}, Int','NotesAfter','NotesAuthorAfterCount','author'),
    ('author_id','{handle}, NoteId, Int','NotesIdAfter','NotesAuthorIdAfterCount','author'),
    ('to','{handle}, Int','NotesAfter','NotesToAfterCount','to'),
]:
    anchor = f'        (\n            "count_by_{fields}".into(),'
    assert text.count(anchor) == 1
    imported = fields.replace('_','-')
    new = f'''        (
            "count_after_by_{fields}".into(),
            format!("({params}) -> Int"),
            &read,
            "\\\"pw:tables/notes#count-after-by-{imported}\\\"",
        ),
        (
            "count_after_by_{fields}_many".into(),
            format!("({{handle}}, List<{input_name}>) -> List<{result}>"),
            &read,
            "\\\"pw:tables/notes#count-after-by-{imported}-many\\\"",
        ),
'''
    text = text.replace(anchor, new + anchor, 1)
    anchor = f'            ("count_by_{fields}", Some("{reader}")),'
    assert text.count(anchor) == 1
    text = text.replace(anchor, f'            ("count_after_by_{fields}", Some("{reader}")),\n            ("count_after_by_{fields}_many", Some("{reader}")),\n' + anchor, 1)
path.write_text(text)

path = root / 'compiler/pw-core/tests/tables.rs'
text = path.read_text()
anchor = '        (\n            "get",'
assert text.count(anchor) == 1
records = ''.join(f'        ("Todos{name}After", "{fields}, after", &none, ""),\n        ("Todos{name}AfterCount", "key, count", &none, ""),\n' for name,fields in [('List','list'),('ListId','list, id'),('Done','done')])
text = text.replace(anchor, records + anchor, 1)
for fields,pascal,params in [('list','List','ListId'),('list_id','ListId','ListId, TodoId'),('done','Done','Bool')]:
    anchor = f'        (\n            "count_by_{fields}",'
    assert text.count(anchor) == 1
    imported = fields.replace('_','-')
    new = f'''        (
            "count_after_by_{fields}",
            "({params}, Int) -> Int",
            &read,
            "\\\"pw:tables/todos#count-after-by-{imported}\\\"",
        ),
        (
            "count_after_by_{fields}_many",
            "(List<Todos{pascal}After>) -> List<Todos{pascal}AfterCount>",
            &read,
            "\\\"pw:tables/todos#count-after-by-{imported}-many\\\"",
        ),
'''
    text = text.replace(anchor, new + anchor, 1)
path.write_text(text)
print('explicit ordinary/owned API expectations and handwritten lowering fixture expanded')
