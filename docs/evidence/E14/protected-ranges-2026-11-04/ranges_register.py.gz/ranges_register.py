from pathlib import Path

root=Path('/home/haki/code/pw-wt/data-path')
path=root/'runtime/pw-table-memory/tests/support/ranges.rs'
text=path.read_text()
old="fn order_cases() -> Vec<(&'static str,Vec<serde_json::Value>,Vec<(serde_json::Value,i64)>,Val)> {"
assert text.count(old)==1
text=text.replace(old,"type OrderCase = (&'static str,Vec<serde_json::Value>,Vec<(serde_json::Value,i64)>,Val);\n\nfn order_cases() -> Vec<OrderCase> {",1)
path.write_text(text)
path=root/'spikes/own-renderer/server/src/tests/conformance.rs'
text=path.read_text()
old='                let marks = vec!['
assert text.count(old)==1
path.write_text(text.replace(old,'                let marks = [',1))

path=root/'scripts/d3_postgres_mutations.py'
text=path.read_text()
assert '"--test", "compiled_ranges"' not in text
text=text.replace('TESTS = [\n','TESTS = [\n    ["cargo", "test", "--quiet", "--locked", "-p", "pw-table-postgres", "--test", "compiled_ranges"],\n',1)
path.write_text(text)
path=root/'scripts/row_ownership_mutations.py'
text=path.read_text()
assert '"--test", "table_ranges"' not in text
text=text.replace('TESTS = [\n','TESTS = [\n    ["cargo", "test", "--quiet", "--locked", "-p", "pw-core", "--test", "table_ranges"],\n    ["cargo", "test", "--quiet", "--locked", "-p", "pw-table-memory", "--test", "compiled_ranges"],\n',1)
text=text.replace('SOURCES = [\n','SOURCES = [\n    ROOT / "compiler/pw-core/tests/table_ranges.rs",\n    ROOT / "runtime/pw-table-memory/tests/compiled_ranges.rs",\n    ROOT / "runtime/pw-table-memory/tests/support/ranges.rs",\n',1)
path.write_text(text)
path=root/'scripts/data_path_mutations.py'
text=path.read_text()
assert '"--test", "compiled_ranges"' not in text
text=text.replace('TESTS = [\n','TESTS = [\n    (["cargo", "test", "--quiet", "--locked", "-p", "pw-table-memory", "--test", "compiled_ranges"], []),\n',1)
text=text.replace('SOURCES = [\n','SOURCES = [\n    ROOT / "runtime/pw-table-memory/tests/compiled_ranges.rs",\n    ROOT / "runtime/pw-table-memory/tests/support/ranges.rs",\n',1)
path.write_text(text)
path=root/'just/d3-postgres.just'
text=path.read_text()
old='counts compiled_counts compiled_windows; do'
assert text.count(old)==1
path.write_text(text.replace(old,'counts compiled_counts compiled_windows compiled_ranges; do',1))
path=root/'just/row-ownership.just'
text=path.read_text()
text=text.replace('--test table_windows;', '--test table_windows --test table_ranges;',1)
text=text.replace('--test compiled_counts --test compiled_windows;', '--test compiled_counts --test compiled_windows --test compiled_ranges;',1)
path.write_text(text)
path=root/'just/data-path.just'
text=path.read_text()
old='--test compiled_guarded --test compiled_snapshot;'
assert text.count(old)==1
path.write_text(text.replace(old,'--test compiled_guarded --test compiled_snapshot --test compiled_ranges;',1))
print('range binaries/source assertions and affected recipes registered; initial clippy findings fixed')
