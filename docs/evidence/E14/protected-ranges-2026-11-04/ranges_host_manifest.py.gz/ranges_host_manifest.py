from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'runtime/pw-host/src/tables.rs'
text = path.read_text()
assert 'CountAfter' not in text
text = text.replace('    CountMany,\n', '    CountMany,\n    CountAfter,\n    CountAfterMany,\n', 1)
text = text.replace('                | Primitive::CountMany\n', '                | Primitive::CountMany\n                | Primitive::CountAfterMany\n', 1)
text = text.replace('            Primitive::CountMany => "count-many",', '            Primitive::CountMany => "count-many",\n            Primitive::CountAfter => "count-after",\n            Primitive::CountAfterMany => "count-after-many",', 1)
text = text.replace('matches!(self, Primitive::Count | Primitive::CountMany)', 'matches!(self, Primitive::Count | Primitive::CountMany | Primitive::CountAfter | Primitive::CountAfterMany)', 1)
anchor = '    pub fn window(self) -> bool {'
assert text.count(anchor) == 1
text = text.replace(anchor, '''    pub fn range(self) -> bool {
        matches!(self, Primitive::CountAfter | Primitive::CountAfterMany)
    }

''' + anchor, 1)
text = text.replace('            | Primitive::CountMany\n            | Primitive::First', '            | Primitive::CountMany\n            | Primitive::CountAfter\n            | Primitive::CountAfterMany\n            | Primitive::First', 1)
anchor = 'impl Read {\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + r'''    /// The mark's value type is the declared order's; its name is not a stored
    /// selector and is distinct from every emitted row field identity.
    pub fn mark_column(&self) -> Result<Column, String> {
        let order = self.order.as_ref().ok_or("a range count requires a declared order")?;
        let column = self.row.iter().find(|c| c.name == *order)
            .ok_or("a range count's order is not a row field")?;
        let mut name = "after".to_string();
        while self.row.iter().any(|c| c.wit == wit_name(&name)) {
            name.push_str("_mark");
        }
        Ok(Column::new(&name, column.stored.clone()))
    }

    /// Full count request identity: equality fields, then the typed mark.
    pub fn count_columns(&self) -> Result<Vec<Column>, String> {
        let mut columns = self.by.clone();
        if self.primitive.range() { columns.push(self.mark_column()?); }
        Ok(columns)
    }

''', 1)
# Column::new already owns the single runtime name projection. Derive through it.
text = text.replace('c.wit == wit_name(&name)', 'c.wit == Column::new(&name, column.stored.clone()).wit')
anchor = '            Primitive::Count | Primitive::CountMany => {'
assert text.count(anchor) == 1
text = text.replace(anchor, r'''            Primitive::CountAfter | Primitive::CountAfterMany => {
                if self.order.is_none() { return Err(format!("range counts of {name} require a declared order")); }
                let prefix = !by.is_empty() && by.len() <= self.key.len() && self.key[..by.len()] == *by;
                if !prefix && !self.indexes.iter().any(|index| index.fields == by) {
                    return Err(format!("range counts by no declared key, prefix or index of {name}"));
                }
                let suffix = if primitive.many() { "_many" } else { "" };
                Ok(format!("count_after_by_{}{suffix}", by.join("_")))
            }
''' + anchor, 1)
anchor = '    fn sorted_by(&self, primitive: Primitive, by: &[String]) -> Vec<String> {\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '        if primitive.range() { return Vec::new(); }\n', 1)
path.write_text(text)
print('range manifest identities and typed request columns added')
