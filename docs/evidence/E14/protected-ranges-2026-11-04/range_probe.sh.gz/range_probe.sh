#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
psql -X -v ON_ERROR_STOP=1 --tuples-only --no-align "${PW_STORE_DATABASE_URL:?throwaway database required}" -f /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration/range_probe.sql > /tmp/pw-protected-migration/range-primary-probe.log
cat /tmp/pw-protected-migration/range-primary-probe.log
