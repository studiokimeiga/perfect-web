from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'runtime/pw-table-postgres/tests/compiled_ranges.rs'
text = path.read_text()
assert 'fn range_counts_bound_real_sql_results' not in text
text += r'''

#[test]
fn malformed_range_requests_validate_whole_before_sql_and_empty_sets_execute_none() {
    let Some(url)=common::database() else { return; };
    let scratch=common::Scratch::new(&url,"range_inputs");
    let program=range_program(false);
    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");
    for (name,args) in [
        ("count-after-by-author",vec![]),
        ("count-after-by-author",vec![json!(ALICE)]),
        ("count-after-by-author",vec![json!(ALICE),json!(0),json!(0)]),
        ("count-after-by-author",vec![json!(7),json!(0)]),
        ("count-after-by-author",vec![json!(ALICE),json!(true)]),
        ("count-after-by-author",vec![json!(ALICE),json!(u64::MAX)]),
        ("count-after-by-author-many",vec![json!([{"author":"u-missing","after":0},{"author":ALICE,"after":true}])]),
        ("count-after-by-author-many",vec![json!([{"author":ALICE}])]),
        ("count-after-by-author-many",vec![json!([{"author":ALICE,"after":0,"extra":true}])]),
        ("count-after-by-author-many",vec![json!([ALICE])]),
    ] {
        let before=(tables.operation_statements(),tables.returned_rows(),tables.returned_bytes());
        let answer=tables.read(&format!("pw:tables/notes#{name}"),&args);
        assert!(answer.is_err(),"bad range {name}: {answer:?}");
        assert_eq!((tables.operation_statements(),tables.returned_rows(),tables.returned_bytes()),before,"malformed range issues no SQL");
    }
    let before=(tables.operation_statements(),tables.returned_rows(),tables.returned_bytes());
    assert_eq!(tables.read("pw:tables/notes#count-after-by-author-many",&[json!([])]).assert_ok("empty ranges"),json!([]));
    assert_eq!((tables.operation_statements(),tables.returned_rows(),tables.returned_bytes()),before);
    assert_eq!(tables.read("pw:tables/notes#count-after-by-author",&[json!(ALICE),json!(0)]).assert_ok("valid absent scalar"),json!(0));
    assert_eq!(tables.operation_statements()-before.0,1);
    assert_eq!(tables.returned_rows()-before.1,1);
    assert_eq!(tables.returned_bytes()-before.2,8);
}

#[test]
fn range_counts_bound_real_sql_results_and_compiled_fuel_at_large_cardinality() {
    let Some(url)=common::database() else { return; };
    let scratch=common::Scratch::new(&url,"range_cost");
    let program=range_program(false);
    let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");
    let fuel=pw_host::Limits { fuel:Some(1000),..pw_host::Limits::unbounded() };
    let set_fuel=pw_host::Limits { fuel:Some(6000),..pw_host::Limits::unbounded() };
    for size in [12,1500] {
        tables.transaction(|tx| {
            tx.write("pw:tables/notes#delete-of-author",&[json!(ALICE)])?;
            for index in 0..size {
                let mut row=note_json(ALICE,&format!("n{index}"),BOB,index%3);
                row["text"]=json!("P".repeat(280)); row["draft"]=json!("S".repeat(280));
                tx.write("pw:tables/notes#insert",&[row])?;
            }
            Ok(())
        }).assert_ok("seed large range");
        let before=(tables.operation_statements(),tables.returned_rows(),tables.returned_bytes());
        assert_eq!(q_limited(&program,&tables,"SinceMine",&as_user(ALICE),&[handle(ALICE),Val::S64(1)],&Arc::default(),&fuel).assert_ok("compiled scalar range"),vec![Val::S64(size/3)]);
        assert_eq!(tables.operation_statements()-before.0,1);
        assert_eq!(tables.returned_rows()-before.1,1);
        assert_eq!(tables.returned_bytes()-before.2,8);
        let requests=Val::List(vec![requested(vec![("to",handle(BOB))],1),requested(vec![("to",handle(CAROL))],0),requested(vec![("to",handle(BOB))],0),requested(vec![("to",handle(BOB))],1)]);
        let before=(tables.operation_statements(),tables.returned_rows(),tables.returned_bytes());
        assert_eq!(q_limited(&program,&tables,"RangeRecipients",&as_user(ALICE),&[handle(ALICE),requests],&Arc::default(),&set_fuel).assert_ok("compiled heterogeneous ranges"),vec![Val::List(vec![
            counted_range(vec![("author",handle(ALICE)),("to",handle(BOB))],0,size*2/3),
            counted_range(vec![("author",handle(ALICE)),("to",handle(BOB))],1,size/3),
            counted_range(vec![("author",handle(ALICE)),("to",handle(CAROL))],0,0),
        ])]);
        assert_eq!(tables.operation_statements()-before.0,1);
        assert_eq!(tables.returned_rows()-before.1,3);
        assert_eq!(tables.returned_bytes()-before.2,48,"three slot/count pairs, independent of {size}");
        let before=(tables.returned_rows(),tables.returned_bytes());
        let all=tables.read("pw:tables/notes#of-author",&[json!(ALICE)]).assert_ok("growing unrestricted neighbor");
        assert_eq!(all.as_array().map_or(0,Vec::len),size as usize);
        assert_eq!(tables.returned_rows()-before.0,size as u64);
        assert!(tables.returned_bytes()-before.1>size as u64*560);
    }
    let tiny=pw_host::Limits { fuel:Some(1),..pw_host::Limits::unbounded() };
    let denied=q_limited(&program,&tables,"SinceMine",&as_user(ALICE),&[handle(ALICE),Val::S64(1)],&Arc::default(),&tiny);
    assert!(denied.as_ref().is_err_and(|why|why.contains("fuel")),"metered failing neighbor: {denied:?}");
}
'''
path.write_text(text)
print('range malformed no-SQL and 12/1500 result-row/byte/fuel witnesses added')
