from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'compiler/pw-core/tests/table_ranges.rs'
text = path.read_text()
assert 'fn range_scalar_and_set_imports' not in text
text += r'''

#[test]
fn range_scalar_and_set_imports_cannot_silently_alias() {
    let source="module RangeNames\ntype Entry = Entry { a: Int, id: Int, a_many: Int, stamp: Int }\ntable RangeNames\n    row Entry\n    key a, id\n    order stamp\n    index by_other on a_many\nsource RangeData\n    holds RangeNames\n    transactions serializable\n    reads strong\n    changes none\n    sets one_call\n";
    for source in [source.to_string(),source.replace("key a, id","key a_many, id").replace("on a_many","on a")] {
        let found=diagnostics(&source);
        assert!(found.iter().any(|d|d.code=="PW0361" && d.message.contains("count_after_by_a_many") && d.message.contains("same import")),"{found:#?}");
        let valid=source.replace("a_many","a_total");
        let build=pw_core::build::build(&units(&valid)).unwrap();
        for name in ["count_after_by_a","count_after_by_a_many","count_after_by_a_total","count_after_by_a_total_many"] {
            assert_eq!(build.tables.tables[0].functions.iter().filter(|f|f.name==name).count(),1,"{name}");
        }
    }
}

#[test]
fn the_range_mark_name_avoids_every_existing_row_field() {
    let source=(BASE.to_string()+QUERIES).replace("draft: String }","draft: String, after: String, after_mark: Int }");
    let program=units(&source);
    let build=pw_core::build::build(&program).unwrap();
    let scalar=build.tables.tables[0].functions.iter().find(|f|f.name=="count_after_by_owner").unwrap();
    assert_eq!(scalar.params.last().unwrap().name,"after_mark_mark");
    let hir=&program.iter().find(|u|u.path=="Ranges.pw").unwrap().hir;
    let record=hir.all_decls().find(|(_,d)|d.name=="RangesAfter").unwrap().1;
    assert_eq!(record.fields.as_ref().unwrap()[0].name,"after_mark_mark");
}
'''
path.write_text(text)

path = root / 'runtime/pw-host/src/engine/table_link.rs'
text = path.read_text()
anchor = '    #[test]\n    fn count_answers_are_nonnegative_and_cover_exactly_the_requested_keys() {'
assert text.count(anchor) == 1
addition = r'''    #[test]
    fn range_answers_cover_every_selector_and_mark_in_canonical_order_without_extras() {
        let one=read(items(Primitive::CountAfter,&["list"]));
        assert!(check_answer(&one,&[Val::String("a".into()),Val::S64(0)],&[Val::S64(0)]).is_ok());
        assert!(check_answer(&one,&[Val::String("a".into())],&[Val::S64(0)]).is_err());
        let many=read(items(Primitive::CountAfterMany,&["list"]));
        let key=|list:&str,mark|Val::Record(vec![("list".into(),Val::String(list.into())),("after".into(),Val::S64(mark))]);
        let args=[Val::List(vec![key("a",2),key("b",0),key("a",0),key("a",0)])];
        let correct=vec![counted(key("a",0),3),counted(key("a",2),0),counted(key("b",0),0)];
        assert!(check_answer(&many,&args,&[Val::List(correct.clone())]).is_ok());
        for wrong in [
            vec![counted(key("a",0),3),counted(key("b",0),0)],
            vec![counted(key("a",0),3),counted(key("a",1),0),counted(key("b",0),0)],
            vec![counted(key("a",2),0),counted(key("a",0),3),counted(key("b",0),0)],
            vec![counted(key("a",0),3),counted(key("a",0),3),counted(key("a",2),0),counted(key("b",0),0)],
            vec![counted(Val::Record(vec![("list".into(),Val::String("a".into()))]),3),counted(key("a",2),0),counted(key("b",0),0)],
            vec![counted(key("a",0),-1),counted(key("a",2),0),counted(key("b",0),0)],
        ] {
            assert!(check_answer(&many,&args,&[Val::List(wrong.clone())]).is_err(),"invalid range answer: {wrong:?}");
        }
        assert!(check_answer(&many,&[Val::List(vec![])],&[Val::List(vec![])]).is_ok());
    }

'''
path.write_text(text.replace(anchor,addition+anchor,1))

path = root / 'runtime/pw-table-memory/tests/support/ranges.rs'
text = path.read_text()
anchor = 'fn range_program_kind(predicate: bool, kind: Option<&str>) -> Program {'
assert text.count(anchor) == 1
text = text.replace(anchor, '''fn range_program_owner(owner: &str) -> Program { range_program_config(false,None,Some(owner)) }

fn range_program_kind(predicate: bool, kind: Option<&str>) -> Program { range_program_config(predicate,kind,None) }

fn range_program_config(predicate: bool, kind: Option<&str>, owner: Option<&str>) -> Program {''', 1)
anchor = '    built(&[("Notes.pw", &notes), ("app.pw", &app)])'
assert text.count(anchor) == 1
text = text.replace(anchor, '''    if let Some(owner)=owner {
        notes=notes.replace("author",owner);
        let pascal=owner.split('_').map(|part|format!("{}{}",part[..1].to_uppercase(),&part[1..])).collect::<String>();
        app=app.replace("author",owner).replace("Author",&pascal);
    }
''' + anchor,1)
path.write_text(text)

body = r'''

#[test]
fn a_named_reader_and_its_range_mark_keep_distinct_wit_fields() {
    for owner in ["after","after_mark","values","row"] {
        let program=range_program_owner(owner);
        let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");
        tables.transaction(|tx| {
            let mut row=note_json(ALICE,"n1",BOB,2);
            let row=row.as_object_mut().unwrap();
            let author=row.remove("author").unwrap(); row.insert(owner.into(),author);
            tx.write("pw:tables/notes#insert",&[serde_json::Value::Object(row.clone())])
        }).assert_ok("seed renamed reader field");
        let mark=if owner=="after" {"after_mark"} else {"after"};
        let request=Val::Record(vec![(pw_host::tables::wit_name(mark),Val::S64(1))]);
        let expected=Val::Record(vec![("key".into(),Val::Record(vec![(pw_host::tables::wit_name(owner),handle(ALICE)),(pw_host::tables::wit_name(mark),Val::S64(1))])),("count".into(),Val::S64(1))]);
        assert_eq!(query(&program,&tables,"RangeMarks",&as_user(ALICE),&[handle(ALICE),Val::List(vec![request])]),Ok(vec![Val::List(vec![expected])]),"reader {owner}, mark {mark}");
    }
}
'''
path = root / 'runtime/pw-table-memory/tests/compiled_ranges.rs'
text = path.read_text()
path.write_text(text + body + r'''

#[test]
fn a_forged_range_manifest_without_order_is_refused_and_reader_only_ranges_are_valid() {
    let program=range_program(false);
    let mut manifest=program.tables.clone();
    manifest.tables[0].functions.retain(|f|f.primitive.range());
    let mut broken=manifest.clone(); broken.tables[0].schema.order=None;
    let why=MemoryTables::new(broken).err();
    assert!(why.as_ref().is_some_and(|why|format!("{why:?}").contains("declared order")),"{why:?}");
    let tables=MemoryTables::new(manifest).assert_ok("declared order restored");
    assert_eq!(tables.read("pw:tables/notes#count-after-by-author-many",&[json!([{"author":ALICE,"after":0}])]).assert_ok("reader-only batched mark"),json!([{"key":{"author":ALICE,"after":0},"count":0}]));
}
''')
path = root / 'runtime/pw-table-postgres/tests/compiled_ranges.rs'
text = path.read_text()
pg = body.replace('let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");', '''let Some(url)=common::database() else { return; };
        let scratch=common::Scratch::new(&url,"range_reader_names");
        let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");''').replace('query(', 'q(')
path.write_text(text + pg)
print('range result membership/completeness, manifest order, scalar/set alias and reader/mark WIT edges added')
