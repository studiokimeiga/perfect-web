from pathlib import Path
import gzip
import hashlib
import json
import re
import shutil
import subprocess
import sys

root = Path('/home/haki/code/pw-wt/data-path')
logs = Path('/tmp/pw-protected-migration')
work = Path('/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration')
code = 'f4fc668f9d6783993203fe27e02180a3e377fc0e'
latest = sys.argv[1]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

assert git('rev-parse', 'HEAD') == latest and not git('status', '--porcelain')
assert git('diff', '--name-only', code, latest) == 'scripts/d3_postgres_mutations.py'
stages = {
    'ranges-frozen': (code, ['core', 'cli', 'host', 'memory', 'pg', 'server', 'test-compile', 'preflight', 'pg-controls', 'row-controls', 'data-controls']),
    'ranges-review-frozen': (latest, ['preflight', 'controls']),
}
for prefix, (sha, suites) in stages.items():
    assert (logs / f'{prefix}.exit').read_text().strip() == '0'
    assert (logs / f'{prefix}-source.txt').read_text() == f'{sha}\nsource guard: clean\n'
    for suite in suites:
        content = (logs / f'{prefix}-{suite}.log').read_text()
        assert content.strip() and 'test result: FAILED' not in content
        if 'controls' in suite:
            assert 'SURVIVED' not in content and 'INVALID' not in content and 'ANCHOR NOT' not in content
            assert re.search(r'(\d+) of \1 mutants killed', content)

totals = {}
for suite, expected in [('core', 336), ('cli', 5), ('host', 117), ('memory', 124), ('pg', 89), ('server', 175)]:
    text = (logs / f'ranges-frozen-{suite}.log').read_text()
    results = [tuple(map(int, m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
    totals[suite] = dict(zip(['passed', 'failed', 'ignored'], [sum(row[i] for row in results) for i in range(3)]))
    assert totals[suite]['passed'] == expected and totals[suite]['failed'] == 0
assert totals['host']['ignored'] == 9
for name, count, baseline in [('pg', 10, 89), ('row', 11, 209), ('data', 4, 74)]:
    content = (logs / f'ranges-frozen-{name}-controls.log').read_text()
    assert f'{count} of {count} mutants killed' in content
    assert f'baseline: {baseline} passed, 0 failed' in content
assert 'baseline: 89 passed, 0 failed' in (logs / 'ranges-review-frozen-controls.log').read_text()
assert '1 of 1 mutants killed' in (logs / 'ranges-review-frozen-controls.log').read_text()
assert (logs / 'ranges-review-native-source.txt').read_text() == f'{latest}\nsource guard: clean\n'
assert 'test result: ok. 1 passed; 0 failed;' in (logs / 'ranges-review-native-baseline.log').read_text()
assert 'test result: FAILED. 0 passed; 1 failed;' in (logs / 'ranges-review-native-mutant.log').read_text()

base = root / 'docs/evidence/E14/protected-ranges-2026-11-04'
base.mkdir()
for path in sorted(logs.glob('range*.log')):
    content = path.read_text()
    assert not re.search(r'postgres(?:ql)?://', content), path
    shutil.copy2(path, base / path.name)
for prefix in stages:
    shutil.copy2(logs / f'{prefix}-source.txt', base)
shutil.copy2(logs / 'ranges-review-native-source.txt', base)
for path in sorted(work.glob('ranges_*.py')) + sorted(work.glob('ranges_*.sh')) + [work / 'range_probe.sh', work / 'range_probe.sql']:
    data = path.read_bytes()
    archived = base / (path.name + '.gz')
    assert not archived.exists(), path
    archived.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(archived.read_bytes()) == data
(base / 'native-summary.json').write_text(json.dumps({'code': code, 'control_only_successor': latest, 'native': totals, 'controls': {'pg': [89, 10], 'row': [209, 11], 'data': [74, 4], 'wrong_field': [89, 1]}}, indent=2) + '\n')
(base / 'reproduce.sh').write_text('''#!/bin/bash
set -euo pipefail
# COPY THIS DIRECTORY OUTSIDE THE REPOSITORY BEFORE CHECKING OUT OLDER SOURCE.
# Use an isolated checkout and preserve all existing dirty worktrees.
# These runners retain original local repo/setup paths. Use that environment
# or adjust only those local paths. Require an actual throwaway PostgreSQL URL.
records="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
case "$records" in
 /home/haki/code/pw-wt/data-path/*) echo 'copy evidence outside checkout first' >&2; exit 1;;
esac
for name in ranges_frozen.sh ranges_review_frozen.sh; do
 gzip -dc "$records/$name.gz" > "$records/$name"
done
cd /home/haki/code/pw-wt/data-path
test -z "$(git status --porcelain)"
git checkout f4fc668f9d6783993203fe27e02180a3e377fc0e
bash "$records/ranges_frozen.sh"
git checkout LATEST
bash "$records/ranges_review_frozen.sh" LATEST
# All other range*.log files are earlier working diagnostics, including
# native reds, invalid fixtures and old-baseline failures. They are retained
# without being relabeled as frozen acceptance. Their one-shot input writers
# are archived byte-for-byte as gzip; do not run them over the final source.
'''.replace('LATEST', latest))
files = sorted(path for path in base.iterdir() if path.is_file())
(base / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n' for path in files))

record = '''# Protected feed/store prerequisite: counts after declared order marks

Implementation/test source: `f4fc668f9d6783993203fe27e02180a3e377fc0e`.
Wrong-field-control-only successor: `LATEST`.
The accepted design preceded code at `99e1f5dc`. Independent immutable review
found no production authority/privacy/lifetime/race or range-semantics issue.
Its missing wrong-field proof is now a strict control at the successor; no
compiler/runtime/test bytes changed. **Canonical feed/store still use legacy
Rust data layers.** This prerequisite does not close their migration.

## Behavior

Scalar count_after reads use existing equality selectors and the actual order
field's type, including refinements and compiler nominal identity. Comparison
is strictly order > mark; equal values are excluded even with different PKs.
It is not an order-plus-PK cursor. No declared order means no range read. An
absent initial mark uses ordinary count rather than bypassing a refinement.
Stable IDs/order allocation after deletion remains a separate obligation.

Every set request is a selector-and-mark record, with the verified reader
passed separately. Reader-only mark records are meaningful and supported;
the ordinary CountMany empty-after-reader ban stays. Full pairs are canonical
and distinct, including zero for missing ranges; same selector/different mark
stays two requests, exact duplicates coalesce. The mark name appends _mark
until distinct from every stored field's emitted identity. Generated imports,
formals and record types retain named collision refusal. PW0405 describes the
actual heterogeneous input record including mark and separate reader.

The host checks scalar mark ABI before execution, including an unused branch,
and validates every member before callbacks. Counts have exact complete pair
coverage/order/membership, no duplicates/extras and nonnegative Int values.
Original table grants, owner/sharer authority, staged commands and pinned query
snapshots remain. Full result keys contain plain ids, never authority handles.

Memory counts borrowed matching row references and borrowed order values.
PostgreSQL binds native declared kinds (bytea UTF-8 strings), running one scalar
COUNT or one typed-array/ordinality LEFT JOIN aggregate for the whole set,
counting a non-null PK to retain missing zeros. No dependency or stored-schema
migration was introduced. Native Bool, refined Int, Unicode/NUL/prefix String
and values beyond JavaScript's exact integer range cover comparison/ABI.

At 12 and 1,500 fixture rows, compiled scalar counts return 1 SQL row/8 payload
bytes under 1,000 fuel; the three-distinct-pair set returns 3 rows/48 bytes under
6,000 fuel. A one-fuel neighbor fails and unrestricted row reads grow. These
measure actual prepared-statement result rows/binary field payload before
decode, using operation deltas; startup prepared reads remain included. They
do not measure constant database internal scans or exact fuel used. The strict
single-query fault fetching all rows then returning the correct count is caught.

Compiled predicates see staged rows. A held query retains eligibility and its
original body after another transaction changes that body and removes the only
newer row; a fresh query is denied. Real Pleris List.map constructs heterogeneous
records before one set call. Forged/no callers, bad types/refinements and malformed
whole sets are refused before callback/SQL. Generic conformance computes ranges
independently from generated data at both sizes and render modes, preserving
ordinary row, count, window and statement-cost assertions. PG random parity and
primitive inventories include the new forms without dropping existing ones.

## Frozen verification

[Raw receipts, runners and hashes](../evidence/E14/protected-ranges-2026-11-04/reproduce.sh)
retain exact source guards. At f4fc: affected core336, CLI5, host117 (9 existing
ignored fixtures), memory124, PostgreSQL89 and selected server175 passed;
test-compile and preflight passed (5,229 unique anchors). Focused strict native
campaigns: D3 baseline89/0,10/10 killed; row209/0,11/11; data74/0,4/4. Each binary's
complete named inventory is held; build/infrastructure failures, survivors or
stopped producers receive no kill credit. Source guard is clean before/after.

At LATEST, the sole change is one registered SQL wrong-field mutation. It keeps
String/bytea types compatible but compares a PK instead of declared order,
allowing valid wrong answers to reach native equality assertions. Preflight
passes (5,230 anchors), strict D3 baseline89/0 and1/1 killed, clean source guard.
The named native String-order test's full raw baseline1/0 and valid mutant0/1
assertion receipts are retained with another clean exact-source guard.
Production/compiler/test bytes are unchanged from f4fc (verified Git diff).
Independent delta review is clear. These are focused prerequisite records;
whole app campaigns, fresh browsers and full CI remain final-port acceptance.

Earlier native red/working logs, fixture/build errors and obsolete API/oracle
failures are retained as diagnostics only. The first broader run exposed
handwritten generated-API expectations and a row-only conformance oracle; these
were extended while retaining existing assertions. Preflight found two older
count anchors newly matching both count paths; full old-count context now makes
each original fault unique. No earlier source result is relabeled as final.

Remaining: fixed global relation windows, generic upload claim/publication/
reference/GC lifetime, initial public data and stable-ID/private-child behavior
where needed, then actual canonical ports and their final acceptance. Existing
startup/mixed-layer/upload guards stay. Prior output bundles and original dirty
row/durable worktrees are preserved. No remote or production work is claimed.
'''.replace('LATEST', latest)
(root / 'docs/diagnostics/protected-feed-store-ranges-2026-11-04.md').write_text(record)

path = root / 'docs/STATUS.md'
text = path.read_text()
old = 'Upload lifecycle, global relation/range reads and the canonical application\nports remain pending under'
new = '''Typed order-range scalar/heterogeneous-set counts passed frozen affected
checks and strict controls at `f4fc668f`; the script-only wrong-field successor
`SHORT` passed its own strict control/preflight. Independent review is clear.
See the [range record](diagnostics/protected-feed-store-ranges-2026-11-04.md).
Upload lifecycle, fixed global relation reads and the canonical application
ports remain pending under'''.replace('SHORT', latest[:8])
assert text.count(old) == 1
path.write_text(text.replace(old, new))
path = root / 'docs/NEXT.md'
text = path.read_text()
old = '''1. Implement and prove the remaining bounded range/relation reads needed
   by the canonical apps. Counts at `15f3c9df` and ordered windows at `79de0dd0`
   with reviewed follow-ups through `5b7f5be8` passed their named frozen local
   checks/controls. Those close prerequisites only. See the counts/window
   diagnostic records; measure rows/bytes/fuel, not calls alone.'''
new = '''1. Implement and prove fixed global relation windows needed by the
   canonical apps. Counts at `15f3c9df`, windows through `5b7f5be8`, and typed
   order-range counts at `f4fc668f` with the script-only `SHORT` control
   successor passed their named frozen local checks/review. Those close
   prerequisites only; see the counts/window/range records. Measure actual
   rows/bytes/fuel, not calls alone.'''.replace('SHORT', latest[:8])
assert text.count(old) == 1
path.write_text(text.replace(old, new))
path = root / 'docs/DECISIONS/ADR-XXXX-protected-feed-store.md'
path.write_text(path.read_text() + '''

The [range execution record](../diagnostics/protected-feed-store-ranges-2026-11-04.md)
records frozen implementation f4fc668f and its script-only wrong-field-control
successor SHORT. Independent review is clear. This closes typed order-range
counts locally, not global relation windows, upload lifetime or the canonical
apps and their final whole-campaign/browser/CI acceptance.
'''.replace('SHORT', latest[:8]))
print(f'range evidence: {len(files)} hashed inputs; frozen guards and native/control totals verified')
