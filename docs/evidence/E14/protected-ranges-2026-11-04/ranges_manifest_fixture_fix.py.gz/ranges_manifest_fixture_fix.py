from pathlib import Path
import shutil

path=Path('/home/haki/code/pw-wt/data-path/runtime/pw-table-memory/tests/compiled_ranges.rs')
text=path.read_text()
anchor='    broken.tables[0].schema.order = None;'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'''
    let schema=pw_core::tables::Schema::of(broken.tables.iter().map(|t|t.schema.clone()).collect());
    broken.hash=schema.hash.clone();
    broken.migration.to=schema.hash;
''',1)
path.write_text(text)
shutil.copy2('/tmp/pw-protected-migration/ranges-memory-edges.log','/tmp/pw-protected-migration/ranges-order-fixture-invalid.log')
