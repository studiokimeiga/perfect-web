#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
expected="${1:?exact script-only range successor required}"
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
git diff --quiet f4fc668f9d6783993203fe27e02180a3e377fc0e "$expected" -- compiler runtime spikes just
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
log=/tmp/pw-protected-migration
git rev-parse HEAD > "$log/ranges-review-frozen-source.txt"
just preflight > "$log/ranges-review-frozen-preflight.log" 2>&1
python3 scripts/d3_postgres_mutations.py 'ranges declared String order' > "$log/ranges-review-frozen-controls.log" 2>&1
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> "$log/ranges-review-frozen-source.txt"
echo 0 > "$log/ranges-review-frozen.exit"
echo 'wrong-field frozen control and source guard passed'
