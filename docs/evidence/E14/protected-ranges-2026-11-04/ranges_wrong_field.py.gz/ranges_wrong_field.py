from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'scripts/d3_postgres_mutations.py'
anchor = '''        Primitive::CountAfter => {
            let order = &table.columns[table.order.expect("validated range order")];'''
replacement = anchor + '''
            // Deliberate type-compatible wrong-field comparison for String order.
            let order = if matches!(order.kind, Kind::Bytes) {
                &table.columns[table.key[0]]
            } else { order };'''
assert (root / 'runtime/pw-table-postgres/src/sql.rs').read_text().count(anchor) == 1
fault = ('ranges declared String order is replaced by the primary key', 'SQL', anchor, replacement)
name, variable, old, new = fault
entry = '    (' + repr(name) + ', ' + variable + ',\n     ' + repr(old) + ',\n     ' + repr(new) + '),\n'
source = path.read_text()
assert source.count('MUTANTS = [\n') == 1 and name not in source
path.write_text(source.replace('MUTANTS = [\n', 'MUTANTS = [\n' + entry))
print('wrong-field control added; no production/test edits')
