from pathlib import Path
import shutil

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'runtime/pw-table-memory/src/lib.rs'
text = path.read_text()
old = '''            let (mark, selected) = key
                .split_last()
                .ok_or_else(|| Error::Input("range mark is missing".into()))?;'''
assert text.count(old) == 1
text = text.replace(old, old + '\n            let selected = selected.to_vec();', 1)
text = text.replace('data.prefixed(selected)', 'data.prefixed(&selected)', 1)
text = text.replace('holding(&data.indexes[index], selected)', 'holding(&data.indexes[index], &selected)', 1)
path.write_text(text)
shutil.copy2('/tmp/pw-protected-migration/ranges-memory-green.log', '/tmp/pw-protected-migration/ranges-memory-build-invalid.log')
