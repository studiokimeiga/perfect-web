from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'runtime/pw-table-postgres/tests/primitives.rs'
text = path.read_text()
anchor = '            "pw:tables/things#count-by-flag",'
assert text.count(anchor) == 1
names = ''.join(f'            "pw:tables/things#count-after-by-{fields}{suffix}",\n' for fields in ['flag','owner','owner-n','owner-rank','slug'] for suffix in ['', '-many'])
text = text.replace(anchor,names+anchor,1)
text = text.replace('        let window = f.starts_with("first-") || f.starts_with("last-");', '        let window = f.starts_with("first-") || f.starts_with("last-");\n        let range = f.starts_with("count-after-");',1)
text = text.replace('            .strip_prefix("count-")', '            .strip_prefix("count-after-")\n            .or_else(|| f.strip_prefix("count-"))',1)
anchor = '        if window {\n            args.push(json!(2));\n        }'
assert text.count(anchor) == 1
text = text.replace(anchor,r'''        if range {
            if import.ends_with("-many") {
                let fields = match f {
                    "get-many" => vec!["owner","n"],
                    "of-owner-many" => vec!["owner"],
                    "by-slug-many" => vec!["slug"],
                    "by-flag-many" => vec!["flag"],
                    _ => vec!["owner","rank"],
                };
                let requests = args[0].as_array().unwrap().iter().map(|key| {
                    let mut fields = if fields.len()==1 {
                        [(fields[0].to_string(),key.clone())].into_iter().collect::<serde_json::Map<String,Value>>()
                    } else { key.as_object().unwrap().clone() };
                    fields.insert("after".into(),json!(0));
                    Value::Object(fields)
                }).collect();
                args=vec![Value::Array(requests)];
            } else { args.push(json!(0)); }
        }
''' + anchor,1)
path.write_text(text)

path = root / 'runtime/pw-table-postgres/tests/parity.rs'
text = path.read_text()
anchor = '    reads.extend(windows);'
assert text.count(anchor) == 1
text = text.replace(anchor,r'''    // Every range request carries its own mark; same key/different mark is
    // retained through staged writes, commit and rollback in both adapters.
    let mut ranges = Vec::new();
    for (import,args) in counts.iter().filter(|(import,_)|import.starts_with("pw:tables/things#")) {
        let after = import.replace("#count-","#count-after-");
        if import.ends_with("-many") {
            let fields = match import.split('#').nth(1).unwrap() {
                "count-by-owner-many" => vec!["owner"],
                "count-by-flag-many" => vec!["flag"],
                "count-by-slug-many" => vec!["slug"],
                "count-by-owner-n-many" => vec!["owner","n"],
                _ => vec!["owner","rank"],
            };
            let requests = args[0].as_array().unwrap().iter().flat_map(|key| {
                [0,10].into_iter().map(|mark| {
                    let mut record = if fields.len()==1 {
                        [(fields[0].to_string(),key.clone())].into_iter().collect::<serde_json::Map<String,Value>>()
                    } else { key.as_object().unwrap().clone() };
                    record.insert("after".into(),json!(mark));
                    Value::Object(record)
                }).collect::<Vec<_>>()
            }).collect();
            ranges.push((after,vec![Value::Array(requests)]));
        } else {
            for mark in [0,10] {
                let mut args=args.clone(); args.push(json!(mark));
                ranges.push((after.clone(),args));
            }
        }
    }
    reads.extend(ranges);
''' + anchor,1)
path.write_text(text)
print('PG primitive inventory/typed arguments and randomized heterogeneous range parity expanded')
