from pathlib import Path
import importlib.util
import sys

root = Path('/home/haki/code/pw-wt/data-path')

def change(path, old, new):
    p = root / path
    s = p.read_text()
    assert s.count(old) == 1, (path, s.count(old), old)
    p.write_text(s.replace(old, new, 1))

# Preserve the older count faults at unique anchors.
change('scripts/d3_postgres_mutations.py',
       "'LEFT JOIN {t} t ON {} GROUP BY k.pw_slot ORDER BY k.pw_slot',\n     'INNER JOIN {t} t ON {} GROUP BY k.pw_slot ORDER BY k.pw_slot'",
       "'\\n                 LEFT JOIN {t} t ON {} GROUP BY k.pw_slot ORDER BY k.pw_slot',\n     '\\n                 INNER JOIN {t} t ON {} GROUP BY k.pw_slot ORDER BY k.pw_slot'")
change('scripts/data_path_mutations.py',
       "'                return Ok(Value::from(count));',\n     '                return Ok(Value::from(count + 1));'",
       "'                return Ok(Value::from(count));\\n            }\\n            let key = match selected.as_slice() {',\n     '                return Ok(Value::from(count + 1));\\n            }\\n            let key = match selected.as_slice() {'")

pg = [
 ('ranges scalar ignores the order mark', 'SQL',
  '"SELECT count(*) AS pw_range_count FROM {t} t WHERE {} AND t.{} > ${}::{}",',
  '"SELECT count(*) AS pw_range_count FROM {t} t WHERE {} AND (t.{} > ${}::{} OR true)",'),
 ('ranges set includes equal order marks', 'SQL', '"t.{} > k.c{}",', '"t.{} >= k.c{}",'),
 ('ranges set omits zero ranges with an inner join', 'SQL',
  '\n                     LEFT JOIN {t} t ON {} GROUP BY k.pw_slot ORDER BY k.pw_slot',
  '\n                     INNER JOIN {t} t ON {} GROUP BY k.pw_slot ORDER BY k.pw_slot'),
 ('ranges different marks collapse to the same equality key', 'SHAPE',
  '    Ok((columns, keys.into_iter().collect()))',
  '    let mut by = std::collections::BTreeMap::new();\n    for key in keys { by.entry(key[..function.by.len()].to_vec()).or_insert(key); }\n    Ok((columns, by.into_values().collect()))'),
 ('ranges correct set answers run one SQL query per pair', 'LIB',
  '    let (columns, keys) = shape::typed_ranges(table, function, args)?;\n    if keys.is_empty() {\n        return Ok(Value::Array(Vec::new()));\n    }',
  '''    let (columns, keys) = shape::typed_ranges(table, function, args)?;
    if keys.is_empty() {
        return Ok(Value::Array(Vec::new()));
    }
    if function.primitive.many() {
        let mut counts = Vec::new();
        for key in &keys {
            let params = columns.iter().zip(key).map(|(column, atom)| bind_array(column, &[atom])).collect::<Result<Vec<Param>, Error>>()?;
            let rows = conn.query(&inner.counters, sql, &params).map_err(database)?;
            let count: i64 = rows[0].try_get(1).map_err(database)?;
            let key = Value::Object(columns.iter().map(|c| c.name.clone()).zip(key.iter().map(shape::Atom::value)).collect());
            counts.push(serde_json::json!({"key":key,"count":count}));
        }
        return Ok(Value::Array(counts));
    }'''),
 ('ranges correct scalar answer materializes every SQL row first', 'LIB',
  '    let rows = conn\n        .query(&inner.counters, sql, &params)\n        .map_err(database)?;\n    if rows.len() != keys.len() {',
  '''    if !function.primitive.many() {
        let unbounded = sql.replace("count(*) AS pw_range_count", "t.*");
        let rows = conn.query(&inner.counters, &unbounded, &params).map_err(database)?;
        return Ok(Value::from(rows.len() as i64));
    }
    let rows = conn
        .query(&inner.counters, sql, &params)
        .map_err(database)?;
    if rows.len() != keys.len() {'''),
]
row = [
 ('ranges reader-only sets are refused', 'HOST_TABLES',
  'if (function.primitive == Primitive::CountMany\n',
  'if (matches!(function.primitive, Primitive::CountMany | Primitive::CountAfterMany)\n'),
 ('ranges result identities omit their mark', 'HOST_TABLES',
  '            columns.push(self.mark_column()?);',
  '            let _ = self.mark_column()?;'),
 ('ranges unused scalar import bypasses its order ABI', 'LINK',
  '        stored(&read.mark_column()?.stored, mark)?;',
  '        let _ = (read.mark_column()?, mark);'),
 ('ranges heterogeneous requests use another readers identity', 'OWNERS',
  'let mut fields = vec![(first.wit.clone(), Val::String(user.clone()))];',
  'let mut fields = vec![(first.wit.clone(), Val::String("u-carol".into()))];'),
 ('ranges reader and list formal names alias', 'TABLES',
  'let list_name = if crate::wit::ident(&by[0]) == "values" {',
  'let list_name = if false && crate::wit::ident(&by[0]) == "values" {'),
 ('ranges mark field aliases a stored field', 'TABLES',
  'while fields.contains(&crate::wit::ident(&name)) {',
  'while false && fields.contains(&crate::wit::ident(&name)) {'),
 ('ranges malformed set members silently disappear', 'SELECTORS',
  '.map(|value| key(&columns, value))\n                .collect::<Result<Vec<_>, _>>()?;',
  '.filter_map(|value| key(&columns, value).ok())\n                .collect::<Vec<_>>();'),
 ('ranges marks lose their actual order type and refinement', 'HOST_TABLES',
  'Ok(Column::new(&name, column.stored.clone()))',
  'Ok(Column::new(&name, Stored::Int { at_least: None, at_most: None }))'),
 ('ranges missing declared order is admitted', 'HOST_TABLES',
  'if self.order.is_none() {\n                    return Err(format!("range counts of {name} require a declared order"));',
  'if false && self.order.is_none() {\n                    return Err(format!("range counts of {name} require a declared order"));'),
]
data = [
 ('ranges memory ignores its mark', 'MEMORY',
  'if strictly_after(value, mark)? {', 'if true || strictly_after(value, mark)? {'),
 ('ranges memory includes equal integer marks', 'MEMORY',
  '.map(|value| value > *mark)', '.map(|value| value >= *mark)'),
 ('ranges memory coalesces different marks for the same selector', 'MEMORY',
  '    Ok((fields, keys))\n}\n\n/// Compare borrowed order values;',
  '    let mut by = BTreeMap::new();\n    for key in keys { by.entry(key[..function.by.len()].to_vec()).or_insert(key); }\n    Ok((fields, by.into_values().collect()))\n}\n\n/// Compare borrowed order values;'),
 ('ranges memory count is wrong for every generated table', 'MEMORY',
  '                return Ok(Value::from(count));\n            }\n            let key = Value::Object(',
  '                return Ok(Value::from(count + 1));\n            }\n            let key = Value::Object('),
]

for script, mutants in [('d3_postgres', pg), ('row_ownership', row), ('data_path', data)]:
    rendered = ''.join('    (' + repr(name) + ', ' + variable + ',\n     ' + repr(anchor) + ',\n     ' + repr(replacement) + '),\n' for name, variable, anchor, replacement in mutants)
    change(f'scripts/{script}_mutations.py', 'MUTANTS = [\n', 'MUTANTS = [\n' + rendered)

# Validate the exact production anchor of every new fault before any build.
sys.path.insert(0, str(root / 'scripts'))
for script in ['d3_postgres', 'row_ownership', 'data_path']:
    spec = importlib.util.spec_from_file_location(script, root / f'scripts/{script}_mutations.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for name, path, anchor, _ in module.MUTANTS:
        if name.startswith('ranges '):
            assert path.read_text().count(anchor) == 1, (name, path, path.read_text().count(anchor))
print('new range anchors: 19 unique')
