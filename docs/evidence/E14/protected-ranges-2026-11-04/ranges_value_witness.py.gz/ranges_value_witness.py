from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'runtime/pw-table-memory/tests/support/ranges.rs'
text = path.read_text()
assert 'fn range_program_kind' not in text
text = text.replace('fn range_program(predicate: bool) -> Program {', '''fn range_program(predicate: bool) -> Program { range_program_kind(predicate,None) }

fn range_program_order(kind: &str) -> Program { range_program_kind(false,Some(kind)) }

fn range_program_kind(predicate: bool, kind: Option<&str>) -> Program {''', 1)
text = text.replace('    let notes = std::fs::read_to_string', '    let mut notes = std::fs::read_to_string', 1)
anchor = '    if predicate {'
assert text.count(anchor) == 1
addition = r'''    if let Some(kind) = kind {
        let (ty,initial) = match kind {
            "refined" => ("Int where value >= 0","0"),
            "string" => ("String where String.length(value) >= 1","\"a\""),
            "bool" => ("Bool","false"),
            _ => panic!("unknown order fixture {kind}"),
        };
        notes = notes.replace("opaque type NoteId = String",&format!("opaque type NoteId = String\nopaque type Mark = {ty}"))
            .replace("added: Int","added: Mark");
        app = app.replace("import Notes\n","import Notes\nimport Notes.{ Mark }\n")
            .replace("added: 0",&format!("added: Mark({initial})"));
    }
'''
text = text.replace(anchor, addition + anchor, 1)
anchor = '        app.push_str(&format!('
assert text.count(anchor) == 1
text = text.replace(anchor, '        let params = if kind.is_some() { params.replace("mark: Int","mark: Mark") } else { params.to_string() };\n' + anchor, 1)
text += r'''

fn requested_order(fields: Vec<(&str,Val)>, mark: Val) -> Val {
    let mut fields = fields.into_iter().map(|(name,value)|(name.to_string(),value)).collect::<Vec<_>>();
    fields.push(("after".into(),mark));
    Val::Record(fields)
}

fn counted_order(fields: Vec<(&str,Val)>, mark: Val, count: i64) -> Val {
    Val::Record(vec![("key".into(),requested_order(fields,mark)),("count".into(),Val::S64(count))])
}

fn order_value(value: &serde_json::Value) -> Val {
    match value {
        serde_json::Value::Bool(value)=>Val::Bool(*value),
        serde_json::Value::String(value)=>Val::String(value.clone()),
        serde_json::Value::Number(value)=>Val::S64(value.as_i64().unwrap()),
        _=>panic!("non-scalar order fixture {value:?}"),
    }
}

fn order_cases() -> Vec<(&'static str,Vec<serde_json::Value>,Vec<(serde_json::Value,i64)>,Val)> {
    vec![
        ("refined",vec![json!(0),json!(1),json!(1),json!(5)],vec![(json!(0),3),(json!(1),1),(json!(5),0)],Val::S64(-1)),
        ("string",vec![json!("\0"),json!("a"),json!("a\0"),json!("z"),json!("é")],vec![(json!("\0"),4),(json!("a"),3),(json!("z"),1),(json!("é"),0)],Val::String("".into())),
        ("bool",vec![json!(false),json!(true),json!(false)],vec![(json!(false),1),(json!(true),0)],Val::S64(0)),
    ]
}
'''
path.write_text(text)

body = r'''

#[test]
fn range_marks_keep_refinements_and_native_bool_and_utf8_order_through_compiled_calls() {
    for (kind,values,cases,invalid) in order_cases() {
        let program=range_program_order(kind);
        let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");
        tables.transaction(|tx| {
            for (index,value) in values.iter().enumerate() {
                let mut row=note_json(ALICE,&format!("n{index}"),BOB,0); row["added"]=value.clone();
                tx.write("pw:tables/notes#insert",&[row])?;
            }
            Ok(())
        }).assert_ok("seed actual order values");
        assert_eq!(tables.read("pw:tables/notes#count-by-author",&[json!(ALICE)]).assert_ok("absent initial mark uses ordinary count"),json!(values.len()));
        let before=tables.statements();
        let rejected=query(&program,&tables,"SinceMine",&as_user(ALICE),&[handle(ALICE),invalid]);
        assert!(rejected.is_err(),"out-of-domain {kind} mark is refused: {rejected:?}");
        assert_eq!(tables.statements()-before,0,"bad mark reaches no adapter operation");
        for (mark,count) in &cases {
            assert_eq!(query(&program,&tables,"SinceMine",&as_user(ALICE),&[handle(ALICE),order_value(mark)]),Ok(vec![Val::S64(*count)]),"{kind} {mark}");
            assert_eq!(query(&program,&tables,"SinceShared",&as_user(BOB),&[handle(BOB),order_value(mark)]),Ok(vec![Val::S64(*count)]),"shared {kind} {mark}");
        }
        let (low,low_count)=&cases[0]; let (high,high_count)=cases.last().unwrap();
        let requests=Val::List(vec![requested_order(vec![],order_value(high)),requested_order(vec![],order_value(low)),requested_order(vec![],order_value(low))]);
        assert_eq!(query(&program,&tables,"RangeMarks",&as_user(ALICE),&[handle(ALICE),requests]),Ok(vec![Val::List(vec![
            counted_order(vec![("author",handle(ALICE))],order_value(low),*low_count),
            counted_order(vec![("author",handle(ALICE))],order_value(high),*high_count),
        ])]),"{kind} records retain typed distinct marks");
    }
}
'''
path = root / 'runtime/pw-table-memory/tests/compiled_ranges.rs'
text = path.read_text()
assert 'fn range_marks_keep_refinements' not in text
path.write_text(text + body)
path = root / 'runtime/pw-table-postgres/tests/compiled_ranges.rs'
text = path.read_text()
assert 'fn range_marks_keep_refinements' not in text
pg = body.replace('let tables=MemoryTables::new(program.tables.clone()).assert_ok("memory");', '''let Some(url)=common::database() else { return; };
        let scratch=common::Scratch::new(&url,"range_order_kinds");
        let tables=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("PostgreSQL");''')
pg = pg.replace('query(', 'q(').replace('tables.statements()', 'tables.operation_statements()')
pg = pg.replace('    }\n}\n', '''        drop(tables);
        let reopened=PgTables::open(&url,scratch.schema(),program.tables.clone()).assert_ok("reopen");
        assert_eq!(reopened.read("pw:tables/notes#count-after-by-author",&[json!(ALICE),cases[0].0.clone()]).assert_ok("range count after reopen"),json!(cases[0].1));
    }
}
''')
path.write_text(text + pg)
print('actual compiled refined/Bool/Unicode-NUL mark and persisted-reopen witnesses added')
