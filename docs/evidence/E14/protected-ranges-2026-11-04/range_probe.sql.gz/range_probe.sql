SHOW server_version;
SELECT false < true AS bool_ascending,
       true > false AS bool_after,
       '\x00'::bytea < '\x01'::bytea AS byte_order,
       '\x61'::bytea < '\x6100'::bytea AS prefix_before_longer,
       '\xc3a9'::bytea > '\x7a'::bytea AS utf8_byte_order;
SELECT count(*) FILTER (WHERE value > 2::bigint) AS strictly_after,
       count(*) FILTER (WHERE value >= 2::bigint) AS inclusive_neighbor
FROM (VALUES (1::bigint), (2::bigint), (2::bigint), (3::bigint)) v(value);
