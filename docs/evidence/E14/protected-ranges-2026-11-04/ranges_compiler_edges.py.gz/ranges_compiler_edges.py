from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'compiler/pw-core/tests/table_ranges.rs'
text = path.read_text()
assert 'fn range_record_names_never_silently_alias_an_ordinary_selector_tuple' not in text
old = '            assert_eq!(f["sorted_by"], serde_json::json!([]));'
assert text.count(old) == 1
text = text.replace(old, '            assert!(f["sorted_by"].as_array().is_none_or(|fields| fields.is_empty()), "range counts have no stored-row sort: {f}");')
old = '''.replace("bucket", field)
            .replace(
                "Bucket",'''
new = '''.replace("owner", field)
            .replace(
                "Owner",'''
assert text.count(old) == 1
text = text.replace(old, new)
text = text.replace('"selector {field}: {:?}"', '"reader field {field}: {:?}"')
text += r'''

#[test]
fn range_record_names_never_silently_alias_an_ordinary_selector_tuple() {
    let source = BASE.replace("bucket", "after");
    let found = diagnostics(&source);
    assert!(found.iter().any(|d| d.code == "PW0361" && d.message.contains("same type") && d.message.contains("ranges-owner-after")), "different range and ordinary selector meanings are refused by emitted identity: {found:#?}");
    let valid = source.replace("bucket", "bucket").replace("after", "cursor");
    let build = pw_core::build::build(&units(&valid));
    assert!(build.is_ok(), "renamed selector retains distinct records: {:?}", build.as_ref().err());
    assert!(build.unwrap().tables.tables[0].functions.iter().any(|f| f.name == "count_after_by_owner_cursor_many"));
}
'''
# No no-op source rewrite in the positive neighbor.
text = text.replace('source.replace("bucket", "bucket").replace("after", "cursor")', 'source.replace("after", "cursor")')
path.write_text(text)
