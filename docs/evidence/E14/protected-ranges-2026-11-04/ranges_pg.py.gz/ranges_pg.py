from pathlib import Path

root = Path('/home/haki/code/pw-wt/data-path')
path = root / 'runtime/pw-table-postgres/src/shape.rs'
text = path.read_text()
assert 'fn range_columns' not in text
text += r'''

/// Typed request columns: equality selectors, then a separately named order mark.
pub(crate) fn range_columns(table: &TableShape, function: &FunctionShape) -> Result<Vec<Column>, Error> {
    let order = table.order.ok_or_else(||Error::Schema("range count requires declared order".into()))?;
    let mut columns = function.by.iter().map(|&at|table.columns[at].clone()).collect::<Vec<_>>();
    let mut mark = table.columns[order].clone();
    mark.name = pw_core::tables::after_field(table.columns.iter().map(|c|c.name.as_str()));
    columns.push(mark);
    Ok(columns)
}

/// The cutoff participates in dedup/order, never in the equality-selector inventory.
pub(crate) fn typed_ranges(table: &TableShape, function: &FunctionShape, args: &[Value]) -> Result<(Vec<Column>,Vec<Key>),Error> {
    let columns = range_columns(table,function)?;
    let supplied = if function.primitive.many() {
        let [Value::Array(requests)] = args else { return Err(Error::Input("set range count takes one array of selector-and-mark records".into())); };
        requests.iter().map(|request| {
            let record=request.as_object().ok_or_else(||Error::Input("range request is a record".into()))?;
            if record.len()!=columns.len() { return Err(Error::Input("range request fields differ".into())); }
            columns.iter().map(|column|record.get(&column.name).ok_or_else(||Error::Input(format!("range request lacks {}",column.name)))).collect::<Result<Vec<_>,Error>>()
        }).collect::<Result<Vec<_>,Error>>()?
    } else {
        if args.len()!=columns.len() { return Err(Error::Input("range count takes equality selectors and an order mark".into())); }
        vec![args.iter().collect()]
    };
    let mut keys = BTreeSet::new();
    for request in supplied {
        let key = columns.iter().zip(request).map(|(column,value)| {
            if !validates(value,&column.stored) { return Err(Error::Input(format!("range field {} fails its declared type or bound",column.name))); }
            Atom::parse(value)
        }).collect::<Result<Key,Error>>()?;
        keys.insert(key);
    }
    Ok((columns,keys.into_iter().collect()))
}
'''
path.write_text(text)

path = root / 'runtime/pw-table-postgres/src/sql.rs'
text = path.read_text()
anchor = '        Primitive::Count => format!('
assert text.count(anchor) == 1
addition = r'''        Primitive::CountAfter => {
            let order = &table.columns[table.order.expect("validated range order")];
            format!("SELECT count(*) AS pw_range_count FROM {t} t WHERE {} AND t.{} > ${}::{}",
                equal("t",table,&function.by,&by),ident(&order.name),function.by.len()+1,order.kind.sql())
        }
        Primitive::CountAfterMany => {
            let order = &table.columns[table.order.expect("validated range order")];
            let mut arrays = function.by.iter().enumerate().map(|(i,&field)|format!("${}::{}",i+1,table.columns[field].kind.array())).collect::<Vec<_>>();
            arrays.push(format!("${}::{}",function.by.len()+1,order.kind.array()));
            let mut columns = (0..=function.by.len()).map(|i|format!("c{i}")).collect::<Vec<_>>();
            columns.push("pw_slot".into());
            let mut join = function.by.iter().enumerate().map(|(i,&field)|format!("t.{} = k.c{i}",ident(&table.columns[field].name))).collect::<Vec<_>>();
            join.push(format!("t.{} > k.c{}",ident(&order.name),function.by.len()));
            format!("SELECT k.pw_slot AS pw_range_slot, count(t.{}) FROM unnest({}) WITH ORDINALITY AS k({}) \
                     LEFT JOIN {t} t ON {} GROUP BY k.pw_slot ORDER BY k.pw_slot",
                ident(&table.columns[table.key[0]].name),arrays.join(", "),columns.join(", "),join.join(" AND "))
        }
'''
text = text.replace(anchor, addition + anchor, 1)
path.write_text(text)

path = root / 'runtime/pw-table-postgres/src/lib.rs'
text = path.read_text()
assert 'fn read_ranges(' not in text
anchor = '    let (args, window_limit) = if function.primitive.window() {'
assert text.count(anchor) == 1
text = text.replace(anchor, '''    if function.primitive.range() {
        return read_ranges(inner,conn,table,function,sql,args);
    }
''' + anchor, 1)
anchor = '/// **A read through a compiler-emitted import**'
assert text.count(anchor) == 1
addition = r'''/// A scalar/set range is one aggregate query after the whole request validates.
fn read_ranges(inner: &Inner, conn: &mut Conn, table: &shape::TableShape, function: &shape::FunctionShape, sql: &str, args: &[Value]) -> Result<Value,Error> {
    let (columns,keys) = shape::typed_ranges(table,function,args)?;
    if keys.is_empty() { return Ok(Value::Array(Vec::new())); }
    let params = if function.primitive.many() {
        columns.iter().enumerate().map(|(at,column)| {
            let atoms = keys.iter().map(|key|&key[at]).collect::<Vec<_>>();
            bind_array(column,&atoms)
        }).collect::<Result<Vec<Param>,Error>>()?
    } else {
        columns.iter().zip(&keys[0]).map(|(column,atom)|bind_atom(column,atom)).collect::<Result<Vec<Param>,Error>>()?
    };
    let rows = conn.query(&inner.counters,sql,&params).map_err(database)?;
    if rows.len()!=keys.len() { return Err(Error::Database("range count rows do not cover the requested pairs".into())); }
    if !function.primitive.many() {
        let count: i64 = rows[0].try_get(0).map_err(database)?;
        if count<0 { return Err(Error::Database("range count is negative".into())); }
        return Ok(Value::from(count));
    }
    let mut counts=Vec::with_capacity(keys.len());
    for (index,(key,row)) in keys.into_iter().zip(rows).enumerate() {
        let slot:i64=row.try_get(0).map_err(database)?;
        let count:i64=row.try_get(1).map_err(database)?;
        if usize::try_from(slot).ok()!=index.checked_add(1) || count<0 {
            return Err(Error::Database("range count slot or value is invalid".into()));
        }
        let key = Value::Object(columns.iter().map(|c|c.name.clone()).zip(key.iter().map(shape::Atom::value)).collect());
        counts.push(serde_json::json!({"key":key,"count":count}));
    }
    Ok(Value::Array(counts))
}

'''
text = text.replace(anchor, addition + anchor, 1)
path.write_text(text)
print('PostgreSQL typed scalar/set range aggregates implemented')
