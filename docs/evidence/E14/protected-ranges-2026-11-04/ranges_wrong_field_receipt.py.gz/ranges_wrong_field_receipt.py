"""Retain the named native assertion for the already registered wrong-field fault."""
from pathlib import Path
import importlib.util
import os
import subprocess
import sys

root = Path('/home/haki/code/pw-wt/data-path')
expected = '06a6ad18a190cf2b69df3809e20213e5b3e6baa3'
logs = Path('/tmp/pw-protected-migration')
sys.path.insert(0, str(root / 'scripts'))
import cargo_assertion_results
import mutation_source
import producer_process

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

assert git('rev-parse', 'HEAD') == expected and not git('status', '--porcelain')
assert os.environ.get('PW_TABLES_DATABASE_URL')
spec = importlib.util.spec_from_file_location('range_d3', root / 'scripts/d3_postgres_mutations.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
faults = [m for m in module.MUTANTS if m[0] == 'ranges declared String order is replaced by the primary key']
assert len(faults) == 1
name = 'range_marks_keep_refinements_and_native_bool_and_utf8_order_through_compiled_calls'
command = ['cargo', 'test', '--quiet', '--locked', '-p', 'pw-table-postgres', '--test', 'compiled_ranges', '--', '--exact', name, '--format=pretty']
baseline = producer_process.run(command, cwd=root, timeout=900)
(logs / 'ranges-review-native-baseline.log').write_text(baseline.stdout)
result = cargo_assertion_results.validate(baseline.returncode, baseline.stdout, root=root, sources=module.SOURCES)
assert result.valid and result.passed == 1 and result.failed == 0, baseline.stdout
inventory = cargo_assertion_results.names(baseline.stdout)
_, path, anchor, replacement = faults[0]
original = path.read_text()
assert original.count(anchor) == 1
with mutation_source.changed(path, original, original.replace(anchor, replacement, 1)):
    mutant = producer_process.run(command, cwd=root, timeout=900)
    (logs / 'ranges-review-native-mutant.log').write_text(mutant.stdout)
    result = cargo_assertion_results.validate(mutant.returncode, mutant.stdout, root=root, sources=module.SOURCES, expected=inventory)
    assert result.valid and result.passed == 0 and result.failed == 1, mutant.stdout
assert git('rev-parse', 'HEAD') == expected and not git('status', '--porcelain')
(logs / 'ranges-review-native-source.txt').write_text(expected + '\nsource guard: clean\n')
print('named native String comparison assertion: baseline1/0, valid fault0/1, source guard clean')
