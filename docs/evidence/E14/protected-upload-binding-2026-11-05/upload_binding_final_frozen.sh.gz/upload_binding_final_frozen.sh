#!/bin/bash
set -euo pipefail
source /home/haki/pw-setup/env.sh
cd /home/haki/code/pw-wt/data-path
export CARGO_BUILD_JOBS=4 RUST_TEST_THREADS=2
export PW_TABLES_DATABASE_URL="${PW_STORE_DATABASE_URL:?throwaway PostgreSQL required}"
expected=6a4c906d4329005b147bfade8f0e2dd87315ae6b
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
log=/tmp/pw-protected-migration
git rev-parse HEAD > "$log/upload-binding-final-source.txt"
run() { local name="$1"; shift; echo "starting $name"; "$@" > "$log/upload-binding-final-$name.log" 2>&1; echo "$name passed"; }
run host cargo test --locked -p pw-host --features engine
run memory cargo test --locked -p pw-table-memory
run pg cargo test --locked -p pw-table-postgres
run server cargo test --locked -p pw-dev-server --bin pw-dev-server -- tests::protected_migration:: tests::conformance:: tests::tables:: tests::tables_pg::
run preflight just preflight
run controls python3 /mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration/upload_binding_final_controls.py
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
echo 'source guard: clean' >> "$log/upload-binding-final-source.txt"
echo 0 > "$log/upload-binding-final.exit"
