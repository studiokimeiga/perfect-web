from pathlib import Path
import gzip,hashlib,re,subprocess,json
root=Path('/home/haki/code/pw-wt/data-path');logs=Path('/tmp/pw-protected-migration')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='6a4c906d4329005b147bfade8f0e2dd87315ae6b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
assert (logs/'upload-binding-final.exit').read_text().strip()=='0'
assert '24/24 killed; no invalid or stopped producer' in (logs/'upload-binding-final-controls.log').read_text()
out=root/'docs/evidence/E14/protected-upload-binding-2026-11-05';assert not out.exists();out.mkdir()
files=list(logs.glob('upload-binding-final-*.log'))+[logs/'upload-binding-final-source.txt',logs/'upload-binding-final.exit']
for name in ['upload-binding-unbound-red.log','upload-binding-review-host-red.log','upload-binding-review-source-red.log','upload-binding-instantiate-red.log','upload-binding-authorization-red.log','upload-table-root-red.log','upload-binding-versioned-red.log']:
 files.append(logs/name)
for p in files:(out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in (logs/'upload-binding-final-strict').iterdir():
 if p.suffix=='.json':assert json.loads(p.read_text())['valid']
 (out/('strict-'+p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
helper=Path('/mnt/c/Users/haki/Documents/Codex/2026-11-02/pleris-continuation/work/protected-migration')
for name in ['upload_binding_final_frozen.sh','upload_binding_final_controls.py','upload_binding_record.py']:
 (out/(name+'.gz')).write_bytes(gzip.compress((helper/name).read_bytes(),mtime=0))
counts={kind:sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',(logs/f'upload-binding-final-{kind}.log').read_text())) for kind in ['host','memory','pg','server']}
(out/'review.txt').write_text('Immutable separate review of f95b842f found byte-ceiling/source/stub/reuse gaps, reproduced native before repair. Follow-up d1470948 found ordinary table root missing both independent axes; native Mine query reproduced both before repair. Parent also reproduced literal-path and versioned-prefix gaps. Final immutable6a4c906d review CLEAR. Full authority Notes+Other neighbor preserves old wrong-primary control reachability. Session/claim ownership, registry, storage, uncertain outcomes and commit lifetime remain unproved and disabled.\n')
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir())))
record=root/'docs/diagnostics/protected-upload-binding-2026-11-05.md'
record.write_text(f'''# Generic upload runtime binding: reviewed local prerequisite

Frozen source6a4c906d4329005b147bfade8f0e2dd87315ae6b, clean before/after.
Host{counts['host']} (9 existing ignored), memory{counts['memory']}, actual
configured PostgreSQL{counts['pg']}, selected server{counts['server']} and
preflight5,304 passed. Strict native baseline47 across five complete selected
inventories; 21 binding faults and three reached old controls all killed.
All raw validator JSON is valid; no stopped/invalid producer counts. Separate
immutable final review is clear.

This proves declaration/grant/ABI binding only. Compiled Keep/Attached use mock
resource callbacks. No session ownership, lease ledger, physical blob, registry,
durable commit, unknown-outcome or HTTP lifecycle acceptance follows. Both
adapters' unbound-asset guards and server upload/mixed-layer guards remain closed;
canonical feed/store still use legacy Rust layers.

The host independently reads generic own-module/source upload declarations and
binds public Ref/Option<Ref> asset fields explicitly. It validates identities,
literal paths, the compiler's 100MB ceiling, kinds/limits, association/source and
exact structural reference shape. Runtime structure does not replace compiler
nominal identity or confer publication authority. Every upload import, unused
ones included, needs its exact database/resource capabilities in the contract
and actual grants, real WIT ABI, command kind and whole argument/answer values.
Bare/versioned reserved spellings cannot evade declaration admission.

All entry points fail closed: actual execution, stub instantiation, root
admission and authorization-only reuse. Prepared::authorize_with_tables_as now
receives the root's actual Granted; root admission checks generic tables/uploads
and actual imported types without fetching body callbacks. The server checks
even no-predicate cached roots before returning, without opening a snapshot.
Compiled predicates retain their own authority and invocation read state.
Actual authorization-only full-grant and independent missing-axis regressions
cover uploads and ordinary tables with callback0. Existing relation authorization
and snapshot tests pass. A no-predicate server test admits a valid neighbor, then
rejects an otherwise-unused forged upload import while ordinary node admission
still succeeds; this does not claim an enabled upload deployment or cache.

Review-driven native reds are retained: unbound execution initially returned Ok;
forged byte ceiling/literal paths and ordinary source=None were accepted; actual
Keep stub-instantiation returned links; unbound Attached and ordinary missing
actual/contract table axes returned authorization-only Ok limits. Corrections
are isolated by faults. The existing predicate-after-body, query-as-command and
wrong-primary controls are reached at assertions. Wrong-primary retains BOTH
real capabilities so the new independent contract check cannot mask it.

The first d147 focused wrapper stopped in its baseline on a helper API error
(bounded needed cmd); no mutant credit was taken. The final retained complete
24-control run uses the corrected helper and exact/restored source guards.

Reproduce from the frozen source with the byte-preserving gzip runner and strict
helper under [the evidence directory](../evidence/E14/protected-upload-binding-2026-11-05/).
Per-binary raw output, validator receipts, source guard, native red witnesses
and review summary are SHA256SUMS-covered. Whole final campaigns, browsers/CI,
hosted landing and production conversion remain outside this prerequisite.
''')
status=root/'docs/STATUS.md';s=status.read_text();needle='Earlier green records below apply to their named sources only.';assert s.count(needle)==1
s=s.replace(needle,'''Generic upload runtime binding source `6a4c906d` passed frozen host126 (9 existing
ignored), memory156, actual PostgreSQL102, selected server86, preflight5,304 and
24/24 strict controls. Separate immutable review is clear. Root admission now
holds fresh/stub/cached paths to independent contract/actual grant axes and WIT
ABIs; this is metadata/engine proof with mock callbacks. See the
[binding record](diagnostics/protected-upload-binding-2026-11-05.md).
Actual upload registry, session/claim ownership, storage, transaction lifetime
and HTTP are next; original guards remain closed and canonical apps legacy.
'''+needle);status.write_text(s)
print(counts)
