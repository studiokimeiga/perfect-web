"""Twenty-one binding faults and three old controls, strict native receipts."""
from pathlib import Path
import importlib.util,sys,json,hashlib
root=Path('/home/haki/code/pw-wt/data-path');sys.path.insert(0,str(root/'scripts'))
import cargo_assertion_results,producer_process,mutant_incremental
def module(name):
 spec=importlib.util.spec_from_file_location(name,root/f'scripts/{name}_mutations.py');loaded=importlib.util.module_from_spec(spec);spec.loader.exec_module(loaded);return loaded
row=module('row_ownership');d2=module('d2_writes');table=module('table_host')
mutants=[m for m in row.MUTANTS if m[0].startswith('upload binding ')];assert len(mutants)==21
mutants += [next(m for m in row.MUTANTS if m[0]=='a predicate is asked after the export runs'),next(m for m in d2.MUTANTS if m[0]=='the engine takes every export for a command'),next(m for m in table.MUTANTS if m[0]=="the gate trusts an import's claim of its capability")]
tests=[['cargo','test','--quiet','--locked','-p','pw-host','--test','assets'],['cargo','test','--quiet','--locked','-p','pw-table-memory','--test','compiled_assets'],['cargo','test','--quiet','--locked','-p','pw-dev-server','--bin','pw-dev-server','reused_queries_without_predicates'],['cargo','test','--quiet','--locked','-p','pw-table-memory','--test','compiled_predicates'],['cargo','test','--quiet','--locked','-p','pw-table-memory','--test','compiled_gate']]
sources=sorted((root/'runtime').rglob('*.rs'))+sorted((root/'spikes/own-renderer/server/src').rglob('*.rs'));inventory={}
out=Path('/tmp/pw-protected-migration/upload-binding-final-strict');out.mkdir(exist_ok=True)
def run(n,indices):
 passed=failed=0
 for i in indices:
  cmd=tests[i]+['--','--format=pretty','--test-threads=2'];child=producer_process.run(cmd,cwd=root,timeout=1200)
  path=out/f'run-{n:02}-{i:02}.log';path.write_text(child.stdout)
  result=cargo_assertion_results.validate(child.returncode,child.stdout,root=root,sources=sources,expected=inventory.get(i))
  path.with_suffix('.json').write_text(json.dumps({'command':cmd,'exit':child.returncode,'valid':result.valid,'passed':result.passed,'failed':result.failed,'sha256':hashlib.sha256(child.stdout.encode()).hexdigest()},indent=2))
  if not result.valid:raise RuntimeError(f'invalid native producer {path}: '+child.stdout[-3000:])
  inventory.setdefault(i,cargo_assertion_results.names(child.stdout));passed+=result.passed;failed+=result.failed
  mutant_incremental.bounded(cmd)
 return passed,failed
passed,failed=run(0,range(len(tests)));assert failed==0;print(f'baseline {passed} native assertions, complete inventories',flush=True)
for n,(label,path,before,after) in enumerate(mutants,1):
 original=path.read_bytes();s=original.decode();assert s.count(before)==1,(label,s.count(before))
 try:
  path.write_text(s.replace(before,after))
  indices=[0,1,2] if n<=21 else ([3] if n==22 else ([4] if n==23 else [1]))
  passed,failed=run(n,indices);assert failed>0,f'survived: {label}'
  print(f'KILLED {n}/{len(mutants)}: {label}; {passed} pass/{failed} fail',flush=True)
 finally:path.write_bytes(original)
print('24/24 killed; no invalid or stopped producer',flush=True)
