#!/usr/bin/env python3
"""Evidence for the message-text fixes (2026-11-06), into
docs/evidence/E14/message-text-2026-11-06/.

Run from the worktree root, inside WSL, with ~/pw-setup/env.sh sourced and
CARGO_TARGET_DIR, GIT_DIR and GIT_WORK_TREE exported, on a clean committed
tree. Each step's command, exit status and output are kept; the manifest
lists every file with its sha256.

    collect.py quick      the red controls, the tests, the guide, the patches,
                          the planner, anchors, preflight and evidence-gates
    collect.py mutations SCRIPT...
                          each mutation script whole, one log each
    collect.py manifest   manifest.json over what the steps wrote
"""

import datetime
import gzip
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path.cwd()
OUT = ROOT / "docs/evidence/E14/message-text-2026-11-06"
BASE = "5d4d4d55a36f52ea556aa8f2af3e70b1150ffcf6"
TARGET = pathlib.Path(os.environ["CARGO_TARGET_DIR"])
PW = TARGET / "debug/pw"
STEPS = OUT / "steps.jsonl"
HERE = pathlib.Path(__file__).resolve().parent


def git(*args):
    return subprocess.run(["git", *args], capture_output=True, text=True, check=True).stdout


def record(name, command, code, extra=None):
    with STEPS.open("a") as f:
        f.write(json.dumps({"step": name, "command": command, "exit": code, **(extra or {})}) + "\n")


def run(name, command, log, gz=False, env=None, shell=False):
    """Runs `command`, keeps its output in `log` (gzipped when `gz`)."""
    started = datetime.datetime.now(datetime.timezone.utc)
    p = subprocess.run(
        command, capture_output=True, text=True, shell=shell,
        env={**os.environ, **(env or {})},
    )
    text = (
        f"$ {command if shell else ' '.join(command)}\n"
        f"started: {started.isoformat()}\n"
        f"commit: {git('rev-parse', 'HEAD').strip()}"
        f"{'' if git_clean() else ' + uncommitted changes'}\n\n"
        + p.stdout + p.stderr + f"\nexit: {p.returncode}\n"
    )
    path = OUT / (log + (".gz" if gz else ""))
    if gz:
        with gzip.open(path, "wt") as f:
            f.write(text)
    else:
        path.write_text(text)
    record(name, command, p.returncode, {"log": path.name})
    print(f"{name}: exit {p.returncode} -> {path.name}", flush=True)
    return p


def git_clean():
    return subprocess.run(
        ["git", "diff", "--quiet", "HEAD", "--", ".", ":(exclude)docs/evidence"]
    ).returncode == 0


def test_lines(out):
    return [l for l in out.splitlines() if l.startswith(("test ", "test result")) or "panicked at" in l]


# --- the red controls: each fix reverted, its test must fail -----------------

SHARED_CACHE = ["cargo", "test", "--locked", "-p", "pw-core", "--test", "shared_cache_holds_no_readers_value"]

# (what, edits, command, the tests that must fail and no other). An edit is
# ("revert", path): the file as the base holds it; or ("replace", path,
# anchor, replacement), the anchor found exactly once.
REVERTS = [
    (
        "PW5001's note as before the fix: it stops mid-sentence",
        [("revert", "compiler/pw-core/src/check.rs")],
        SHARED_CACHE,
        {"the_parameter_a_readers_value_comes_from_is_noted_in_a_whole_sentence",
         "the_parameter_is_noted_with_its_own_label_where_more_are_given"},
    ),
    (
        "PW5001's note and cause chain given all the declaration's parameters state, not the parameter's own",
        [("replace", "compiler/pw-core/src/check.rs",
          ".map(|g| (g.first.as_str(), &g.first_label))", ".map(|g| (g.first.as_str(), &g.label))")],
        SHARED_CACHE,
        {"the_parameter_is_noted_with_its_own_label_where_more_are_given"},
    ),
    (
        "PW5048's note tells the dated story, as before the fix",
        [("revert", "compiler/pw-core/src/holds.rs")],
        ["cargo", "test", "--locked", "-p", "pw-core", "--test", "controls_where_they_hold"],
        {"a_refused_controls_note_says_the_rule_and_why"},
    ),
    (
        "the guide shows PW5048's old note, which `pw check` no longer prints",
        [("revert", "docs/guide/errors.md")],
        ["cargo", "test", "--locked", "-p", "pw-cli", "--test", "guide"],
        {"every_example_in_the_guide_compiles_as_it_says"},
    ),
]


def red():
    lines = []
    for what, edits, command, expected in REVERTS:
        paths = sorted({e[1] for e in edits})
        originals = {p: (ROOT / p).read_text() for p in paths}
        try:
            for e in edits:
                if e[0] == "revert":
                    (ROOT / e[1]).write_text(git("show", f"{BASE}:{e[1]}"))
                else:
                    text = (ROOT / e[1]).read_text()
                    if text.count(e[2]) != 1:
                        raise SystemExit(f"{what}: the anchor is not found exactly once in {e[1]}")
                    (ROOT / e[1]).write_text(text.replace(e[2], e[3], 1))
            r = subprocess.run(command, capture_output=True, text=True)
        finally:
            for p, text in originals.items():
                (ROOT / p).write_text(text)
        out = r.stdout + r.stderr
        failed = set(re.findall(r"^test (\S+) \.\.\. FAILED$", out, re.M))
        verdict = (
            "FAIL as they must, and no other"
            if failed == expected and r.returncode != 0
            else f"DID NOT FAIL AS THEY MUST (failed: {sorted(failed)})"
        )
        how = "; ".join(
            f"{e[1]} as at {BASE[:8]}" if e[0] == "revert" else f"{e[1]}: `{e[2]}` -> `{e[3]}`"
            for e in edits
        )
        test = ", ".join(sorted(expected))
        lines += [f"== {what}", f"   edited: {how}",
                  f"   $ {' '.join(command)}", f"   exit {r.returncode}; {test}: {verdict}"]
        lines += ["   " + l for l in test_lines(out)]
        # The assertion's own words, where the test says them.
        lines += ["   | " + l for l in out.splitlines()
                  if l.startswith(("  left:", " right:", "the reason first", "the page shows output"))][:6]
        lines.append("")
        record(f"red: {what}", command, r.returncode, {"edited": paths, "verdict": verdict})
    touched = sorted({e[1] for _, es, _, _ in REVERTS for e in es})
    restored = subprocess.run(["git", "diff", "--quiet", "HEAD", "--", *touched])
    lines.append(f"sources restored to HEAD: {'yes' if restored.returncode == 0 else 'NO'}")
    (OUT / "red-controls.txt").write_text(
        f"Each fix undone in turn (base {BASE}), and the tests that hold it run\n"
        f"commit: {git('rev-parse', 'HEAD').strip()}\n\n" + "\n".join(lines) + "\n"
    )
    print("red controls written", flush=True)


# --- the benchmark's patches ---------------------------------------------------

def store_at(at, baseline_files):
    at.mkdir(parents=True)
    for rel, text in baseline_files.items():
        p = at / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)


def baseline(rev):
    """The benchmark's Pleris store at `rev` (None: the working tree)."""
    base = "benchmarks/baselines/pleris"
    if rev is None:
        files = [p for p in (ROOT / base).rglob("*.pw")]
        return {str(p.relative_to(ROOT / base)): p.read_text() for p in files}
    names = git("ls-tree", "-r", "--name-only", rev, base).split()
    return {n[len(base) + 1:]: git("show", f"{rev}:{n}") for n in names if n.endswith(".pw")}


def patches(rev):
    names = sorted(
        str(p.relative_to(ROOT)) for p in (ROOT / "benchmarks/tasks").glob("*/*/pleris.patch")
    )
    if rev is None:
        return {n: (ROOT / n).read_text() for n in names}
    return {n: git("show", f"{rev}:{n}") for n in names}


def apply_all(store_rev, patch_rev, work):
    """Each task's setup, reference and unsafe patch, applied as the harness
    applies them: the setup first, then the change. (applied, failed names, stores)."""
    store, ps = baseline(store_rev), patches(patch_rev)
    applied, failed, stores = 0, [], []
    for name in ps:
        task, change = pathlib.Path(name).parts[2:4]
        setup = f"benchmarks/tasks/{task}/setup/pleris.patch"
        at = work / f"{task}-{change}"
        store_at(at, store)
        given = ([setup] if change != "setup" and setup in ps else []) + [name]
        ok = True
        for g in given:
            pf = work / (g.replace("/", "_"))
            pf.write_text(ps[g])
            r = subprocess.run(["git", "apply", str(pf)], cwd=at, capture_output=True, text=True)
            if r.returncode != 0:
                ok = False
                failed.append(f"{task}/{change}" + ("" if g == name else " (its setup)"))
                break
        if ok:
            applied += 1
            stores.append(at)
    return applied, failed, stores


def bench():
    lines = []
    with tempfile.TemporaryDirectory() as tmp:
        work = pathlib.Path(tmp)
        for label, store_rev, patch_rev in [
            ("this commit's store, this commit's patches", None, None),
            (f"this commit's store, the patches at {BASE[:8]} (control)", None, BASE),
            (f"the store at {BASE[:8]}, this commit's patches (control)", BASE, None),
        ]:
            w = work / re.sub(r"\W+", "-", label)
            w.mkdir()
            applied, failed, stores = apply_all(store_rev, patch_rev, w)
            lines.append(f"== {label}")
            lines.append(f"   applied: {applied}; refused: {len(failed)}")
            lines += [f"   refused: {f}" for f in failed]
            if store_rev is None and patch_rev is None:
                said = [str(s.name) for s in stores if "double-tap" in (s / "store/app.pw").read_text()]
                lines.append(f"   stores that say \"double-tap\": {len(said)} {said}")
                # Each applied store is the same program as at the base: `pw diff`
                # between the base's store with the base's patches and this one.
                base_w = work / "base-pairs"
                base_w.mkdir()
                # The store itself, before any patch.
                store_at(base_w / "store-base", baseline(BASE))
                store_at(base_w / "store-this", baseline(None))
                r = subprocess.run([str(PW), "diff", str(base_w / "store-base"), str(base_w / "store-this")],
                                   capture_output=True, text=True)
                items = [l for l in r.stdout.splitlines() if l.startswith("- ")]
                lines.append(
                    f"   pw diff, the store alone, base -> this: exit {r.returncode}, "
                    f"{'every section `- none`' if items and all(l == '- none' for l in items) else 'A CHANGE: ' + str(items)}"
                )
                _, _, base_stores = apply_all(BASE, BASE, base_w)
                by_name = {s.name: s for s in base_stores}
                same = changed = 0
                for s in stores:
                    b = by_name.get(s.name)
                    if b is None:
                        continue
                    r = subprocess.run([str(PW), "diff", str(b), str(s)], capture_output=True, text=True)
                    said_diff = (r.stdout + r.stderr).replace(str(b), "base").replace(str(s), "this")
                    items = [l for l in said_diff.splitlines() if l.startswith("- ")]
                    if r.returncode == 0 and items and all(l == "- none" for l in items):
                        same += 1
                    else:
                        changed += 1
                        lines.append(f"   pw diff {s.name}: exit {r.returncode}: {said_diff.strip()[:400]}")
                lines.append(
                    f"   pw diff against the same task's store at the base: {same} report every "
                    f"section `- none`, {changed} report a change"
                )
            lines.append("")
    (OUT / "benchmark-patches.txt").write_text(
        "The benchmark's Pleris store and its tasks' patches (setup, then reference or unsafe)\n"
        f"commit: {git('rev-parse', 'HEAD').strip()}\n\n" + "\n".join(lines)
    )
    record("benchmark patches", ["collect.py", "bench"], 0)
    print("benchmark patches written", flush=True)


def stores():
    """Each of the 33 patched stores, as the base's store and patches make it
    and as this commit's do: every line that differs is a `//` comment, so the
    programs are the same. `pw diff` cannot say so of a store that does not
    check (an unsafe patch, or a setup the compiler refuses by design)."""
    import difflib
    lines, total, comment_only, other = [], 0, 0, []
    with tempfile.TemporaryDirectory() as tmp:
        work = pathlib.Path(tmp)
        (work / "base").mkdir()
        (work / "this").mkdir()
        _, failed_b, base_stores = apply_all(BASE, BASE, work / "base")
        _, failed_t, this_stores = apply_all(None, None, work / "this")
        by_name = {s.name: s for s in base_stores}
        for s in this_stores:
            b = by_name[s.name]
            total += 1
            changed = []
            files_b = {p.relative_to(b) for p in b.rglob("*.pw")}
            files_t = {p.relative_to(s) for p in s.rglob("*.pw")}
            if files_b != files_t:
                changed.append(("(files)", f"+{sorted(map(str, files_t - files_b))} -{sorted(map(str, files_b - files_t))}"))
            for f in sorted(files_t & files_b):
                old = (b / f).read_text().splitlines() if (b / f).exists() else []
                new = (s / f).read_text().splitlines()
                for l in difflib.unified_diff(old, new, lineterm="", n=0):
                    if l.startswith(("---", "+++", "@@")):
                        continue
                    changed.append((str(f), l))
            if not changed:
                comment_only += 1
                lines.append(f"   {s.name}: identical")
            elif all(f != "(files)" and l[1:].lstrip().startswith("//") for f, l in changed):
                comment_only += 1
                lines.append(f"   {s.name}: {len(changed)} line(s) differ, every one a // comment")
            else:
                other.append(s.name)
                lines.append(f"   {s.name}: A NON-COMMENT DIFFERENCE: {changed[:6]}")
        lines.insert(0, f"   applied: base {len(base_stores)} (refused {len(failed_b)}), "
                        f"this {len(this_stores)} (refused {len(failed_t)})")
    (OUT / "benchmark-stores-text.txt").write_text(
        "The 33 patched stores, the base's against this commit's: what differs\n"
        f"commit: {git('rev-parse', 'HEAD').strip()}\nbase: {BASE}\n\n" + "\n".join(lines)
        + f"\n\n{comment_only} of {total} are identical or differ only in // comment lines; "
        f"{len(other)} otherwise\n"
    )
    record("benchmark stores, text", ["collect.py", "stores"], 0 if not other and total == 33 else 1)
    print(f"stores: {comment_only} of {total} comment-only", flush=True)


def quick():
    OUT.mkdir(parents=True, exist_ok=True)
    if not git_clean():
        sys.exit("refusing: the tree differs from HEAD; evidence is recorded at a commit")
    (OUT / "environment.txt").write_text(
        f"commit: {git('rev-parse', 'HEAD').strip()}\nbase: {BASE}\n"
        f"branch: {git('rev-parse', '--abbrev-ref', 'HEAD').strip()}\n"
        + subprocess.run(["rustc", "--version"], capture_output=True, text=True).stdout
        + subprocess.run(["cargo", "--version"], capture_output=True, text=True).stdout
        + "node " + subprocess.run(["node", "--version"], capture_output=True, text=True).stdout
        + subprocess.run(["python3", "--version"], capture_output=True, text=True).stdout
        + f"CARGO_TARGET_DIR: {TARGET}\nCARGO_BUILD_JOBS: {os.environ.get('CARGO_BUILD_JOBS')}\n"
    )
    run("diff against the base", ["git", "diff", "--stat", BASE, "HEAD"], "diff-stat.txt")
    red()
    run("pw-core, every test binary",
        ["cargo", "test", "--locked", "--no-fail-fast", "-p", "pw-core"], "pw-core-tests.txt", gz=True)
    run("the guide", ["cargo", "test", "--locked", "-p", "pw-cli", "--test", "guide"], "guide-test.txt")
    run("the corpus, formatted", ["cargo", "test", "--locked", "-p", "pw-syntax", "--test", "corpus_fmt"],
        "corpus-fmt-test.txt")
    run("the guide's pw-check blocks, against the built pw",
        ["python3", str(HERE / "regen_guide_blocks.py"), ".", str(PW)], "guide-blocks.txt")
    bench()
    run("the planner: what the change reaches",
        ["python3", "scripts/ci_plan.py", "--shards", "1", "--changed", BASE, "HEAD"], "ci-plan.txt")
    run("mutation anchors", ["python3", "scripts/mutation_anchors.py"], "mutation-anchors.txt")
    run("just preflight", ["just", "preflight"], "preflight.txt")
    run("just evidence-gates", ["just", "evidence-gates"], "evidence-gates.txt", gz=True)


def mutations(scripts):
    OUT.mkdir(parents=True, exist_ok=True)
    for s in scripts:
        name = pathlib.Path(s).stem
        run(f"mutation script {s}, whole", ["python3", s], f"{name}.txt")
        run(f"mutation anchors after {s}", ["python3", "scripts/mutation_anchors.py"],
            f"{name}-anchors-after.txt")


def manifest():
    steps = [json.loads(l) for l in STEPS.read_text().splitlines()] if STEPS.exists() else []
    files = []
    for p in sorted(OUT.rglob("*")):
        if p.is_file() and p.name != "manifest.json":
            data = p.read_bytes()
            entry = {"path": str(p.relative_to(OUT)), "bytes": len(data),
                     "sha256": hashlib.sha256(data).hexdigest()}
            if p.suffix == ".gz":
                raw = gzip.decompress(data)
                entry.update(decoded_bytes=len(raw), decoded_sha256=hashlib.sha256(raw).hexdigest())
            files.append(entry)
    (OUT / "manifest.json").write_text(json.dumps({
        "kind": "LOCAL_WORKER_EVIDENCE",
        "track": "message-text",
        "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "commit": git("rev-parse", "HEAD").strip(),
        "base": BASE,
        "steps": steps,
        "files": files,
        "qualifications": [
            "Recorded locally in WSL Ubuntu 22.04; hosted CI has not run this commit.",
            "Nothing was pushed.",
        ],
    }, indent=1) + "\n")
    print("manifest written", flush=True)


if __name__ == "__main__":
    {"quick": lambda: quick(), "mutations": lambda: mutations(sys.argv[2:]),
     "stores": lambda: stores(), "manifest": lambda: manifest()}[sys.argv[1]]()
