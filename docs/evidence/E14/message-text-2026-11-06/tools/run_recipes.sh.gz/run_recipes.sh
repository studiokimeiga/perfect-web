#!/usr/bin/env bash
# The recipes `python3 scripts/ci_plan.py --changed 5d4d4d55 2fd56c14` plans,
# each run whole in the detached worktree at 2fd56c14, one after another (each
# mutation script edits the worktree's sources). After each: the anchors, and
# whether the worktree is back to its commit. Logs in $LOGS.
set -uo pipefail
cd /home/haki/code/pw-wt/message-text-recipes
export CARGO_TARGET_DIR=/home/haki/pw-targets/message-text-recipes PORT=46400 BENCH_PORT=46700
LOGS=/home/haki/pw-targets/message-text-logs/recipes
mkdir -p "$LOGS"
: > "$LOGS/summary.txt"
for r in "$@"; do
  start=$(date -u +%FT%TZ)
  just "$r" > "$LOGS/$r.log" 2>&1
  code=$?
  anchors=$(python3 scripts/mutation_anchors.py 2>&1 | tail -1)
  if git diff --quiet HEAD -- . ':(exclude)docs/evidence' ':(exclude)spikes/own-renderer/store-ir.json'; then
    restored=yes
  else
    restored="NO: $(git diff --name-only HEAD -- . ':(exclude)docs/evidence' | tr '\n' ' ')"
  fi
  echo "$r started=$start ended=$(date -u +%FT%TZ) exit=$code restored=$restored anchors=[$anchors]" | tee -a "$LOGS/summary.txt"
done
echo "leftover processes from this target: $(pgrep -fc message-text-recipes || true)" | tee -a "$LOGS/summary.txt"
git status --short | tee -a "$LOGS/summary.txt"
