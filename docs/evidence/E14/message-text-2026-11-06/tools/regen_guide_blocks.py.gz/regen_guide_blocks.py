#!/usr/bin/env python3
"""Regenerate docs/guide's `text pw-check` blocks from a built `pw`.

Replays what compiler/pw-cli/tests/guide.rs does for a `pw fails=` example
followed by a `text pw-check` block: the example is written, alone, as
`<last module segment>.pw` in a scratch directory, and
`pw check --plain <standard packages, sorted> <file>` runs there. The block
is what that prints, less its closing `pw check: ` count.

    regen_guide_blocks.py REPO PW [--write]

Prints one line per block: `same` or `changed`, with a unified diff of each
change. Without --write nothing is rewritten.
"""

import difflib
import pathlib
import subprocess
import sys
import tempfile


def fence_of(line):
    for c in "`~":
        n = len(line) - len(line.lstrip(c))
        if n >= 3:
            return c, n
    return None


def blocks(lines):
    """(info, first content index, end index (the closing fence), opening line number)."""
    out, open_ = [], None
    for i, line in enumerate(lines):
        if open_ is None:
            f = fence_of(line)
            if f and line == line.lstrip():
                open_ = (f[0], f[1], line[f[1]:].strip(), i)
        else:
            c, n, info, start = open_
            stripped = line.rstrip()
            if stripped and set(stripped) == {c} and len(stripped) >= n:
                out.append((info, start + 1, i, start + 1))
                open_ = None
    if open_ is not None:
        raise SystemExit("an unclosed fence")
    return out


def file_name_of(src):
    for line in src.splitlines():
        if line.startswith("module "):
            m = line[len("module "):].strip().rsplit(".", 1)[-1]
            if m:
                return f"{m}.pw"
    return "example.pw"


def main():
    repo, pw = pathlib.Path(sys.argv[1]).resolve(), sys.argv[2]
    write = "--write" in sys.argv[3:]
    packages = sorted(
        str(p)
        for d in ["packages/pw-std", "packages/pw-platform-web"]
        for p in (repo / d).iterdir()
        if p.suffix == ".pw"
    )
    changed = 0
    for page in sorted((repo / "docs/guide").glob("*.md")):
        lines = page.read_text().split("\n")
        found = blocks(lines)
        edits = []
        for k, (info, first, end, line_no) in enumerate(found):
            if info.split() != ["text", "pw-check"]:
                continue
            p_info, p_first, p_end, _ = found[k - 1]
            assert k > 0 and p_info.split()[0] == "pw" and "fails=" in p_info, (page, line_no)
            src = "\n".join(lines[p_first:p_end]) + "\n"
            with tempfile.TemporaryDirectory() as tmp:
                name = file_name_of(src)
                (pathlib.Path(tmp) / name).write_text(src)
                r = subprocess.run(
                    [pw, "check", "--plain", *packages, name],
                    cwd=tmp, capture_output=True, text=True,
                )
            assert r.returncode == 1 and "panicked" not in r.stderr, (page, line_no, r.stderr)
            printed = [l for l in r.stdout.split("\n") if not l.startswith("pw check: ")]
            while printed and printed[-1] == "":
                printed.pop()
            shown = lines[first:end]
            while shown and shown[-1].rstrip() == "":
                shown.pop()
            where = f"{page.relative_to(repo)}:{line_no}"
            if [l.rstrip() for l in shown] == [l.rstrip() for l in printed]:
                print(f"same     {where}")
                continue
            changed += 1
            print(f"changed  {where}")
            sys.stdout.writelines(
                l + "\n" for l in difflib.unified_diff(shown, printed, "shown", "printed", lineterm="")
            )
            edits.append((first, end, printed))
        if write and edits:
            for first, end, printed in reversed(edits):
                lines[first:end] = printed
            page.write_text("\n".join(lines))
    print(f"{changed} block(s) changed{' and rewritten' if write and changed else ''}")


if __name__ == "__main__":
    main()
