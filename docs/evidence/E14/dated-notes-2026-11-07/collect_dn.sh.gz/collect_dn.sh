#!/usr/bin/env bash
# Evidence for the dated diagnostic notes (2026-11-07), recorded at HEAD of
# the worktree it runs in, into docs/evidence/E14/dated-notes-2026-11-07/.
# LOGS holds the whole-suite logs of the same tree (clippy, the guide test,
# pw-core), run before this collector by the commands their headers name.
set -uo pipefail
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
: "${CARGO_TARGET_DIR:?set CARGO_TARGET_DIR}" "${LOGS:?set LOGS}" "${REGEN:?set REGEN}"
OUT=docs/evidence/E14/dated-notes-2026-11-07
BASE=$(git merge-base origin/master HEAD)
mkdir -p "$OUT"
header() {
  echo "$1"; echo
  echo "commit: $(git rev-parse HEAD)$(git diff --quiet HEAD -- . ':(exclude)docs/evidence' || echo ' + uncommitted changes')"
  echo "base: $BASE"; echo "rust: $(rustc --version)"; echo
}
GUARD=(cargo test --locked -p pw-core --test printed_texts_carry_no_dates)
SOURCES=(compiler/pw-core/src/check.rs compiler/pw-core/src/annotations.rs compiler/pw-core/src/graph.rs compiler/pw-core/src/holds.rs)
{
  header "The guard (compiler/pw-core/tests/printed_texts_carry_no_dates.rs), and its red control"
  echo "== at this commit: \$ ${GUARD[*]}"
  "${GUARD[@]}" 2>&1 | grep -E '^(test |test result)|panicked at'
  echo; echo "== the control: the four changed sources as the base holds them"
  for f in "${SOURCES[@]}"; do cp "$f" "/tmp/dn-$(basename "$f")"; git show "$BASE:$f" > "$f"; done
  out=$("${GUARD[@]}" -- no_string 2>&1)
  for f in "${SOURCES[@]}"; do cp "/tmp/dn-$(basename "$f")" "$f"; rm "/tmp/dn-$(basename "$f")"; done
  echo "$out" | grep -E '^test result'
  echo "dated literals reported: $(echo "$out" | grep -cE '^compiler/[a-z_/-]+\.rs:[0-9]+: 20[0-9]{2}-')"
  echo "$out" | grep -E '^compiler/[a-z_/-]+\.rs:[0-9]+: 20[0-9]{2}-' | cut -c1-110
  echo; git diff --quiet HEAD -- "${SOURCES[@]}" && echo "sources restored to HEAD: yes" || echo "sources restored to HEAD: NO"
} > "$OUT/guard.txt" 2>&1
for name in clippy guide pw-core; do
  {
    header "Recorded on the tree committed as $(git rev-parse --short HEAD); the run began before the commit was made, and no file it reads changed since"
    case $name in
      clippy) echo "\$ cargo clippy --locked -p pw-core --all-targets -- -D warnings"; echo; tail -3 "$LOGS/clippy.log" ;;
      guide) echo "\$ cargo test --locked -p pw-cli --test guide"; echo; grep -E '^(test |test result)|panicked at' "$LOGS/guide.log" ;;
      pw-core) echo "\$ cargo test --locked --no-fail-fast -p pw-core"; echo
        grep '^test result' "$LOGS/pw-core.log" | awk '{p+=$4; f+=$6; i+=$8} END {print NR " test binaries: " p " passed, " f " failed, " i " ignored"}'
        echo; cat "$LOGS/pw-core.log" ;;
    esac
  } > "$OUT/$name.txt"
done
gzip -n -f "$OUT/pw-core.txt"
{
  header "Every text pw-check block of docs/guide against the built pw (PW5048's regenerated)"
  python3 "$REGEN" . "$CARGO_TARGET_DIR/debug/pw"
} > "$OUT/guide-blocks.txt" 2>&1
{
  header "Mutation anchors and rustfmt"
  echo "== python3 scripts/mutation_anchors.py"; python3 scripts/mutation_anchors.py; echo "exit $?"
  echo; echo "== cargo fmt --all -- --check"; cargo fmt --all -- --check; echo "exit $?"
} > "$OUT/checks.txt" 2>&1
{
  header "What the change reaches (python3 scripts/ci_plan.py --changed BASE HEAD)"
  python3 scripts/ci_plan.py --shards 1 --changed "$BASE" HEAD | python3 -c 'import json,sys; s=sys.stdin.read().split("=",1)[1]; r=sorted(x for sh in json.loads(s) for x in sh["recipes"]); print(len(r), "recipes:"); print("\n".join("  "+x for x in r))'
  echo; echo "Left to this branch's hosted verification (the PC runs no heavy recipes, 2026-11-07)."
} > "$OUT/ci-plan.txt" 2>&1
gzip -n -c "$0" > "$OUT/collect_dn.sh.gz"
ls "$OUT"
