# Source me: the toolchain environment for the todomvc-checks worktree.
export PATH="$HOME/.nvm/versions/node/v22.21.1/bin:$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
export WT=/home/haki/code/pw-wt/todomvc-checks
export CARGO_TARGET_DIR=/home/haki/pw-targets/todomvc-checks
export SP=/mnt/c/Users/haki/AppData/Local/Temp/claude/2fa9113b97a63953/ed6a007c-73b2-4125-864d-2fde8498d637/scratchpad
export PORT=14880
cd "$WT"
