"""scripts/todomvc_mutations.py's own main(), over its styles mutants alone:
a quick check, before the whole script runs again, that each is killed under
the receipt protocol (baseline, the four, then the restored suites). Not the
evidence: the whole script, run whole at the commit, is."""
import os, pathlib, sys
ROOT = pathlib.Path(os.environ["WT"])
os.chdir(ROOT)
sys.path.insert(0, str(ROOT / "scripts"))
import todomvc_mutations as t
t.MUTANTS[:] = [m for m in t.MUTANTS if m[1] == t.STYLES]
print(f"styles mutants only: {len(t.MUTANTS)}", flush=True)
sys.exit(t.main())
