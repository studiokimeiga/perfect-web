// **The checkbox's ink, measured** (ADR-0367's amendment of 2026-11-06): how
// far this app's drawing is from the official one in the ink each region
// lays down, per channel: the sum over its pixels of 255 less the value. Ink
// is conserved by anti-aliasing (a thin line spread over more pixels lays the
// same ink), so it tells a colour or a lightness apart from an edge drawn
// otherwise. Two regions of the 40-pixel box: the ring's annulus (within 2.5
// pixels of its radius) and inside it (the tick's). For the drawing as it is
// and for drawings with one colour changed, in Chromium and Firefox; and the
// whole-box measures the spec bounds now, for comparison.
//
//   cd spikes/own-renderer && node <this file>     (needs todomvc-styles.mjs beside it)
import { readFileSync } from "node:fs";
import { chromium, firefox } from "@playwright/test";
import { sheetOf } from "./todomvc-styles.mjs";

const OFFICIAL = readFileSync("node_modules/todomvc-app-css/index.css", "utf8");
const BASE = readFileSync("node_modules/todomvc-common/base.css", "utf8");
const OURS = sheetOf(OFFICIAL);
const markup = (checked) =>
  '<section class="todoapp"><section class="main"><ul class="todo-list"><li><div class="view">' +
  `<input class="toggle" type="checkbox"${checked ? " checked" : ""}><label>buy some cheese</label></div></li></ul></section></section>`;

async function shot(page, sheets, checked) {
  await page.setContent(sheets.map((s) => `<style>${s}</style>`).join("") + markup(checked));
  const label = await page.locator("label").boundingBox();
  return page.screenshot({ clip: { x: label.x, y: label.y + (label.height - 40) / 2, width: 40, height: 40 } });
}

// The official circle: centre (22.963, 20.148) px, radius 14.815, in the box.
async function measure(page, a, b) {
  return page.evaluate(async ([a, b]) => {
    const pixels = async (png) => {
      const i = new Image();
      i.src = `data:image/png;base64,${png}`;
      await i.decode();
      const c = Object.assign(document.createElement("canvas"), { width: i.width, height: i.height });
      const g = c.getContext("2d");
      g.drawImage(i, 0, 0);
      return g.getImageData(0, 0, i.width, i.height).data;
    };
    const [p, q] = [await pixels(a), await pixels(b)];
    const region = (k) => {
      const x = (k / 4) % 40 + 0.5, y = Math.floor(k / 4 / 40) + 0.5;
      const d = Math.hypot(x - 22.963, y - 20.148);
      return Math.abs(d - 14.815) <= 2.5 ? "ring" : d < 14.815 - 2.5 ? "inside" : "outside";
    };
    const ink = { ring: [[0, 0, 0], [0, 0, 0]], inside: [[0, 0, 0], [0, 0, 0]], outside: [[0, 0, 0], [0, 0, 0]] };
    const each = [];
    for (let k = 0; k < p.length; k += 4) {
      each.push(Math.max(Math.abs(p[k] - q[k]), Math.abs(p[k + 1] - q[k + 1]), Math.abs(p[k + 2] - q[k + 2])));
      const r = ink[region(k)];
      for (let c = 0; c < 3; c++) { r[0][c] += 255 - p[k + c]; r[1][c] += 255 - q[k + c]; }
    }
    const apart = (r) => r[0].map((o, c) => (o ? ((r[1][c] - o) / o) * 100 : r[1][c]).toFixed(1)).join("/");
    return `mean ${(each.reduce((s, d) => s + d, 0) / each.length).toFixed(2)}, over ${each.filter((d) => d > 32).length}, largest ${Math.max(...each)}; ` +
      `ink apart % (r/g/b): ring ${apart(ink.ring)}, inside ${apart(ink.inside)}, outside ${ink.outside[0].join("/")} vs ${ink.outside[1].join("/")}; ` +
      `official ink: ring ${ink.ring[0].join("/")}, inside ${ink.inside[0].join("/")}`;
  }, [a.toString("base64"), b.toString("base64")]);
}

const CHECKED = ".todo-list li .toggle:checked + label";
const ring = (colour) => `radial-gradient(circle at 22.963px 20.148px, transparent 13.926px, ${colour} 14.815px, transparent 15.704px)`;
const VARIANTS = {
  unchecked: {
    "as it is": "",
    "the ring lighter (#CACACA)": `.todo-list li .toggle + label { background-image: ${ring("#CACACA")}; }`,
    "the ring off its centre by 2 px": `.todo-list li .toggle + label { background-image: ${ring("#949494").replace("22.963px", "24.963px")}; }`,
  },
  checked: {
    "as it is": "",
    "the checked ring in the unchecked colour (the surviving mutant)": `${CHECKED} { background-image: ${ring("#949494")}; }`,
    "the tick in the ring's colour (#59A193)": `${CHECKED}::after { background: #59A193; }`,
    "the checked ring lighter (#ACD0C9)": `${CHECKED} { background-image: ${ring("#ACD0C9")}; }`,
  },
};

for (const engine of [chromium, firefox]) {
  const browser = await engine.launch();
  const page = await browser.newPage();
  console.log(`== ${engine.name()} ${browser.version()}`);
  for (const [state, variants] of Object.entries(VARIANTS)) {
    const official = await shot(page, [BASE, OFFICIAL], state === "checked");
    for (const [name, extra] of Object.entries(variants)) {
      const ours = await shot(page, [BASE, OFFICIAL, OURS, extra], state === "checked");
      console.log(`${state}, ${name}: ${await measure(page, official, ours)}`);
    }
  }
  await browser.close();
}
