// **The alternatives to the checkbox's CSS drawing, measured** (ADR-0367's
// amendment of 2026-11-06): each against the official drawing, as
// `e2e/todomvc.spec.mjs` compares them, in Chromium and Firefox.
// - the ring's profile, unchecked: six;
// - the tick's placement, checked: where a box falls, moved by fractions of a
//   pixel, and rounded to the row a browser draws the background's image on;
// - the tick's clip: `polygon()` and `path()`.
// Each line: the mean over the 1,600 pixels of each pixel's largest channel
// difference, the pixels apart by more than an eighth, and the largest.
//
//   cd spikes/own-renderer && node <this file>     (needs todomvc-styles.mjs beside it)
import { readFileSync } from "node:fs";
import { chromium, firefox } from "@playwright/test";
import { sheetOf } from "./todomvc-styles.mjs";

const OFFICIAL = readFileSync("node_modules/todomvc-app-css/index.css", "utf8");
const BASE = readFileSync("node_modules/todomvc-common/base.css", "utf8");
const OURS = sheetOf(OFFICIAL);
const markup = (checked) =>
  '<section class="todoapp"><section class="main"><ul class="todo-list"><li><div class="view">' +
  `<input class="toggle" type="checkbox"${checked ? " checked" : ""}><label>buy some cheese</label></div></li></ul></section></section>`;

async function shot(page, sheets, checked) {
  await page.setContent(sheets.map((s) => `<style>${s}</style>`).join("") + markup(checked));
  const label = await page.locator("label").boundingBox();
  return page.screenshot({ clip: { x: label.x, y: label.y + (label.height - 40) / 2, width: 40, height: 40 } });
}

async function apart(page, a, b) {
  return page.evaluate(async ([a, b]) => {
    const px = async (png) => {
      const i = new Image();
      i.src = `data:image/png;base64,${png}`;
      await i.decode();
      const c = Object.assign(document.createElement("canvas"), { width: i.width, height: i.height });
      const g = c.getContext("2d");
      g.drawImage(i, 0, 0);
      return g.getImageData(0, 0, i.width, i.height).data;
    };
    const [p, q] = [await px(a), await px(b)];
    const each = [];
    for (let k = 0; k < p.length; k += 4) {
      each.push(Math.max(Math.abs(p[k] - q[k]), Math.abs(p[k + 1] - q[k + 1]), Math.abs(p[k + 2] - q[k + 2])));
    }
    return `mean ${(each.reduce((s, d) => s + d, 0) / each.length).toFixed(2)}, over an eighth ${each.filter((d) => d > 32).length}, largest ${Math.max(...each)}`;
  }, [a.toString("base64"), b.toString("base64")]);
}

// The official circle: centre (22.963, 20.148) px, radius 14.815, stroke 0.889.
const ring = (inner, peak, outer) =>
  `radial-gradient(circle at 22.963px 20.148px, transparent ${inner}px, #949494 ${peak}px, transparent ${outer}px)`;
const band = (a, b, c, d) =>
  `radial-gradient(circle at 22.963px 20.148px, transparent ${a}px, #949494 ${b}px, #949494 ${c}px, transparent ${d}px)`;
const RINGS = {
  "its colour at the radius, fading over a stroke's width either side (chosen)": ring(13.926, 14.815, 15.704),
  "the same, fading over 0.75 px": ring(14.065, 14.815, 15.565),
  "the same, fading over 1.0 px": ring(13.815, 14.815, 15.815),
  "the same, fading over 1.2 px": ring(13.615, 14.815, 16.015),
  "a band a stroke wide, with 0.5 px ramps": band(13.871, 14.371, 15.259, 15.759),
  "a band a stroke wide, hard-edged": band(14.37, 14.371, 15.259, 15.26),
};
const AFTER = ".todo-list li .toggle:checked + label::after";
const PATH = 'path("M29.481 12.741L20.593 26.37L16.148 21.926L14.963 23.111L20.889 29.037L30.963 13.63Z")';
const ROUNDED = "top: round(nearest, calc(50% - 20px), 1px);";
const TICKS = {
  ...Object.fromEntries(
    [-0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6].map((dy) => [
      `polygon, its box where it falls, moved ${dy} px`,
      `${AFTER} { top: calc(50% - 20px + ${dy}px); }`,
    ]),
  ),
  "polygon, its box rounded to the image's row (chosen)": `${AFTER} { ${ROUNDED} }`,
  "path(), its box rounded to the image's row": `${AFTER} { ${ROUNDED} clip-path: ${PATH}; }`,
};

for (const engine of [chromium, firefox]) {
  const browser = await engine.launch();
  const page = await browser.newPage();
  console.log(`== ${engine.name()} ${browser.version()}`);
  const unchecked = await shot(page, [BASE, OFFICIAL], false);
  for (const [name, image] of Object.entries(RINGS)) {
    const extra = `.todo-list li .toggle + label { background-image: ${image}; }`;
    console.log(`ring, unchecked: ${name}: ${await apart(page, unchecked, await shot(page, [BASE, OFFICIAL, OURS, extra], false))}`);
  }
  const checked = await shot(page, [BASE, OFFICIAL], true);
  for (const [name, extra] of Object.entries(TICKS)) {
    console.log(`tick, checked: ${name}: ${await apart(page, checked, await shot(page, [BASE, OFFICIAL, OURS, extra], true))}`);
  }
  await browser.close();
}
