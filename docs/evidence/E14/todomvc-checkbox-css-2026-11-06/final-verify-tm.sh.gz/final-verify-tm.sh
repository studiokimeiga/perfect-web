#!/usr/bin/env bash
# TodoMVC's checkbox in CSS, verified at its exact commit (the second run; the
# first, at d94b6ecd, failed and is kept as run1-*): the
# Fallow audit as CI runs it against master (5d4d4d55), the whole pre-push
# check, then `scripts/todomvc_mutations.py` (whose mutants and suite it
# changes) and every other mutation script the change reaches
# (`reached.py 5d4d4d55`), each run whole, as its recipe runs it.
set -uo pipefail
source "$SCRATCH/env-tm.sh"
LOG="$SP/final-verify-tm.log"
: > "$LOG"
step() { echo "== $(date -Is) $*" >> "$LOG"; }
step "commit $(git rev-parse HEAD); uncommitted code paths: $(git status --porcelain -- . ':(exclude)docs' | wc -l)"
step "fallow audit (fallow 3.23.0, gate new-only, against 5d4d4d55, as CI runs it)"
npx -y fallow@3.23.0 audit --root . --quiet --format json \
  --changed-since 5d4d4d55a36f52ea556aa8f2af3e70b1150ffcf6 --gate new-only > "$SP/fallow-tm.json" 2>/dev/null
echo "exit fallow $?" >> "$LOG"
python3 - "$SP/fallow-tm.json" >> "$LOG" <<'EOF'
import json, sys
d = json.load(open(sys.argv[1]))
print("verdict", d["verdict"], json.dumps(d["attribution"]))
for f in d["complexity"]["findings"]:
    if f.get("introduced"):
        print("introduced", f["path"], f["name"], f["line"], f["cyclomatic"], f["exceeded"])
EOF
step "reached mutation scripts (reached.py 5d4d4d55 3)"
python3 "$SP/reached.py" 5d4d4d55 3 > "$SP/tm-reached.txt" 2>&1
cat "$SP/tm-reached.txt" >> "$LOG"
step "the whole pre-push check (TAG=tm2)"
TAG=tm2 bash "$SCRATCH/prepush-verify-tm.sh"; echo "exit tm2 $?" >> "$LOG"
grep -E "^exit |Running [0-9]+ tests|^\s+[0-9]+ (passed|skipped|failed|flaky)|^Ran |^OK|^FAILED|EVIDENCE|is not run|test result: ok. 8" "$SP/tm2-verify.log" >> "$LOG"
grep -h "EVIDENCE checkbox" "$SP/tm2-specs.log" >> "$LOG"
scripts=$( { echo todomvc; sed -n 's/^\([a-z_0-9]*\)_mutations\.py: .*/\1/p' "$SP/tm-reached.txt"; } | sort -u)
for s in $scripts; do
  step "mutation controls: $s"
  CARGO_INCREMENTAL=0 python3 "scripts/${s}_mutations.py" > "$SP/tm-mut-$s.log" 2>&1
  echo "exit $s $?" >> "$LOG"
  grep -E "^baseline|^restored|KILLED|SURVIVED|REFUSED|DID NOT BUILD|mutants killed" "$SP/tm-mut-$s.log" >> "$LOG"
done
step "restored"
python3 scripts/mutation_anchors.py >> "$LOG" 2>&1; echo "exit anchors $?" >> "$LOG"
git status --porcelain -- . ':(exclude)docs' >> "$LOG"
echo FINAL_VERIFY_TM_FINISHED >> "$LOG"
