#!/usr/bin/env bash
# TodoMVC's checkbox in CSS, its whole check copied into the branch's evidence
# (`docs/evidence/E14/todomvc-checkbox-css-2026-11-06/`): the check at the
# exact commit (its second run, tm2), the mutation scripts it ran whole; the
# first run, at d94b6ecd, which failed (run1-*); the probes that found that
# failure's cause and checked its fix; the drawing's alternatives measured; the
# long logs compressed, the scripts that ran them beside them, and SHA256SUMS
# over everything but the README.
set -euo pipefail
SP=/mnt/c/Users/haki/AppData/Local/Temp/claude/2fa9113b97a63953/ed6a007c-73b2-4125-864d-2fde8498d637/scratchpad
WT=/home/haki/code/pw-wt/todomvc-checks
OUT="$WT/docs/evidence/E14/todomvc-checkbox-css-2026-11-06"
mkdir -p "$OUT"
strip() { sed 's/\x1b\[[0-9;]*[A-Za-z]//g' "$1"; }
small() { strip "$SP/$1" > "$OUT/${2:-$1}"; }
large() { strip "$SP/$1" | gzip -9n > "$OUT/${2:-$1}.gz"; }
script() { gzip -9nc "$SP/$1" > "$OUT/$1.gz"; }

# The second run, at the commit.
small final-verify-tm.log
small tm-reached.txt
small tm2-verify.log
small tm2-size.log
for f in tm2-preflight.log tm2-evidence-gates.log tm2-cargo-test.log tm2-specs.log; do large "$f"; done
for f in "$SP"/tm-mut-*.log; do large "$(basename "$f")"; done
gzip -9nc "$SP/fallow-tm.json" > "$OUT/fallow-tm.json.gz"

# The first run, at d94b6ecd, which failed.
small run1/final-verify-tm.log run1-final-verify-tm.log
small run1/tm-reached.txt run1-tm-reached.txt
small run1/tm1-verify.log run1-tm1-verify.log
for f in tm1-evidence-gates.log tm1-specs.log tm-mut-page_policy.log tm-mut-todomvc.log tm-mut-todomvc_producer.log; do
  large "run1/$f" "run1-$f"
done

# The failures' causes found and their fixes checked, and the alternatives
# measured: which matchers name themselves; each styles mutant's effect on the
# sheet; the four styles mutants alone, once with the pixel bounds only (the
# survivor) and once with the ink bounds; the ink measured.
for f in matcher-names.log styles-mutant-effects.log styles-only-1.log styles-only.log ink-measure.log \
         checkbox-alternatives.log; do
  small "$f"
done
for f in final-verify-tm.sh prepush-verify-tm.sh env-tm.sh reached.py matcher-names.mjs styles-mutant-effects.py \
         styles-only-mutations.py ink-measure.mjs checkbox-alternatives.mjs copy-tm-evidence.sh; do
  script "$f"
done

cd "$OUT"
find . -type f ! -name README.md ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
echo "copied: $(ls | wc -l) files; SHA256SUMS lines: $(wc -l < SHA256SUMS)"
