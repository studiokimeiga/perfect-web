// #81's WebKit failure: where the checked tick must sit to match the
// official drawing in each engine. Each variant's checked box against the
// official sheet's, as `e2e/todomvc.spec.mjs` compares them: the mean of each
// pixel's largest channel difference, and the pixels over an eighth.
//   cd spikes/own-renderer && node <this file>
import { readFileSync } from "node:fs";
import { chromium, firefox, webkit } from "@playwright/test";
import { sheetOf } from "./todomvc-styles.mjs";

const OFFICIAL = readFileSync("node_modules/todomvc-app-css/index.css", "utf8");
const BASE = readFileSync("node_modules/todomvc-common/base.css", "utf8");
const OURS = sheetOf(OFFICIAL);
const AFTER = ".todo-list li .toggle:checked + label::after";
const markup =
  '<section class="todoapp"><section class="main"><ul class="todo-list"><li><div class="view">' +
  '<input class="toggle" type="checkbox" checked><label>buy some cheese</label></div></li></ul></section></section>';

const VARIANTS = {
  "as it is: in the item, rounded": "",
  "in the item, not rounded": `${AFTER} { top: calc(50% - 20px); }`,
  "in the label, not rounded": `.todo-list li .toggle { z-index: 1; } .todo-list li label { position: relative; } ${AFTER} { top: calc(50% - 20px); }`,
  "in the label, rounded": `.todo-list li .toggle { z-index: 1; } .todo-list li label { position: relative; } ${AFTER} { top: round(nearest, calc(50% - 20px), 1px); }`,
  "in the item, floored": `${AFTER} { top: round(down, calc(50% - 20px), 1px); }`,
  "in the item, ceiled": `${AFTER} { top: round(up, calc(50% - 20px), 1px); }`,
};

async function shot(page, sheets) {
  await page.setContent(sheets.map((s) => `<style>${s}</style>`).join("") + markup);
  const label = await page.locator("label").boundingBox();
  return page.screenshot({ clip: { x: label.x, y: label.y + (label.height - 40) / 2, width: 40, height: 40 } });
}

async function apart(page, a, b) {
  return page.evaluate(async ([a, b]) => {
    const px = async (png) => {
      const i = new Image();
      i.src = `data:image/png;base64,${png}`;
      await i.decode();
      const c = Object.assign(document.createElement("canvas"), { width: i.width, height: i.height });
      const g = c.getContext("2d");
      g.drawImage(i, 0, 0);
      return g.getImageData(0, 0, i.width, i.height).data;
    };
    const [p, q] = [await px(a), await px(b)];
    const each = [];
    for (let k = 0; k < p.length; k += 4) {
      each.push(Math.max(Math.abs(p[k] - q[k]), Math.abs(p[k + 1] - q[k + 1]), Math.abs(p[k + 2] - q[k + 2])));
    }
    return `mean ${(each.reduce((s, d) => s + d, 0) / each.length).toFixed(2)}, over ${each.filter((d) => d > 32).length}`;
  }, [a.toString("base64"), b.toString("base64")]);
}

for (const engine of [chromium, firefox, webkit]) {
  let browser;
  try {
    browser = await engine.launch();
    const page = await browser.newPage();
    const label = await (async () => {
      await page.setContent(`<style>${BASE}</style><style>${OFFICIAL}</style>${markup}`);
      return page.locator("label").boundingBox();
    })();
    console.log(`== ${engine.name()} ${browser.version()}: label ${JSON.stringify(label)}`);
    const official = await shot(page, [BASE, OFFICIAL]);
    for (const [name, extra] of Object.entries(VARIANTS)) {
      console.log(`${name}: ${await apart(page, official, await shot(page, [BASE, OFFICIAL, OURS, extra]))}`);
    }
  } catch (error) {
    console.log(`== ${engine.name()}: not run here (${String(error.message).split("\n")[0]})`);
  } finally {
    await browser?.close();
  }
}
