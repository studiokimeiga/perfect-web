"""Each styles mutant of scripts/todomvc_mutations.py, applied to a copy of
todomvc-styles.mjs: does the sheet it writes differ from the unmutated one?
(An equivalent mutant would survive whatever the tests.)"""
import os, pathlib, subprocess, sys, tempfile
ROOT = pathlib.Path(os.environ["WT"])
sys.path.insert(0, str(ROOT / "scripts"))
import todomvc_mutations as t
CSS = ROOT / "spikes/own-renderer/node_modules/todomvc-app-css/index.css"
def sheet(source):
    with tempfile.TemporaryDirectory() as d:
        f = pathlib.Path(d) / "styles.mjs"
        f.write_text(source)
        js = f"import('{f.as_uri()}').then(m => process.stdout.write(m.sheetOf(require('fs').readFileSync('{CSS}', 'utf8'))))"
        run = subprocess.run(["node", "-e", js], capture_output=True, text=True, timeout=30)
        return run.returncode, run.stdout, run.stderr.strip().splitlines()[-1:] 
original = t.STYLES_FILE.read_text()
code, base, err = sheet(original)
print("unmutated:", code, len(base), "bytes", err)
for what, kind, path, anchor, replacement in t.MUTANTS:
    if kind != t.STYLES:
        continue
    assert original.count(anchor) == 1, what
    code, out, err = sheet(original.replace(anchor, replacement, 1))
    changed = [l for l in out.splitlines() if l not in base.splitlines()]
    print(f"{what}: exit {code}, {'DIFFERS' if out != base else 'SAME'}; {err}")
    for l in changed[:3]:
        print("   ", l[:160])
