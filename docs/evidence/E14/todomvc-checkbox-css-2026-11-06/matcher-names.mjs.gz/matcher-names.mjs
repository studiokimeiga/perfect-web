// Which of Playwright's synchronous matchers name themselves in a failure's
// matcherResult: only those can carry assertion-expect.mjs's proof.
import { expect } from "@playwright/test";
const cases = {
  toBe: () => expect(1).toBe(2),
  toEqual: () => expect([1]).toEqual([]),
  toStrictEqual: () => expect([1]).toStrictEqual([]),
  toMatch: () => expect("a").toMatch(/^b/),
  toBeLessThan: () => expect(8).toBeLessThan(3),
  toBeLessThanOrEqual: () => expect(8).toBeLessThanOrEqual(3),
  toBeGreaterThan: () => expect(1).toBeGreaterThan(3),
  toBeTruthy: () => expect(false).toBeTruthy(),
  toContain: () => expect([1]).toContain(2),
  toHaveLength: () => expect([1]).toHaveLength(2),
  toMatchObject: () => expect({ a: 1 }).toMatchObject({ a: 2 }),
};
for (const [name, run] of Object.entries(cases)) {
  try { run(); console.log(`${name}: passed?`); }
  catch (error) { console.log(`${name}: matcherResult.name=${error.matcherResult?.name}`); }
}
